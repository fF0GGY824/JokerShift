extends Control

const SUITS = ["♠", "♥", "♦", "♣"]
const RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "В", "Д", "К", "Т"]
const BG = Color("#12091F")
const VIOLET = Color("#A45BFF")
const LIGHT = Color("#F5E8FF")
const GOLD = Color("#DDB5FF")
const TELEGRAM_NEWS_URL: String = "https://t.me/+HLR-m55X-bM2ZjAy"

var deck: Array = []
var player_hand: Array = []
var bot_hand: Array = []
var table_cards: Array = []
var discard_pile: Array = []
var replaced_throw_ranks: Array[int] = []

var trump_mode: String = "suit"
var trump_suit: String = ""
var bot_difficulty: int = 1
var attacker: int = 0
var first_round: bool = true
var bot_takes: bool = false
var finished: bool = false
var player_nick: String = "Игрок"
var selected_index: int = -1
var selected_pair: int = -1
var status_text: String = ""
var last_table_visual_key: String = ""
var last_hand_visual_key: String = ""
var last_trump_visual_key: String = ""

var menu_screen: Control
var menu_panel: PanelContainer
var coming_soon_dialog: AcceptDialog
var mobile_more_dialog: AcceptDialog
var news_dialog: ConfirmationDialog
var game_screen: Control
var nick_input: LineEdit
var difficulty_select: OptionButton
var avatar_dialog: FileDialog
var avatar_preview: TextureRect
var avatar_game: TextureRect
var avatar_placeholder_menu: Label
var avatar_placeholder_game: Label
var avatar_texture: Texture2D

const AVATAR_SAVE_PATH = "user://avatar.png"
const PROFILE_SAVE_PATH = "user://profile.cfg"
const MAX_AVATAR_FILE_BYTES: int = 8 * 1024 * 1024
const MAX_AVATAR_SIDE: int = 384

# Оригинальные изображения карт.
# Если атласа нет, игра рисует карты самостоятельно.
# Рубашка соперника при этом не изменяется.
# Each face is its own PNG. This prevents Godot from displaying
# an entire atlas row inside a single card in GL Compatibility.
const CARD_FACES_DIR: String = "res://assets/faces/"
var face_image_cache: Dictionary = {}
var face_texture_cache: Dictionary = {}

var rules_dialog: AcceptDialog
var result_dialog: AcceptDialog
var joker_dialog: ConfirmationDialog
var joker_options: VBoxContainer
var replace_confirmation: ConfirmationDialog
var pending_replacement: Dictionary = {}

var enemy_backs: HBoxContainer
var enemy_back_scroll: ScrollContainer
var motion_layer: Control
var animation_busy: bool = false
var animation_serial: int = 0
var animation_enabled: bool = true
var last_enemy_visual_key: String = ""
var remembered_table_faces: Dictionary = {}

var finale_overlay: Control
var finale_id: int = 0

# In-game stopwatch and modal pause controls.
var elapsed_game_seconds: float = 0.0
var timer_label: Label
var pause_timer_label: Label
var pause_overlay: Control
var is_game_paused: bool = false

var bot_label: Label
var player_label: Label
var deck_label: Label
var discard_label: Label
var trump_label: Label
var trump_icon_row: HBoxContainer
var mobile_deck_strip: PanelContainer
var mobile_deck_label: Label
var mobile_discard_label: Label
var mobile_trump_label: Label
var status_label: Label

var table_grid: GridContainer
var hand_row: HBoxContainer
var hand_scroll: ScrollContainer
var deck_panel: PanelContainer
var field_panel: GameField
var battle_layout: GridContainer
var deck_info: HBoxContainer
var battle_scroll: ScrollContainer
var hand_actions_layout: GridContainer

var landscape_mode: bool = false
var slot_width: float = 78.0
var slot_height: float = 132.0
var card_width: float = 74.0
var card_height: float = 110.0

var pending_joker_action: String = ""
var pending_joker_index: int = -1
var pending_pair_index: int = -1
var pending_slot_id: int = -1


class SuitIcon extends Control:
	var suit: String = ""
	var ink: Color = Color("#251530")
	var card_icon: bool = false

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		queue_redraw()

	func paint_poly(points: PackedVector2Array) -> void:
		draw_colored_polygon(points, ink)

	func _draw() -> void:
		if suit.is_empty():
			return

		var center: Vector2 = Vector2(
			size.x * 0.5,
			size.y * (0.55 if card_icon else 0.5)
		)

		var r: float = minf(
			size.x * 0.29,
			size.y * (0.19 if card_icon else 0.36)
		)

		if r < 2.0:
			return

		match suit:
			"♥":
				draw_circle(
					center + Vector2(-0.47 * r, -0.35 * r),
					0.65 * r,
					ink
				)
				draw_circle(
					center + Vector2(0.47 * r, -0.35 * r),
					0.65 * r,
					ink
				)
				paint_poly(PackedVector2Array([
					center + Vector2(-1.10 * r, -0.25 * r),
					center + Vector2(1.10 * r, -0.25 * r),
					center + Vector2(0.0, 1.28 * r)
				]))

			"♦":
				paint_poly(PackedVector2Array([
					center + Vector2(0.0, -1.28 * r),
					center + Vector2(0.95 * r, 0.0),
					center + Vector2(0.0, 1.28 * r),
					center + Vector2(-0.95 * r, 0.0)
				]))

			"♠":
				draw_circle(
					center + Vector2(-0.49 * r, 0.12 * r),
					0.62 * r,
					ink
				)
				draw_circle(
					center + Vector2(0.49 * r, 0.12 * r),
					0.62 * r,
					ink
				)
				paint_poly(PackedVector2Array([
					center + Vector2(0.0, -1.33 * r),
					center + Vector2(1.04 * r, 0.33 * r),
					center + Vector2(-1.04 * r, 0.33 * r)
				]))
				paint_poly(PackedVector2Array([
					center + Vector2(-0.20 * r, 0.30 * r),
					center + Vector2(0.20 * r, 0.30 * r),
					center + Vector2(0.47 * r, 1.10 * r),
					center + Vector2(-0.47 * r, 1.10 * r)
				]))

			"♣":
				draw_circle(
					center + Vector2(0.0, -0.66 * r),
					0.63 * r,
					ink
				)
				draw_circle(
					center + Vector2(-0.59 * r, 0.16 * r),
					0.63 * r,
					ink
				)
				draw_circle(
					center + Vector2(0.59 * r, 0.16 * r),
					0.63 * r,
					ink
				)
				paint_poly(PackedVector2Array([
					center + Vector2(-0.20 * r, 0.0),
					center + Vector2(0.20 * r, 0.0),
					center + Vector2(0.47 * r, 1.10 * r),
					center + Vector2(-0.47 * r, 1.10 * r)
				]))

			"joker", "mark":
				var points: PackedVector2Array = PackedVector2Array()

				for i in range(10):
					var a: float = (
						-PI * 0.5 + float(i) * PI / 5.0
					)
					var length: float = (
						r * (1.16 if i % 2 == 0 else 0.43)
					)
					points.append(
						center
						+ Vector2(cos(a), sin(a)) * length
					)

				paint_poly(points)


class GameCard extends Button:
	var game
	var card: Dictionary = {}
	var role: String = ""
	var hand_index: int = -1
	var pair_index: int = -1

	func _ready() -> void:
		text = ""
		focus_mode = Control.FOCUS_NONE
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND

		var texture: Texture2D = game.card_face_texture(card)

		if texture != null:
			var face: TextureRect = TextureRect.new()
			face.name = "CardFaceArt"
			face.texture = texture
			face.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			face.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			# A dedicated pre-resampled ImageTexture, NOT an atlas crop.
			face.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			face.mouse_filter = Control.MOUSE_FILTER_IGNORE
			add_child(face)
			face.set_anchors_and_offsets_preset(
				Control.PRESET_FULL_RECT
			)

			# All PNG faces already contain the matching rank and suit in
			# both corners, including В/Д/К/Т. Do not overlay a second
			# label over their built-in artwork.
			add_joker_copy_badge()

			mouse_entered.connect(_hover.bind(true))
			mouse_exited.connect(_hover.bind(false))
			return

		mouse_entered.connect(_hover.bind(true))
		mouse_exited.connect(_hover.bind(false))

		var icon: SuitIcon = SuitIcon.new()
		icon.name = "SuitGlyph"
		icon.card_icon = true
		icon.suit = str(game.card_suit(card))

		icon.ink = (
			Color("#D82E57")
			if icon.suit == "♥" or icon.suit == "♦"
			else Color("#251530")
		)

		if game.is_mark(card):
			icon.suit = "mark"
			icon.ink = Color("#8732C8")

		elif game.is_joker(card):
			if game.card_rank(card) == 100:
				icon.suit = "mark"
				icon.ink = Color("#8732C8")

			elif (
				game.card_rank(card) >= 2
				and not game.card_suit(card).is_empty()
			):
				icon.suit = game.card_suit(card)
				icon.ink = (
					Color("#D82E57")
					if icon.suit == "♥" or icon.suit == "♦"
					else Color("#251530")
				)
			else:
				icon.suit = "joker"
				icon.ink = (
					Color("#D82E57")
					if str(card.get("joker_color", "")) == "red"
					else Color("#251530")
				)

		add_child(icon)
		icon.set_anchors_and_offsets_preset(
			Control.PRESET_FULL_RECT
		)

		var corner: SuitIcon = SuitIcon.new()
		corner.name = "SuitCorner"
		corner.suit = str(game.card_suit(card))

		if corner.suit.is_empty():
			corner.suit = icon.suit

		corner.ink = (
			Color("#D82E57")
			if corner.suit == "♥" or corner.suit == "♦"
			else Color("#251530")
		)

		if corner.suit == "joker" or corner.suit == "mark":
			corner.ink = icon.ink

		corner.anchor_left = 1.0
		corner.anchor_right = 1.0
		corner.anchor_top = 0.0
		corner.anchor_bottom = 0.0
		corner.offset_left = -23.0
		corner.offset_right = -3.0
		corner.offset_top = 3.0
		corner.offset_bottom = 24.0

		add_child(corner)
		add_joker_copy_badge()

	func add_joker_copy_badge() -> void:
		if not game.is_joker(card):
			return

		if game.card_rank(card) < 2:
			tooltip_text = "Джокер ещё ничего не скопировал"
			return

		var copy_value: String = game.joker_copy_label(card)
		tooltip_text = "ДЖОКЕР СКОПИРОВАЛ: " + copy_value

		var suit: String = game.card_suit(card)
		var accent: Color = Color("#E3B9FF")

		match suit:
			"♥":
				accent = Color("#FF5C6C")
			"♦":
				accent = Color("#53E4FF")
			"♣":
				accent = Color("#C879FF")
			"♠":
				accent = Color("#FF6BD7")
			_:
				if game.card_rank(card) == 100:
					accent = Color("#E5C26A")

		var badge: PanelContainer = PanelContainer.new()
		badge.name = "JokerCopiedValue"
		badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		badge.anchor_left = 0.03
		badge.anchor_right = 0.97
		badge.anchor_top = 0.66
		badge.anchor_bottom = 0.97
		badge.offset_left = 0
		badge.offset_right = 0
		badge.offset_top = 0
		badge.offset_bottom = 0

		badge.add_theme_stylebox_override(
			"panel",
			game.make_style(
				Color(0.06, 0.02, 0.11, 0.97),
				accent,
				7
			)
		)

		add_child(badge)

		var content: VBoxContainer = VBoxContainer.new()
		content.name = "CopyInfo"
		content.mouse_filter = Control.MOUSE_FILTER_IGNORE
		content.add_theme_constant_override("separation", 0)
		badge.add_child(content)

		var heading: Label = game.make_label(
			"КОПИЯ",
			9,
			game.LIGHT
		)
		heading.name = "CopyTitle"
		heading.mouse_filter = Control.MOUSE_FILTER_IGNORE
		heading.autowrap_mode = TextServer.AUTOWRAP_OFF
		content.add_child(heading)

		var big_value: Label = game.make_label(
			copy_value,
			15 if game.card_rank(card) != 100 else 12,
			accent
		)

		big_value.name = "CopiedCard"
		big_value.mouse_filter = Control.MOUSE_FILTER_IGNORE
		big_value.autowrap_mode = TextServer.AUTOWRAP_OFF
		content.add_child(big_value)

	func _hover(active: bool) -> void:
		# On touchscreens an artificial hover scale could move the card
		# outside its slot or make a defended pair look misaligned.
		if not is_inside_tree() or role != "hand":
			return
		if DisplayServer.is_touchscreen_available():
			return
		pivot_offset = size / 2.0
		var tween: Tween = create_tween()
		tween.tween_property(
			self, "scale",
			Vector2(1.02, 1.02) if active else Vector2.ONE,
			0.12
		)

	func _draw() -> void:
		if game.card_face_texture(card) != null:
			return

		if card.is_empty():
			return

		var font: Font = get_theme_default_font()
		var rank: String = str(
			game.rank_name(game.card_rank(card))
		)
		var suit: String = str(game.card_suit(card))
		var ink: Color = Color("#251530")

		if suit == "♥" or suit == "♦":
			ink = Color("#D82E57")

		if game.is_mark(card):
			rank = "М"
			suit = "✦"
			ink = Color("#8732C8")

		if game.is_joker(card):
			rank = "J"
			suit = "★"

			if game.card_rank(card) == 100:
				ink = Color("#8732C8")
			elif game.card_rank(card) >= 2:
				ink = (
					Color("#D82E57")
					if (
						game.card_suit(card) == "♥"
						or game.card_suit(card) == "♦"
					)
					else Color("#251530")
				)
			elif str(card.get("joker_color", "")) == "red":
				ink = Color("#D82E57")
			else:
				ink = Color("#251530")

		var factor: float = size.x / 74.0
		var small_size: int = maxi(
			13, int(19.0 * factor)
		)

		draw_string(
			font,
			Vector2(7.0, 22.0 * factor),
			rank,
			HORIZONTAL_ALIGNMENT_LEFT,
			-1,
			small_size,
			ink
		)

		if not game.is_special(card):
			var caption: String = game.suit_short_name(suit)
			var caption_size: int = maxi(
				9, int(11.0 * factor)
			)

			var caption_width: float = (
				font.get_string_size(
					caption,
					HORIZONTAL_ALIGNMENT_LEFT,
					-1,
					caption_size
				).x
			)

			draw_string(
				font,
				Vector2(
					maxf(
						2.0,
						(size.x - caption_width) * 0.5
					),
					size.y - 7.0
				),
				caption,
				HORIZONTAL_ALIGNMENT_LEFT,
				-1,
				caption_size,
				ink
			)

	func _get_drag_data(_position: Vector2) -> Variant:
		if role != "hand" or game.finished or game.animation_busy:
			return null

		# Preview is a real playing card. The source hand card remains
		# in place until the drop is accepted by a table slot.
		var preview: PanelContainer = PanelContainer.new()
		preview.name = "DraggedCardPreview"
		preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var pw: float = maxf(84.0, game.card_width * 1.16)
		var ph: float = maxf(118.0, game.card_height * 1.16)
		preview.custom_minimum_size = Vector2(pw, ph)
		preview.size = Vector2(pw, ph)
		var frame: StyleBoxFlat = game.make_style(
			Color("#080311"), game.VIOLET, 8
		)
		frame.set_content_margin_all(0)
		frame.set_border_width_all(2)
		preview.add_theme_stylebox_override("panel", frame)

		var art: Texture2D = game.card_face_texture(card)
		if art != null:
			var face: TextureRect = TextureRect.new()
			face.name = "DraggedCardArtwork"
			face.texture = art
			face.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			face.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			face.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
			face.mouse_filter = Control.MOUSE_FILTER_IGNORE
			preview.add_child(face)
			face.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		else:
			var fallback: Label = game.make_label(
				game.card_name(card), 15, game.LIGHT
			)
			fallback.mouse_filter = Control.MOUSE_FILTER_IGNORE
			preview.add_child(fallback)
			fallback.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

		preview.modulate.a = 0.96
		set_drag_preview(preview)
		return {
			"type": "hand_card",
			"index": hand_index
		}

	func _can_drop_data(
		_position: Vector2,
		data: Variant
	) -> bool:
		if role == "hand" or typeof(data) != TYPE_DICTIONARY:
			return false

		if data.get("type", "") != "hand_card":
			return false

		var slot_id: int = game.slot_for_pair(pair_index)

		return game.can_drop_on_slot(
			int(data.get("index", -1)),
			slot_id
		)

	func _drop_data(
		_position: Vector2,
		data: Variant
	) -> void:
		game.place_in_slot(
			int(data["index"]),
			game.slot_for_pair(pair_index)
		)


class TableSlot extends Control:
	var game
	var slot_id: int = 0
	var hover: bool = false

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP
		mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		mouse_entered.connect(_on_hover.bind(true))
		mouse_exited.connect(_on_hover.bind(false))

	func _on_hover(active: bool) -> void:
		hover = active
		queue_redraw()

	func _draw() -> void:
		if game == null:
			return

		if (
			game.selected_index < 0
			or game.selected_index >= game.player_hand.size()
		):
			return

		if not game.can_drop_on_slot(
			game.selected_index,
			slot_id
		):
			return

		var color: Color = (
			game.GOLD if hover else game.VIOLET
		)

		draw_rect(
			Rect2(Vector2.ZERO, size),
			color,
			false,
			2.0
		)

	func _gui_input(event: InputEvent) -> void:
		if event is InputEventMouseButton:
			if (
				event.button_index == MOUSE_BUTTON_LEFT
				and event.pressed
			):
				game.place_selected_on_slot(slot_id)
				accept_event()

	func _can_drop_data(
		_position: Vector2,
		data: Variant
	) -> bool:
		return (
			typeof(data) == TYPE_DICTIONARY
			and data.get("type", "") == "hand_card"
			and game.can_drop_on_slot(
				int(data.get("index", -1)),
				slot_id
			)
		)

	func _drop_data(
		_position: Vector2,
		data: Variant
	) -> void:
		game.place_in_slot(
			int(data["index"]),
			slot_id
		)


class GameField extends PanelContainer:
	var game

	func _can_drop_data(
		_position: Vector2,
		_data: Variant
	) -> bool:
		return false


func _ready() -> void:
	randomize()
	load_profile()
	load_saved_avatar()

	set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	create_interface()
	# Count only real playing time; SceneTree pause suspends this callback.
	set_process(true)

	get_viewport().size_changed.connect(
		adapt_layout
	)

	show_menu()
	adapt_layout()


func _process(delta: float) -> void:
	if (
		game_screen == null
		or not game_screen.visible
		or finished
		or is_game_paused
		or animation_busy
	):
		return

	elapsed_game_seconds += delta
	if timer_label != null:
		timer_label.text = format_game_time(elapsed_game_seconds)


func format_game_time(seconds: float) -> String:
	var whole: int = maxi(0, int(seconds))
	var hours: int = whole / 3600
	var minutes: int = (whole / 60) % 60
	var remaining: int = whole % 60
	if hours > 0:
		return "%02d:%02d:%02d" % [hours, minutes, remaining]
	return "%02d:%02d" % [minutes, remaining]


func make_style(
	background: Color,
	border: Color,
	radius: int = 12
) -> StyleBoxFlat:
	var style_box: StyleBoxFlat = StyleBoxFlat.new()

	style_box.bg_color = background
	style_box.border_color = border
	style_box.set_border_width_all(2)
	style_box.set_corner_radius_all(radius)

	style_box.content_margin_left = 6
	style_box.content_margin_right = 6
	style_box.content_margin_top = 6
	style_box.content_margin_bottom = 6

	return style_box


func make_label(
	value: String,
	font_size: int = 16,
	color: Color = LIGHT
) -> Label:
	var result: Label = Label.new()

	result.text = value
	result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	result.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

	result.add_theme_font_size_override(
		"font_size",
		font_size
	)
	result.add_theme_color_override(
		"font_color",
		color
	)

	return result


func make_button(
	value: String,
	callback: Callable
) -> Button:
	var button: Button = Button.new()

	button.text = value
	button.custom_minimum_size = Vector2(0, 46)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL

	button.add_theme_stylebox_override(
		"normal",
		make_style(Color("#48216E"), VIOLET)
	)

	button.add_theme_stylebox_override(
		"hover",
		make_style(Color("#7137A7"), GOLD)
	)

	button.add_theme_color_override(
		"font_color",
		LIGHT
	)
	button.add_theme_font_size_override(
		"font_size",
		15
	)

	button.pressed.connect(callback)
	return button


func make_card_back(
	width: float = 49.0,
	height: float = 66.0
) -> PanelContainer:
	var back: PanelContainer = PanelContainer.new()
	back.custom_minimum_size = Vector2(width, height)
	back.mouse_filter = Control.MOUSE_FILTER_IGNORE

	back.add_theme_stylebox_override(
		"panel",
		make_style(
			Color("#51218C"),
			Color("#E2B6FF"),
			9
		)
	)

	var symbol: Label = make_label("✦\nJS", 13, GOLD)
	symbol.mouse_filter = Control.MOUSE_FILTER_IGNORE
	back.add_child(symbol)

	return back


func refresh_enemy_backs() -> void:
	if enemy_backs == null:
		return

	var key: String = (
		str(bot_hand.size())
		+ "|"
		+ str(snapped(card_width, 1.0))
	)

	if key == last_enemy_visual_key:
		return

	last_enemy_visual_key = key
	clear_children(enemy_backs)

	var back_width: float = clampf(
		card_width * 0.62,
		32.0,
		58.0
	)

	for i in range(bot_hand.size()):
		var back: PanelContainer = make_card_back(
			back_width,
			back_width * 1.34
		)
		back.name = "EnemyBack_%d" % i
		enemy_backs.add_child(back)


func clear_children(node: Node) -> void:
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()


func animate_in(
	node: Control,
	delay: float = 0.0
) -> void:
	node.modulate.a = 0.0
	var tween: Tween = create_tween()

	tween.tween_property(
		node,
		"modulate:a",
		1.0,
		0.20
	).set_delay(delay)


func pulse(node: Control) -> void:
	if node == null:
		return

	var tween: Tween = create_tween()

	tween.tween_property(
		node,
		"modulate",
		Color("#D8B2FF"),
		0.12
	)
	tween.tween_property(
		node,
		"modulate",
		Color.WHITE,
		0.18
	)


func create_interface() -> void:
	var background: ColorRect = ColorRect.new()
	background.color = BG

	background.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background)

	create_menu()
	create_game_screen()
	create_dialogs()
	create_pause_overlay()


func card_face_key(card: Dictionary) -> String:
	if is_joker(card):
		return "joker_black" if str(card.get("joker_color", "")) == "black" else "joker_red"
	if is_mark(card):
		return "mark"

	var rank: int = card_rank(card)
	if rank < 2 or rank > 14:
		return ""
	var prefix: String = ""
	match card_suit(card):
		"♥":
			prefix = "h"
		"♦":
			prefix = "d"
		"♣":
			prefix = "c"
		"♠":
			prefix = "s"
		_:
			return ""
	return prefix + "_" + str(rank)


func card_face_texture(card: Dictionary) -> Texture2D:
	var key: String = card_face_key(card)
	if key.is_empty():
		return null

	var draw_width: int = maxi(32, roundi(card_width))
	var draw_height: int = maxi(48, roundi(card_height))
	var cache_key: String = key + ":" + str(draw_width) + "x" + str(draw_height)
	if face_texture_cache.has(cache_key):
		return face_texture_cache[cache_key] as Texture2D

	# Do not use AtlasTexture: the older GL renderer could render
	# several neighbouring atlas tiles in one card.
	var source: Image
	if face_image_cache.has(key):
		source = face_image_cache[key] as Image
	else:
		var path: String = CARD_FACES_DIR + key + ".png"
		if not ResourceLoader.exists(path):
			return null
		var original_texture: Texture2D = load(path) as Texture2D
		if original_texture == null:
			return null
		source = original_texture.get_image()
		if source == null or source.is_empty():
			return null
		face_image_cache[key] = source

	# High quality downsampling ONCE instead of repeated GPU stretch.
	# Keep the actual proportions of the uploaded card art. Do not stretch it.
	var picture: Image = source.duplicate() as Image
	var original_width: int = picture.get_width()
	var original_height: int = picture.get_height()
	var scale_factor: float = minf(
		float(draw_width) / float(original_width),
		float(draw_height) / float(original_height)
	)
	var fitted_width: int = maxi(1, roundi(float(original_width) * scale_factor))
	var fitted_height: int = maxi(1, roundi(float(original_height) * scale_factor))
	picture.resize(fitted_width, fitted_height, Image.INTERPOLATE_LANCZOS)
	picture.convert(Image.FORMAT_RGBA8)
	var canvas: Image = Image.create(draw_width, draw_height, false, Image.FORMAT_RGBA8)
	canvas.fill(Color("#010005"))
	canvas.blit_rect(
		picture,
		Rect2i(0, 0, fitted_width, fitted_height),
		Vector2i(
			int((draw_width - fitted_width) / 2),
			int((draw_height - fitted_height) / 2)
		)
	)
	var texture: ImageTexture = ImageTexture.create_from_image(canvas)
	face_texture_cache[cache_key] = texture
	return texture


func defender_attack_limit() -> int:
	var available: int = (
		bot_hand.size()
		if attacker == 0
		else player_hand.size()
	)

	var defended: int = 0

	for pair in table_cards:
		if not pair["defense"].is_empty():
			defended += 1

	return mini(
		round_limit(),
		maxi(
			table_cards.size(),
			available + defended
		)
	)


func make_style_avatar_box(side: int) -> PanelContainer:
	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(side, side)
	panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER

	panel.add_theme_stylebox_override(
		"panel",
		make_style(
			Color("#381957"),
			GOLD,
			14
		)
	)

	return panel


func create_avatar_holder(
	side: int,
	is_menu: bool
) -> Control:
	var holder: Control = Control.new()
	holder.custom_minimum_size = Vector2(side, side)
	holder.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	holder.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	holder.clip_contents = true

	var picture: TextureRect = TextureRect.new()
	picture.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)
	picture.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	picture.stretch_mode = (
		TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	)
	picture.mouse_filter = Control.MOUSE_FILTER_IGNORE

	holder.add_child(picture)
	picture.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	var placeholder: Label = make_label("JS", 21, GOLD)
	placeholder.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)
	placeholder.mouse_filter = Control.MOUSE_FILTER_IGNORE

	holder.add_child(placeholder)
	placeholder.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	if is_menu:
		avatar_preview = picture
		avatar_placeholder_menu = placeholder
	else:
		avatar_game = picture
		avatar_placeholder_game = placeholder

	refresh_avatar_views()
	return holder


func refresh_avatar_views() -> void:
	if avatar_preview != null:
		avatar_preview.texture = avatar_texture

	if avatar_game != null:
		avatar_game.texture = avatar_texture

	if avatar_placeholder_menu != null:
		avatar_placeholder_menu.visible = (
			avatar_texture == null
		)

	if avatar_placeholder_game != null:
		avatar_placeholder_game.visible = (
			avatar_texture == null
		)


func load_profile() -> void:
	var config: ConfigFile = ConfigFile.new()

	if config.load(PROFILE_SAVE_PATH) != OK:
		return

	player_nick = str(
		config.get_value(
			"player",
			"nickname",
			"Игрок"
		)
	)

	bot_difficulty = clampi(
		int(
			config.get_value(
				"game",
				"difficulty",
				1
			)
		),
		0,
		2
	)


func save_profile() -> void:
	var config: ConfigFile = ConfigFile.new()
	config.set_value("player", "nickname", player_nick)
	config.set_value("game", "difficulty", bot_difficulty)
	config.save(PROFILE_SAVE_PATH)


func on_difficulty_changed(index: int) -> void:
	bot_difficulty = clampi(index, 0, 2)
	save_profile()


func load_saved_avatar() -> void:
	if not FileAccess.file_exists(AVATAR_SAVE_PATH):
		return

	var img: Image = Image.new()

	if (
		img.load(AVATAR_SAVE_PATH) == OK
		and not img.is_empty()
	):
		avatar_texture = ImageTexture.create_from_image(img)


func open_avatar_picker() -> void:
	if avatar_dialog != null:
		avatar_dialog.popup_centered_ratio(0.85)


func on_avatar_file_selected(path: String) -> void:
	var file: FileAccess = FileAccess.open(
		path,
		FileAccess.READ
	)

	if file == null:
		OS.alert(
			"Не удалось открыть фото. Выбери JPG или PNG.",
			"JokerShift"
		)
		return

	if file.get_length() > MAX_AVATAR_FILE_BYTES:
		file.close()
		OS.alert(
			"Фото слишком большое (максимум 8 МБ).",
			"JokerShift"
		)
		return

	var data: PackedByteArray = file.get_buffer(
		file.get_length()
	)
	file.close()

	var img: Image = Image.new()
	var ext: String = path.get_extension().to_lower()
	var err: Error = ERR_FILE_UNRECOGNIZED

	match ext:
		"png":
			err = img.load_png_from_buffer(data)
		"jpg", "jpeg":
			err = img.load_jpg_from_buffer(data)
		"webp":
			err = img.load_webp_from_buffer(data)

	if err != OK or img.is_empty():
		OS.alert(
			"Не удалось прочитать изображение. Подходит JPG, PNG или WebP.",
			"JokerShift"
		)
		return

	var longest: int = maxi(
		img.get_width(),
		img.get_height()
	)

	if longest > MAX_AVATAR_SIDE:
		var scale_factor: float = (
			float(MAX_AVATAR_SIDE) / float(longest)
		)

		img.resize(
			maxi(
				1,
				int(img.get_width() * scale_factor)
			),
			maxi(
				1,
				int(img.get_height() * scale_factor)
			),
			Image.INTERPOLATE_LANCZOS
		)

	if img.save_png(AVATAR_SAVE_PATH) != OK:
		OS.alert(
			"Не удалось сохранить аватарку.",
			"JokerShift"
		)
		return

	avatar_texture = ImageTexture.create_from_image(img)
	refresh_avatar_views()


func clear_avatar() -> void:
	avatar_texture = null

	if FileAccess.file_exists(AVATAR_SAVE_PATH):
		DirAccess.remove_absolute(
			ProjectSettings.globalize_path(
				AVATAR_SAVE_PATH
			)
		)

	refresh_avatar_views()


func create_menu() -> void:
	menu_screen = Control.new()
	menu_screen.name = "MainMenu"
	menu_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(menu_screen)

	var background: TextureRect = TextureRect.new()
	background.name = "MenuBackground"
	background.texture = load("res://assets/menu_background.png") as Texture2D
	background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_screen.add_child(background)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.name = "MenuScroll"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	menu_screen.add_child(scroll)
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var margin: MarginContainer = MarginContainer.new()
	margin.name = "MenuMargins"
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	scroll.add_child(margin)

	var centered: CenterContainer = CenterContainer.new()
	centered.name = "MenuCenter"
	centered.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	centered.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	margin.add_child(centered)

	menu_panel = PanelContainer.new()
	menu_panel.name = "MenuPanel"
	menu_panel.custom_minimum_size = Vector2(
		minf(456.0, maxf(270.0, get_viewport_rect().size.x - 36.0)),
		0
	)
	menu_panel.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	menu_panel.add_theme_stylebox_override(
		"panel", make_style(Color("#241137"), Color("#8D4FCD"), 22)
	)
	centered.add_child(menu_panel)

	var body: VBoxContainer = VBoxContainer.new()
	body.name = "MenuContent"
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 11)
	menu_panel.add_child(body)

	# Large game crest and lobby heading.
	var hero: HBoxContainer = HBoxContainer.new()
	hero.alignment = BoxContainer.ALIGNMENT_CENTER
	hero.add_theme_constant_override("separation", 8)
	body.add_child(hero)

	var logo: TextureRect = TextureRect.new()
	logo.name = "MenuLogo"
	logo.texture = load("res://assets/jokershift_icon.png") as Texture2D
	logo.custom_minimum_size = Vector2(76, 76)
	logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hero.add_child(logo)

	var branding: VBoxContainer = VBoxContainer.new()
	branding.add_theme_constant_override("separation", 2)
	hero.add_child(branding)
	var brand_title: Label = make_label("JOKERSHIFT", 25, GOLD)
	brand_title.autowrap_mode = TextServer.AUTOWRAP_OFF
	branding.add_child(brand_title)
	branding.add_child(make_label("КАРТЫ • ДЖОКЕРЫ • ПОБЕДА", 11, Color("#B98FD2")))

	var separator: ColorRect = ColorRect.new()
	separator.color = Color("#7746A6")
	separator.custom_minimum_size = Vector2(0, 2)
	separator.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_child(separator)

	var profile_label: Label = make_label("ТВОЙ ПРОФИЛЬ", 12, Color("#CBA2EB"))
	profile_label.name = "ProfileCaption"
	body.add_child(profile_label)

	var profile: HBoxContainer = HBoxContainer.new()
	profile.alignment = BoxContainer.ALIGNMENT_CENTER
	profile.add_theme_constant_override("separation", 10)
	body.add_child(profile)

	var avatar_box: PanelContainer = make_style_avatar_box(68)
	avatar_box.name = "MenuAvatarBox"
	avatar_box.add_child(create_avatar_holder(64, true))
	profile.add_child(avatar_box)

	var profile_input: VBoxContainer = VBoxContainer.new()
	profile_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	profile.add_child(profile_input)
	nick_input = LineEdit.new()
	nick_input.name = "NicknameInput"
	nick_input.placeholder_text = "Имя игрока"
	nick_input.text = player_nick
	nick_input.max_length = 18
	nick_input.keep_editing_on_text_submit = false
	nick_input.custom_minimum_size = Vector2(180, 42)
	nick_input.add_theme_font_size_override("font_size", 17)
	profile_input.add_child(nick_input)
	profile_input.add_child(make_label("Игра без интернета", 11, Color("#B18AC8")))

	var avatar_actions: HBoxContainer = HBoxContainer.new()
	avatar_actions.name = "AvatarActions"
	avatar_actions.add_theme_constant_override("separation", 7)
	body.add_child(avatar_actions)
	var avatar_choose: Button = make_button("Фото профиля", open_avatar_picker)
	avatar_choose.name = "AvatarChooseButton"
	avatar_choose.custom_minimum_size.y = 36
	avatar_actions.add_child(avatar_choose)
	var avatar_reset: Button = make_button("Убрать фото", clear_avatar)
	avatar_reset.name = "AvatarResetButton"
	avatar_reset.custom_minimum_size.y = 36
	avatar_actions.add_child(avatar_reset)

	var difficulty_caption: Label = make_label("СЛОЖНОСТЬ КОМПЬЮТЕРА", 12, GOLD)
	difficulty_caption.name = "DifficultyCaption"
	body.add_child(difficulty_caption)
	difficulty_select = OptionButton.new()
	difficulty_select.name = "DifficultySelect"
	difficulty_select.add_item("Лёгкая", 0)
	difficulty_select.add_item("Средняя", 1)
	difficulty_select.add_item("Сложная", 2)
	difficulty_select.select(clampi(bot_difficulty, 0, 2))
	difficulty_select.custom_minimum_size = Vector2(0, 43)
	difficulty_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	difficulty_select.item_selected.connect(on_difficulty_changed)
	body.add_child(difficulty_select)

	var play: Button = make_button("▶   ИГРАТЬ", start_game)
	play.name = "PlayButton"
	play.custom_minimum_size.y = 62
	play.add_theme_font_size_override("font_size", 24)
	play.add_theme_stylebox_override(
		"normal", make_style(Color("#7026BC"), Color("#DDB8FF"), 15)
	)
	play.add_theme_stylebox_override(
		"hover", make_style(Color("#9840E0"), Color.WHITE, 15)
	)
	body.add_child(play)

	# Visible multiplayer entry point, with an honest coming-soon state.
	# It must NOT start a local match or pretend online play works.
	var play_online: Button = make_button(
		"", show_coming_soon.bind("Игра онлайн")
	)
	play_online.name = "PlayOnlineButton"
	play_online.custom_minimum_size.y = 65
	play_online.add_theme_stylebox_override(
		"normal", make_style(Color("#311B49"), Color("#8E5BAB"), 15)
	)
	play_online.add_theme_stylebox_override(
		"hover", make_style(Color("#4D2B69"), Color("#CE93F9"), 15)
	)
	body.add_child(play_online)
	# Separate lines prevent Button's built-in text layout from clipping
	# the "in development" marker on Android and narrow screens.
	var online_content: VBoxContainer = VBoxContainer.new()
	online_content.name = "OnlineButtonContent"
	online_content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	online_content.alignment = BoxContainer.ALIGNMENT_CENTER
	online_content.add_theme_constant_override("separation", 0)
	play_online.add_child(online_content)
	online_content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var online_title: Label = make_label(
		"🌐  ИГРАТЬ ОНЛАЙН", 16, Color("#F0DDFF")
	)
	online_title.name = "OnlinePlayTitle"
	online_title.autowrap_mode = TextServer.AUTOWRAP_OFF
	online_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	online_content.add_child(online_title)
	var online_notice: Label = make_label(
		"✦  В РАЗРАБОТКЕ  ✦", 11, Color("#BF9CD9")
	)
	online_notice.name = "OnlinePlayNotice"
	online_notice.autowrap_mode = TextServer.AUTOWRAP_OFF
	online_notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
	online_content.add_child(online_notice)

	var features_caption: Label = make_label("РАЗДЕЛЫ", 12, GOLD)
	features_caption.name = "FeaturesCaption"
	body.add_child(features_caption)
	var feature_grid: GridContainer = GridContainer.new()
	feature_grid.name = "FeatureGrid"
	feature_grid.columns = 2
	feature_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	feature_grid.add_theme_constant_override("h_separation", 8)
	feature_grid.add_theme_constant_override("v_separation", 8)
	body.add_child(feature_grid)

	var coming_features: Array[String] = [
		"Достижения", "Предметы", "Друзья",
		"Доска почёта", "Новости"
	]
	var symbols: Array[String] = ["★", "✦", "♣", "♛", "✉"]
	for i in range(coming_features.size()):
		var feature: String = coming_features[i]
		var callback: Callable = (
			show_news if feature == "Новости"
			else show_coming_soon.bind(feature)
		)
		var feature_button: Button = make_button(
			symbols[i] + "  " + feature,
			callback
		)
		feature_button.name = "Feature_" + str(i)
		feature_button.custom_minimum_size = Vector2(0, 54)
		feature_button.add_theme_font_size_override("font_size", 14)
		feature_grid.add_child(feature_button)

	var rules_button: Button = make_button("ⓘ  ПРАВИЛА", show_rules)
	rules_button.name = "MenuRulesButton"
	rules_button.custom_minimum_size.y = 54
	feature_grid.add_child(rules_button)
	var footer: Label = make_label("✦  ПРОЕКТ В РАЗВИТИИ  ✦", 11, Color("#AD83C6"))
	footer.name = "MenuFooter"
	body.add_child(footer)
	var more_button: Button = make_button("☰  ДОПОЛНИТЕЛЬНО", show_mobile_more)
	more_button.name = "MobileMoreButton"
	more_button.custom_minimum_size.y = 44
	more_button.hide()
	body.add_child(more_button)


func show_mobile_more() -> void:
	if mobile_more_dialog == null:
		return
	var viewport_size: Vector2 = get_viewport_rect().size
	mobile_more_dialog.popup_centered(Vector2i(
		int(minf(410.0, viewport_size.x - 20.0)),
		int(minf(510.0, viewport_size.y - 30.0))
	))


func mobile_more_action(name: String) -> void:
	if mobile_more_dialog != null:
		mobile_more_dialog.hide()
	match name:
		"Фото профиля":
			open_avatar_picker()
		"Убрать фото":
			clear_avatar()
		"Новости":
			show_news()
		"Правила":
			show_rules()
		_:
			show_coming_soon(name)


func show_news() -> void:
	if news_dialog == null:
		return
	var viewport: Vector2 = get_viewport_rect().size
	news_dialog.popup_centered(Vector2i(
		int(minf(480.0, maxf(300.0, viewport.x - 24.0))),
		int(minf(360.0, maxf(240.0, viewport.y - 24.0)))
	))


func open_telegram_news() -> void:
	# Only run on an explicit click on the news dialog's action button.
	var error: Error = OS.shell_open(TELEGRAM_NEWS_URL)
	if error != OK:
		OS.alert(
			"Не удалось открыть Telegram. Адрес канала: " + TELEGRAM_NEWS_URL,
			"Новости JokerShift"
		)


func show_coming_soon(feature: String) -> void:
	if coming_soon_dialog == null:
		return
	coming_soon_dialog.title = feature
	coming_soon_dialog.dialog_text = (
		"✦  В РАЗРАБОТКЕ  ✦\n\n"
		+ "Раздел «" + feature + "» пока в процессе.\n"
		+ "Мы добавим его в одном из будущих обновлений."
	)
	coming_soon_dialog.popup_centered(Vector2i(390, 190))


# ==========================================
# PREMIUM PAUSE MENU — TIMER AND GAMEPLAY FREEZE
# ==========================================

func create_pause_overlay() -> void:
	pause_overlay = Control.new()
	pause_overlay.name = "PauseOverlay"
	pause_overlay.process_mode = Node.PROCESS_MODE_ALWAYS
	pause_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(pause_overlay)
	pause_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_overlay.hide()

	var backdrop: ColorRect = ColorRect.new()
	backdrop.name = "PauseShade"
	backdrop.color = Color(0.055, 0.008, 0.098, 0.91)
	backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	pause_overlay.add_child(backdrop)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# The content scrolls on short landscape phone screens.
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.name = "PauseScroll"
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	pause_overlay.add_child(scroll)
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var centered: CenterContainer = CenterContainer.new()
	centered.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	centered.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.add_child(centered)

	var card: PanelContainer = PanelContainer.new()
	card.name = "PauseCard"
	card.custom_minimum_size = Vector2(
		minf(352.0, maxf(265.0, get_viewport_rect().size.x - 30.0)), 0.0
	)
	card.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	card.add_theme_stylebox_override(
		"panel", make_style(Color("#231134"), Color("#B473F6"), 22)
	)
	centered.add_child(card)

	var body: VBoxContainer = VBoxContainer.new()
	body.name = "PauseOptions"
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 9)
	card.add_child(body)

	var crest: Label = make_label("✦  🃏  ✦", 30, Color("#F0BFFF"))
	body.add_child(crest)
	var heading: Label = make_label("ПАУЗА", 30, Color("#F6D4FF"))
	heading.autowrap_mode = TextServer.AUTOWRAP_OFF
	body.add_child(heading)
	body.add_child(make_label("Партия остановлена", 13, Color("#CDA3E8")))

	# Single-column stopwatch card: a horizontal row was compressing
	# "ВРЕМЯ" into one letter per line at smaller window widths.
	var time_panel: PanelContainer = PanelContainer.new()
	time_panel.name = "PauseTimePanel"
	time_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	time_panel.add_theme_stylebox_override(
		"panel", make_style(Color("#160B2A"), Color("#A86CDF"), 16)
	)
	body.add_child(time_panel)

	var time_column: VBoxContainer = VBoxContainer.new()
	time_column.name = "PauseTimeContent"
	time_column.add_theme_constant_override("separation", 1)
	time_panel.add_child(time_column)

	var time_caption: Label = make_label("◷  ВРЕМЯ ПАРТИИ", 13, GOLD)
	time_caption.name = "PauseTimeCaption"
	time_caption.autowrap_mode = TextServer.AUTOWRAP_OFF
	time_caption.custom_minimum_size.y = 24
	time_caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	time_column.add_child(time_caption)

	pause_timer_label = make_label("00:00", 36, Color("#FFFFFF"))
	pause_timer_label.name = "PauseStopwatch"
	pause_timer_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	pause_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_timer_label.custom_minimum_size.y = 51
	pause_timer_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pause_timer_label.add_theme_color_override("font_outline_color", Color("#4A216D"))
	pause_timer_label.add_theme_constant_override("outline_size", 2)
	time_column.add_child(pause_timer_label)

	var time_hint: Label = make_label(
		"ТАЙМЕР ОСТАНОВЛЕН", 10, Color("#B78DCE")
	)
	time_hint.name = "PauseTimeHint"
	time_hint.autowrap_mode = TextServer.AUTOWRAP_OFF
	time_hint.custom_minimum_size.y = 18
	time_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	time_column.add_child(time_hint)

	var line: ColorRect = ColorRect.new()
	line.color = Color("#8050A7")
	line.custom_minimum_size = Vector2(0, 2)
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_child(line)

	var keep_playing: Button = make_button("▶  ПРОДОЛЖИТЬ", resume_game)
	keep_playing.name = "PauseContinue"
	keep_playing.custom_minimum_size.y = 48
	keep_playing.add_theme_stylebox_override(
		"normal", make_style(Color("#6730B5"), Color("#F0B8FF"), 12)
	)
	body.add_child(keep_playing)

	var restart: Button = make_button("↻  НАЧАТЬ ЗАНОВО", restart_from_pause)
	restart.name = "PauseRestart"
	restart.custom_minimum_size.y = 44
	body.add_child(restart)

	var rules: Button = make_button("ⓘ  ПРАВИЛА", show_rules)
	rules.name = "PauseRules"
	rules.custom_minimum_size.y = 44
	body.add_child(rules)

	var home: Button = make_button("⌂  ГЛАВНОЕ МЕНЮ", menu_from_pause)
	home.name = "PauseHome"
	home.custom_minimum_size.y = 44
	body.add_child(home)

	body.add_child(make_label("✦ JOKERSHIFT ✦", 11, Color("#AB80CA")))


func pause_game() -> void:
	if (
		is_game_paused or finished
		or game_screen == null or not game_screen.visible
	):
		return
	is_game_paused = true
	pause_timer_label.text = format_game_time(elapsed_game_seconds)
	pause_overlay.show()
	pause_overlay.move_to_front()
	pause_overlay.modulate.a = 0.0
	get_tree().paused = true
	var t: Tween = pause_overlay.create_tween()
	t.tween_property(pause_overlay, "modulate:a", 1.0, 0.19)


func resume_game() -> void:
	# Restore processing before hiding the modal; the next frame can continue.
	get_tree().paused = false
	is_game_paused = false
	if pause_overlay != null:
		pause_overlay.hide()
		pause_overlay.modulate.a = 1.0


func restart_from_pause() -> void:
	resume_game()
	new_game()


func menu_from_pause() -> void:
	resume_game()
	show_menu()


func show_menu() -> void:
	if is_game_paused or get_tree().paused:
		resume_game()
	pending_replacement.clear()

	if replace_confirmation != null:
		replace_confirmation.hide()

	clear_finale()
	animation_serial += 1
	animation_busy = false

	if motion_layer != null:
		clear_children(motion_layer)

	if hand_row != null:
		hand_row.modulate.a = 1.0

	if enemy_backs != null:
		enemy_backs.modulate.a = 1.0

	if table_grid != null:
		table_grid.modulate.a = 1.0

	game_screen.hide()
	menu_screen.show()
	adapt_layout()
	animate_in(menu_screen)


func start_game() -> void:
	player_nick = nick_input.text.strip_edges()

	if player_nick.is_empty():
		player_nick = "Игрок"

	bot_difficulty = difficulty_select.selected
	save_profile()

	menu_screen.hide()
	game_screen.show()
	new_game()


func create_game_screen() -> void:
	game_screen = Control.new()
	game_screen.name = "GameScreen"
	game_screen.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)
	add_child(game_screen)

	animation_enabled = (
		DisplayServer.get_name() != "headless"
	)

	motion_layer = Control.new()
	motion_layer.name = "CardMotionLayer"
	motion_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	game_screen.add_child(motion_layer)
	motion_layer.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	var screen_scroll: ScrollContainer = ScrollContainer.new()
	screen_scroll.name = "GameScroll"
	screen_scroll.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)
	screen_scroll.horizontal_scroll_mode = (
		ScrollContainer.SCROLL_MODE_DISABLED
	)
	screen_scroll.vertical_scroll_mode = (
		ScrollContainer.SCROLL_MODE_AUTO
	)
	screen_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	screen_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	game_screen.add_child(screen_scroll)

	var margin: MarginContainer = MarginContainer.new()
	margin.name = "GameMargins"
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	margin.size_flags_vertical = Control.SIZE_EXPAND_FILL
	# A hard 585px floor forced horizontal phones to scroll before
	# the hand was visible, even if the actual content was smaller.
	margin.custom_minimum_size = Vector2.ZERO
	screen_scroll.add_child(margin)

	margin.add_theme_constant_override(
		"margin_left",
		6
	)
	margin.add_theme_constant_override(
		"margin_right",
		6
	)
	margin.add_theme_constant_override(
		"margin_top",
		6
	)
	margin.add_theme_constant_override(
		"margin_bottom",
		6
	)

	var root: VBoxContainer = VBoxContainer.new()
	root.name = "GameRoot"
	root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	root.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_theme_constant_override(
		"separation",
		6
	)
	margin.add_child(root)

	var top: HBoxContainer = HBoxContainer.new()
	top.name = "TopBar"
	root.add_child(top)

	var title: Label = make_label(
		"🃏 JokerShift",
		21,
		GOLD
	)
	title.name = "GameTitle"
	title.autowrap_mode = TextServer.AUTOWRAP_OFF
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(title)

	# Compact stopwatch chip, same design language as the pause card.
	var clock_panel: PanelContainer = PanelContainer.new()
	clock_panel.name = "StopwatchPanel"
	clock_panel.custom_minimum_size = Vector2(110, 46)
	clock_panel.size_flags_horizontal = Control.SIZE_SHRINK_END
	clock_panel.add_theme_stylebox_override(
		"panel", make_style(Color("#24113B"), Color("#A767DD"), 12)
	)
	top.add_child(clock_panel)
	var clock_content: VBoxContainer = VBoxContainer.new()
	clock_content.name = "StopwatchContent"
	clock_content.add_theme_constant_override("separation", 0)
	clock_panel.add_child(clock_content)
	var clock_caption: Label = make_label(
		"ВРЕМЯ", 10, Color("#C59BDF")
	)
	clock_caption.name = "StopwatchCaption"
	clock_caption.autowrap_mode = TextServer.AUTOWRAP_OFF
	clock_caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	clock_content.add_child(clock_caption)
	timer_label = make_label("00:00", 17, Color("#F9E7FF"))
	timer_label.name = "GameStopwatch"
	timer_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	timer_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	clock_content.add_child(timer_label)

	var menu_button: Button = make_button(
		"☰ Пауза",
		pause_game
	)
	menu_button.name = "OpenPauseButton"
	menu_button.custom_minimum_size = Vector2(98, 43)
	menu_button.size_flags_horizontal = Control.SIZE_SHRINK_END
	top.add_child(menu_button)

	bot_label = make_label("", 16)
	bot_label.name = "OpponentInfo"
	bot_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	root.add_child(bot_label)

	# Рубашки всех карт компьютера.
	enemy_back_scroll = ScrollContainer.new()
	enemy_back_scroll.name = "EnemyCards"
	enemy_back_scroll.custom_minimum_size = Vector2(0, 69)
	enemy_back_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	enemy_back_scroll.horizontal_scroll_mode = (
		ScrollContainer.SCROLL_MODE_AUTO
	)
	enemy_back_scroll.vertical_scroll_mode = (
		ScrollContainer.SCROLL_MODE_DISABLED
	)
	root.add_child(enemy_back_scroll)

	enemy_backs = HBoxContainer.new()
	enemy_backs.name = "EnemyCardBacks"
	enemy_backs.add_theme_constant_override(
		"separation",
		-12
	)
	enemy_back_scroll.add_child(enemy_backs)

	# Стол и колода.
	battle_layout = GridContainer.new()
	battle_layout.name = "BattleLayout"
	battle_layout.columns = 2
	battle_layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	battle_layout.size_flags_vertical = Control.SIZE_EXPAND_FILL
	battle_layout.add_theme_constant_override(
		"h_separation",
		8
	)
	battle_layout.add_theme_constant_override(
		"v_separation",
		6
	)
	root.add_child(battle_layout)

	field_panel = GameField.new()
	field_panel.name = "BattleField"
	field_panel.game = self
	field_panel.custom_minimum_size = Vector2(280, 225)
	field_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	field_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL

	field_panel.add_theme_stylebox_override(
		"panel",
		make_style(
			Color("#1D0E30"),
			Color("#68379B"),
			14
		)
	)

	battle_layout.add_child(field_panel)

	var field_column: VBoxContainer = VBoxContainer.new()
	field_column.name = "FieldContent"
	field_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	field_column.size_flags_vertical = Control.SIZE_EXPAND_FILL
	field_column.mouse_filter = Control.MOUSE_FILTER_PASS
	field_column.add_theme_constant_override(
		"separation",
		6
	)
	field_panel.add_child(field_column)

	var field_title: Label = make_label(
		"ИГРОВОЙ СТОЛ · 2 × 5",
		13,
		GOLD
	)
	field_title.name = "FieldTitle"
	field_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	field_column.add_child(field_title)

	battle_scroll = ScrollContainer.new()
	battle_scroll.name = "TableScroll"
	battle_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	battle_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	battle_scroll.horizontal_scroll_mode = (
		ScrollContainer.SCROLL_MODE_AUTO
	)
	battle_scroll.vertical_scroll_mode = (
		ScrollContainer.SCROLL_MODE_DISABLED
	)
	battle_scroll.mouse_filter = Control.MOUSE_FILTER_PASS
	field_column.add_child(battle_scroll)

	var grid_center: CenterContainer = CenterContainer.new()
	grid_center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid_center.mouse_filter = Control.MOUSE_FILTER_PASS
	battle_scroll.add_child(grid_center)

	table_grid = GridContainer.new()
	table_grid.name = "TableSlots"
	table_grid.columns = 5
	table_grid.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	table_grid.mouse_filter = Control.MOUSE_FILTER_PASS
	table_grid.add_theme_constant_override(
		"h_separation",
		6
	)
	table_grid.add_theme_constant_override(
		"v_separation",
		7
	)
	grid_center.add_child(table_grid)

	deck_info = HBoxContainer.new()
	deck_info.name = "DeckInfo"
	deck_info.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	deck_info.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	deck_info.add_theme_constant_override(
		"separation",
		12
	)
	battle_layout.add_child(deck_info)

	var deck_section: VBoxContainer = VBoxContainer.new()
	deck_section.name = "DeckSection"
	deck_section.add_theme_constant_override(
		"separation",
		4
	)
	deck_info.add_child(deck_section)

	var deck_heading: Label = make_label("КОЛОДА", 12, GOLD)
	deck_heading.name = "DeckHeading"
	deck_section.add_child(deck_heading)

	deck_panel = PanelContainer.new()
	deck_panel.custom_minimum_size = Vector2(68, 82)
	deck_panel.add_theme_stylebox_override(
		"panel",
		make_style(
			Color("#6324A1"),
			Color("#D9A5FF"),
			10
		)
	)
	deck_section.add_child(deck_panel)

	var deck_art: VBoxContainer = VBoxContainer.new()
	deck_art.add_theme_constant_override(
		"separation",
		0
	)
	deck_panel.add_child(deck_art)
	deck_art.add_child(make_label("✦", 23))
	deck_art.add_child(make_label("JOKER", 10))
	deck_art.add_child(make_label("SHIFT", 10))

	deck_label = make_label("", 12)
	deck_section.add_child(deck_label)

	discard_label = make_label("БИТО: 0", 11, GOLD)
	deck_section.add_child(discard_label)

	var trump_section: VBoxContainer = VBoxContainer.new()
	trump_section.name = "TrumpSection"
	trump_section.add_theme_constant_override(
		"separation",
		4
	)
	deck_info.add_child(trump_section)
	var trump_heading: Label = make_label("КОЗЫРЬ", 12, GOLD)
	trump_heading.name = "TrumpHeading"
	trump_section.add_child(trump_heading)

	trump_icon_row = HBoxContainer.new()
	trump_icon_row.alignment = BoxContainer.ALIGNMENT_CENTER
	trump_icon_row.custom_minimum_size = Vector2(74, 44)
	trump_section.add_child(trump_icon_row)

	trump_label = make_label("", 12, GOLD)
	trump_label.custom_minimum_size = Vector2(74, 29)
	trump_section.add_child(trump_label)

	# Entirely separate compact HUD for portrait phones. The old desktop
	# deck + trump columns are HIDDEN on a phone: no narrow word wrapping.
	mobile_deck_strip = PanelContainer.new()
	mobile_deck_strip.name = "MobileDeckStrip"
	mobile_deck_strip.visible = false
	mobile_deck_strip.custom_minimum_size = Vector2(258, 54)
	mobile_deck_strip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mobile_deck_strip.add_theme_stylebox_override(
		"panel", make_style(Color("#211133"), Color("#8952C3"), 12)
	)
	deck_info.add_child(mobile_deck_strip)

	var hud_row: HBoxContainer = HBoxContainer.new()
	hud_row.name = "MobileDeckHUDRow"
	hud_row.alignment = BoxContainer.ALIGNMENT_CENTER
	hud_row.add_theme_constant_override("separation", 12)
	mobile_deck_strip.add_child(hud_row)

	var pile_info: VBoxContainer = VBoxContainer.new()
	pile_info.custom_minimum_size.x = 120
	pile_info.add_theme_constant_override("separation", 1)
	hud_row.add_child(pile_info)
	mobile_deck_label = make_label("КОЛОДА · 55", 13, LIGHT)
	mobile_deck_label.name = "MobileDeckCount"
	mobile_deck_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	pile_info.add_child(mobile_deck_label)
	mobile_discard_label = make_label("БИТО · 0", 11, GOLD)
	mobile_discard_label.name = "MobileDiscardCount"
	mobile_discard_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	pile_info.add_child(mobile_discard_label)

	var hud_divider: ColorRect = ColorRect.new()
	hud_divider.color = Color("#623891")
	hud_divider.custom_minimum_size = Vector2(2, 32)
	hud_divider.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_row.add_child(hud_divider)

	var trump_info: VBoxContainer = VBoxContainer.new()
	trump_info.custom_minimum_size.x = 106
	trump_info.add_theme_constant_override("separation", 1)
	hud_row.add_child(trump_info)
	var small_trump_title: Label = make_label("КОЗЫРЬ", 11, GOLD)
	small_trump_title.autowrap_mode = TextServer.AUTOWRAP_OFF
	trump_info.add_child(small_trump_title)
	mobile_trump_label = make_label("♠  ПИКИ", 13, LIGHT)
	mobile_trump_label.name = "MobileTrumpName"
	mobile_trump_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	trump_info.add_child(mobile_trump_label)

	# Desktop labels should never stack their individual characters either.
	for no_wrap_label in [deck_heading, deck_label, discard_label, trump_heading, trump_label]:
		no_wrap_label.autowrap_mode = TextServer.AUTOWRAP_OFF

	status_label = make_label("", 13)
	status_label.name = "StatusLabel"
	status_label.custom_minimum_size = Vector2(0, 57)
	root.add_child(status_label)

	# Unused vertical room lives here, never inside the card table.
	# On tall screens the user's hand and controls stay near the bottom.
	var hand_spacer: Control = Control.new()
	hand_spacer.name = "HandSpacer"
	hand_spacer.custom_minimum_size = Vector2.ZERO
	hand_spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hand_spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(hand_spacer)

	# Профиль игрока.
	var player_row: HBoxContainer = HBoxContainer.new()
	player_row.name = "PlayerInfoRow"
	player_row.alignment = BoxContainer.ALIGNMENT_CENTER
	player_row.custom_minimum_size = Vector2(0, 52)
	player_row.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	player_row.add_theme_constant_override(
		"separation",
		10
	)
	root.add_child(player_row)

	var player_avatar_box: PanelContainer = make_style_avatar_box(46)
	player_avatar_box.name = "PlayerAvatar"
	player_row.add_child(player_avatar_box)
	player_avatar_box.add_child(
		create_avatar_holder(42, false)
	)

	player_label = make_label("", 17, GOLD)
	player_label.name = "PlayerNickname"
	player_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	player_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	player_label.custom_minimum_size = Vector2(154, 40)
	player_label.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	player_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	player_row.add_child(player_label)

	# Карты игрока и действия.
	hand_actions_layout = GridContainer.new()
	hand_actions_layout.name = "HandActionsLayout"
	hand_actions_layout.columns = 2
	hand_actions_layout.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hand_actions_layout.add_theme_constant_override(
		"h_separation",
		12
	)
	hand_actions_layout.add_theme_constant_override(
		"v_separation",
		7
	)
	root.add_child(hand_actions_layout)

	hand_scroll = ScrollContainer.new()
	hand_scroll.name = "HandScroll"
	hand_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hand_scroll.custom_minimum_size = Vector2(0, 134)
	hand_scroll.horizontal_scroll_mode = (
		ScrollContainer.SCROLL_MODE_AUTO
	)
	hand_scroll.vertical_scroll_mode = (
		ScrollContainer.SCROLL_MODE_DISABLED
	)
	hand_actions_layout.add_child(hand_scroll)

	hand_row = HBoxContainer.new()
	hand_row.add_theme_constant_override(
		"separation",
		-5
	)
	hand_scroll.add_child(hand_row)

	var actions: GridContainer = GridContainer.new()
	actions.name = "ActionButtons"
	actions.columns = 2
	actions.add_theme_constant_override(
		"h_separation",
		5
	)
	actions.add_theme_constant_override(
		"v_separation",
		5
	)
	actions.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hand_actions_layout.add_child(actions)

	game_screen.move_child(
		motion_layer,
		game_screen.get_child_count() - 1
	)

	actions.add_child(
		make_button("Добрать", draw_cards)
	)
	actions.add_child(
		make_button("Бито!", finish_round)
	)
	actions.add_child(
		make_button("Забрать", take_cards)
	)


func create_dialogs() -> void:
	mobile_more_dialog = AcceptDialog.new()
	mobile_more_dialog.name = "MobileMoreDialog"
	mobile_more_dialog.title = "✦  ДОПОЛНИТЕЛЬНО"
	mobile_more_dialog.ok_button_text = "ЗАКРЫТЬ"
	add_child(mobile_more_dialog)
	var extra_scroll: ScrollContainer = ScrollContainer.new()
	extra_scroll.custom_minimum_size = Vector2(245, 320)
	extra_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	extra_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	mobile_more_dialog.add_child(extra_scroll)
	var extra_grid: GridContainer = GridContainer.new()
	extra_grid.name = "MobileMoreOptions"
	extra_grid.columns = 2
	extra_grid.add_theme_constant_override("h_separation", 6)
	extra_grid.add_theme_constant_override("v_separation", 6)
	extra_scroll.add_child(extra_grid)
	for title in [
		"Фото профиля", "Убрать фото", "Достижения", "Предметы",
		"Друзья", "Доска почёта", "Новости", "Правила"
	]:
		var extra_button: Button = make_button(title, mobile_more_action.bind(title))
		extra_button.custom_minimum_size = Vector2(114, 43)
		extra_button.add_theme_font_size_override("font_size", 13)
		extra_grid.add_child(extra_button)

	coming_soon_dialog = AcceptDialog.new()
	coming_soon_dialog.name = "ComingSoonDialog"
	coming_soon_dialog.title = "Раздел в разработке"
	coming_soon_dialog.ok_button_text = "ПОНЯТНО"
	add_child(coming_soon_dialog)

	# A real news tab: the user-provided JokerShift Telegram channel.
	# The actual external link opens only after pressing the primary button.
	news_dialog = ConfirmationDialog.new()
	news_dialog.name = "NewsDialog"
	news_dialog.title = "✦  НОВОСТИ JOKERSHIFT"
	news_dialog.ok_button_text = "ОТКРЫТЬ TELEGRAM  ↗"
	news_dialog.cancel_button_text = "ЗАКРЫТЬ"
	news_dialog.confirmed.connect(open_telegram_news)
	add_child(news_dialog)

	var news_card: PanelContainer = PanelContainer.new()
	news_card.name = "NewsCard"
	news_card.custom_minimum_size = Vector2(280, 215)
	news_card.add_theme_stylebox_override(
		"panel", make_style(Color("#1D0B2E"), Color("#AA63F9"), 18)
	)
	news_dialog.add_child(news_card)

	var news_body: VBoxContainer = VBoxContainer.new()
	news_body.name = "NewsBody"
	news_body.add_theme_constant_override("separation", 9)
	news_card.add_child(news_body)

	var news_star: Label = make_label("✦  🃏  ✦", 34, Color("#E6B9FF"))
	news_star.mouse_filter = Control.MOUSE_FILTER_IGNORE
	news_body.add_child(news_star)

	var news_title: Label = make_label("НОВОСТИ И ОБНОВЛЕНИЯ", 21, GOLD)
	news_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	news_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	news_body.add_child(news_title)

	var news_description: Label = make_label(
		"Наш Telegram-канал о JokerShift.\n"
		+ "Анонсы, новые карты, исправления и планы игры.\n"
		+ "Подписывайся, чтобы следить за развитием проекта!",
		14, LIGHT
	)
	news_description.name = "NewsDescription"
	news_description.mouse_filter = Control.MOUSE_FILTER_IGNORE
	news_body.add_child(news_description)

	var news_link: Label = make_label("t.me/+HLR-m55X-bM2ZjAy", 13, Color("#C883FF"))
	news_link.name = "NewsChannelLink"
	news_link.autowrap_mode = TextServer.AUTOWRAP_OFF
	news_link.mouse_filter = Control.MOUSE_FILTER_IGNORE
	news_body.add_child(news_link)

	var news_open: Button = news_dialog.get_ok_button()
	news_open.add_theme_stylebox_override(
		"normal", make_style(Color("#6D2CAF"), Color("#DDAAFF"), 11)
	)
	news_open.add_theme_stylebox_override(
		"hover", make_style(Color("#9A50E0"), Color.WHITE, 11)
	)
	news_open.add_theme_color_override("font_color", LIGHT)

	avatar_dialog = FileDialog.new()
	avatar_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	avatar_dialog.access = FileDialog.ACCESS_FILESYSTEM
	avatar_dialog.use_native_dialog = true
	avatar_dialog.title = "Выбрать аватарку"
	avatar_dialog.filters = PackedStringArray([
		"*.png,*.jpg,*.jpeg,*.webp;Изображения"
	])
	avatar_dialog.file_selected.connect(
		on_avatar_file_selected
	)
	add_child(avatar_dialog)

	rules_dialog = AcceptDialog.new()
	rules_dialog.process_mode = Node.PROCESS_MODE_ALWAYS
	rules_dialog.title = "✦ Как играть в JokerShift"
	rules_dialog.ok_button_text = "ПОНЯТНО ✓"
	rules_dialog.name = "RulesDialog"
	add_child(rules_dialog)

	var rules: RichTextLabel = RichTextLabel.new()
	rules.name = "RulesContent"
	rules.bbcode_enabled = true
	rules.scroll_active = true
	rules.fit_content = false
	rules.selection_enabled = false
	rules.custom_minimum_size = Vector2(275, 375)
	rules.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rules.size_flags_vertical = Control.SIZE_EXPAND_FILL

	rules.add_theme_font_size_override(
		"normal_font_size",
		16
	)
	rules.add_theme_color_override(
		"default_color",
		LIGHT
	)
	rules.add_theme_constant_override(
		"line_separation",
		5
	)
	rules.add_theme_stylebox_override(
		"normal",
		make_style(
			Color("#20102F"),
			Color("#6C3C91"),
			12
		)
	)

	rules.text = (
		"[center][font_size=25][color=#E9C0FF][b]🃏 JOKERSHIFT[/b][/color][/font_size][/center]\n"
		+ "[center][color=#BE9FD6]«Дурак», переводы и особые карты[/color][/center]\n\n"

		+ "[font_size=20][color=#FFD18C][b]01  КАК ХОДИТЬ[/b][/color][/font_size]\n"
		+ "Выбери карту внизу и нажми на свободную ячейку стола. "
		+ "Можно просто [b]перетащить[/b] карту мышкой или пальцем.\n\n"
		+ "[color=#D6ACFF]Чтобы отбиться:[/color] положи подходящую карту "
		+ "[b]прямо на атакующую[/b]. Защита появится поверх неё.\n\n"

		+ "[font_size=20][color=#FFD18C][b]02  ПОДКИДЫВАНИЕ И «БИТО»[/b][/color][/font_size]\n"
		+ "Подкидывать можно достоинства карт, уже появившихся на столе. "
		+ "Стол вмещает [b]2 ряда по 5 мест[/b].\n"
		+ "В первой взятке — максимум [b]8 атак[/b], затем — до [b]10[/b]. "
		+ "Но карт нельзя подкинуть больше, чем сможет принять защитник.\n"
		+ "[color=#D6ACFF]Пример:[/color] бот отбил 4 карты, а в руке у него 2. "
		+ "Можно подкинуть [b]ещё 2[/b].\n"
		+ "[b]Бито![/b] — когда все атаки отбиты. [b]Забрать[/b] — "
		+ "взять карты со стола, если не можешь защититься.\n\n"

		+ "[font_size=20][color=#FFD18C][b]03  КОЗЫРИ[/b][/color][/font_size]\n"
		+ "Обычный козырь — одна масть. Красный джокер в колоде "
		+ "означает козыри [color=#FF6D89]♥ червы + ♦ бубны[/color]; "
		+ "чёрный — [color=#C0B3FF]♠ пики + ♣ трефы[/color]. "
		+ "Метка открывает игру [b]без козыря[/b].\n\n"

		+ "[font_size=20][color=#FFD18C][b]04  ДЖОКЕР И МЕТКА[/b][/color][/font_size]\n"
		+ "[color=#E5BDFF][b]Джокер[/b][/color] копирует [b]любую карту на столе[/b]: "
		+ "атаку, защиту, уже сыгранного джокера и даже метку. "
		+ "На самом джокере крупно показано [b]скопированное достоинство и масть[/b]. "
		+ "При защите скопированная обычная карта должна быть "
		+ "[b]старше атаки минимум на 1 ранг[/b] и той же масти. "
		+ "Копия козыря отбивает козырь старше по рангу, "
		+ "а также [b]тот же самый козырь[/b] равного ранга и масти. "
		+ "Козырем можно отбить некозырную карту. "
		+ "Джокер с копией метки [b]отбивает даже козырь[/b]. "
		+ "Если атакует такой джокер, другой джокер может "
		+ "скопировать метку с него и отбиться. Без метки или "
		+ "другого джокера придётся забирать карты. "
		+ "Джокер также подходит для перевода.\n"
		+ "[color=#E5BDFF][b]Метка[/b][/color] отбивает любую атаку. "
		+ "Обычную карту нельзя использовать для защиты от метки. "
		+ "Метка может отбить другую метку.\n\n"

		+ "[font_size=20][color=#FFD18C][b]05  ПЕРЕВОД И ЗАМЕНА[/b][/color][/font_size]\n"
		+ "[b]Перевод:[/b] положи карту того же достоинства в "
		+ "[b]пустую ячейку[/b], пока атаки ещё не отбиты. "
		+ "Теперь защищается соперник.\n"
		+ "[b]Замена защиты:[/b] можно положить [b]любую карту, которая отбивает атаку[/b], "
		+ "поверх уже сыгранной защиты. Например, туза бубен можно заменить "
		+ "младшим козырем. Если замена тратит козырь или не экономит карты, "
		+ "игра сначала [b]попросит подтверждение[/b]. Старая карта вернётся в руку, "
		+ "но бот сможет подкинуть карту её достоинства.\n\n"

		+ "[font_size=20][color=#FFD18C][b]06  ДОБОР И ПОБЕДА[/b][/color][/font_size]\n"
		+ "Нажимай [b]«Добрать»[/b], чтобы взять 1 карту, "
		+ "пока в руке меньше 6. Бот при защите может добирать "
		+ "из колоды, но не выше [b]6 карт[/b].\n"
		+ "После окончания колоды побеждает тот, кто первым "
		+ "избавится от карт. Если остались только джокер или "
		+ "метка, [b]это не поражение, пока тебя атакуют[/b]: "
		+ "ими ещё можно отбиться.\n\n"

		+ "[center][color=#C9A3E8]✦ Удачной партии! ✦[/color][/center]"
	)

	rules_dialog.add_child(rules)

	# Подтверждение спорной замены.
	replace_confirmation = ConfirmationDialog.new()
	replace_confirmation.name = "ReplaceConfirmation"
	replace_confirmation.title = "Подтвердить замену защиты"
	replace_confirmation.ok_button_text = "Да, заменить"
	replace_confirmation.cancel_button_text = "Оставить как есть"
	replace_confirmation.confirmed.connect(
		confirm_replacement
	)
	replace_confirmation.canceled.connect(
		func() -> void:
			pending_replacement.clear()
	)
	add_child(replace_confirmation)

	joker_dialog = ConfirmationDialog.new()
	joker_dialog.title = "Джокер — выбери карту"
	joker_dialog.ok_button_text = "Закрыть"
	add_child(joker_dialog)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(280, 230)
	joker_dialog.add_child(scroll)

	joker_options = VBoxContainer.new()
	scroll.add_child(joker_options)

	result_dialog = AcceptDialog.new()
	result_dialog.title = "JokerShift"
	result_dialog.ok_button_text = "ИГРАТЬ СНОВА"
	result_dialog.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(result_dialog)
	result_dialog.confirmed.connect(new_game)
	result_dialog.add_button("ГЛАВНОЕ МЕНЮ", true, "home")
	result_dialog.custom_action.connect(
		func(action: String) -> void:
			if action == "home":
				result_dialog.hide()
				show_menu()
	)


func show_rules() -> void:
	var viewport: Vector2 = get_viewport_rect().size
	var width: int = int(
		minf(540.0, maxf(288.0, viewport.x - 24.0))
	)
	var height: int = int(
		minf(690.0, maxf(330.0, viewport.y - 30.0))
	)

	rules_dialog.popup_centered(
		Vector2i(width, height)
	)


func card_size_for_screen(viewport_size: Vector2) -> float:
	# Portrait: preserve original 2:3 artwork and leave enough room for
	# the complete gameplay HUD, table, hand, and action buttons.
	var portrait: bool = viewport_size.y >= viewport_size.x
	if portrait:
		# 5 columns, slim 12px defensive overlap and 4px gutters;
		# 68px max leaves room for the HUD + visible player hand.
		var by_width: float = (viewport_size.x - 62.0) / 5.0 - 12.0
		var by_height: float = (viewport_size.y - 430.0) / 3.5
		var max_size: float = maxf(68.0, minf(105.0, viewport_size.x * 0.145))
		return clampf(minf(by_width, by_height), 36.0, max_size)

	var deck_room: float = clampf(viewport_size.x * 0.16, 94.0, 148.0)
	var by_width: float = (
		viewport_size.x - deck_room - 72.0 - 5.0 * 18.0
		- 4.0 * 6.0
	) / 5.0
	var by_height: float = (viewport_size.y - 282.0) / 3.25
	return clampf(minf(by_width, by_height), 40.0, 106.0)


func adapt_layout() -> void:
	var viewport_size: Vector2 = get_viewport_rect().size
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return

	var portrait: bool = viewport_size.y >= viewport_size.x
	var compact: bool = portrait and viewport_size.x <= 900.0
	var very_short: bool = compact and viewport_size.y < 780.0
	landscape_mode = not portrait

	if menu_panel != null:
		menu_panel.custom_minimum_size.x = maxf(240.0, minf(
			456.0, viewport_size.x - 20.0
		))

	if pause_overlay != null:
		var pause_card: Control = pause_overlay.find_child(
			"PauseCard", true, false
		)
		if pause_card != null:
			pause_card.custom_minimum_size.x = minf(
				352.0, maxf(238.0, viewport_size.x - 20.0)
			)

	# Main menu: no full-height center alignment and no forced scrolling
	# on common portrait aspect ratios. Scroll remains as accessibility
	# fallback on unusually tiny or split-screen windows.
	if menu_screen != null:
		var menu_scroll: ScrollContainer = menu_screen.find_child(
			"MenuScroll", true, false
		) as ScrollContainer
		if menu_scroll != null:
			menu_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO

		var menu_center: CenterContainer = menu_screen.find_child(
			"MenuCenter", true, false
		) as CenterContainer
		if menu_center != null:
			menu_center.size_flags_vertical = Control.SIZE_SHRINK_BEGIN

		var margins: MarginContainer = menu_screen.find_child(
			"MenuMargins", true, false
		) as MarginContainer
		if margins != null:
			var edge: int = 4 if compact else 12
			var vertical: int = 3 if very_short else (7 if compact else 16)
			for margin_name in ["margin_left", "margin_right"]:
				margins.add_theme_constant_override(margin_name, edge)
			for margin_name in ["margin_top", "margin_bottom"]:
				margins.add_theme_constant_override(margin_name, vertical)

		var menu_content: VBoxContainer = menu_screen.find_child(
			"MenuContent", true, false
		) as VBoxContainer
		if menu_content != null:
			menu_content.add_theme_constant_override(
				"separation", 4 if very_short else (6 if compact else 11)
			)

		var menu_logo: TextureRect = menu_screen.find_child(
			"MenuLogo", true, false
		) as TextureRect
		if menu_logo != null:
			var logo_side: float = 43.0 if compact else 76.0
			menu_logo.custom_minimum_size = Vector2(logo_side, logo_side)

		for optional_name in [
			"ProfileCaption", "AvatarActions", "FeaturesCaption",
			"FeatureGrid", "MenuFooter"
		]:
			var optional_node: Control = menu_screen.find_child(
				optional_name, true, false
			) as Control
			if optional_node != null:
				optional_node.visible = not very_short

		var mobile_more: Button = menu_screen.find_child(
			"MobileMoreButton", true, false
		) as Button
		if mobile_more != null:
			mobile_more.visible = very_short

		var menu_avatar: Control = menu_screen.find_child(
			"MenuAvatarBox", true, false
		) as Control
		if menu_avatar != null:
			menu_avatar.visible = not very_short

		var nick: LineEdit = menu_screen.find_child(
			"NicknameInput", true, false
		) as LineEdit
		if nick != null:
			nick.custom_minimum_size = Vector2(145, 38 if compact else 42)
			nick.add_theme_font_size_override("font_size", 16 if compact else 17)

		var difficulty: OptionButton = menu_screen.find_child(
			"DifficultySelect", true, false
		) as OptionButton
		if difficulty != null:
			difficulty.custom_minimum_size.y = 40 if compact else 43

		var play: Button = menu_screen.find_child("PlayButton", true, false) as Button
		if play != null:
			play.custom_minimum_size.y = 52 if compact else 62
			play.add_theme_font_size_override("font_size", 21 if compact else 24)

		var online: Button = menu_screen.find_child(
			"PlayOnlineButton", true, false
		) as Button
		if online != null:
			online.custom_minimum_size.y = 52 if compact else 65

		var online_title: Label = menu_screen.find_child(
			"OnlinePlayTitle", true, false
		) as Label
		if online_title != null:
			online_title.add_theme_font_size_override("font_size", 15 if compact else 16)

		var online_notice: Label = menu_screen.find_child(
			"OnlinePlayNotice", true, false
		) as Label
		if online_notice != null:
			online_notice.add_theme_font_size_override("font_size", 10 if compact else 11)

		for node_name in ["AvatarChooseButton", "AvatarResetButton"]:
			var btn: Button = menu_screen.find_child(node_name, true, false) as Button
			if btn != null:
				btn.custom_minimum_size.y = 36 if compact else 36
				btn.add_theme_font_size_override("font_size", 14 if compact else 15)

		var features: GridContainer = menu_screen.find_child(
			"FeatureGrid", true, false
		) as GridContainer
		if features != null:
			features.add_theme_constant_override("h_separation", 5 if compact else 8)
			features.add_theme_constant_override("v_separation", 5 if compact else 8)
			for child in features.get_children():
				if child is Button:
					var feature_button: Button = child as Button
					feature_button.custom_minimum_size.y = 40 if compact else 54
					feature_button.add_theme_font_size_override("font_size", 13 if compact else 14)

	# Live match: everything necessary for a turn stays on screen.
	if game_screen != null:
		var title: Label = game_screen.find_child(
			"GameTitle", true, false
		) as Label
		if title != null:
			title.text = "✦ JS" if compact else "🃏 JokerShift"
			title.add_theme_font_size_override("font_size", 17 if compact else 21)

		var game_scroll: ScrollContainer = game_screen.find_child(
			"GameScroll", true, false
		) as ScrollContainer
		if game_scroll != null:
			# Keep a scroll fallback only on genuinely tiny viewports.
			# Content is sized to fit common 320x568..720x1280 phones.
			game_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO

		var game_root: VBoxContainer = game_screen.find_child(
			"GameRoot", true, false
		) as VBoxContainer
		if game_root != null:
			game_root.add_theme_constant_override("separation", 3 if compact else 6)

		var game_margins: MarginContainer = game_screen.find_child(
			"GameMargins", true, false
		) as MarginContainer
		if game_margins != null:
			var spacing: int = 3 if compact else 6
			for margin_name in ["margin_left", "margin_right", "margin_top", "margin_bottom"]:
				game_margins.add_theme_constant_override(margin_name, spacing)

		var time_chip: Control = game_screen.find_child(
			"StopwatchPanel", true, false
		) as Control
		if time_chip != null:
			time_chip.custom_minimum_size = Vector2(91, 40) if compact else Vector2(110, 46)

		var pause_btn: Button = game_screen.find_child(
			"OpenPauseButton", true, false
		) as Button
		if pause_btn != null:
			pause_btn.custom_minimum_size = Vector2(83, 41) if compact else Vector2(98, 43)
			pause_btn.add_theme_font_size_override("font_size", 13 if compact else 15)

		var field_title: Label = game_screen.find_child(
			"FieldTitle", true, false
		) as Label
		if field_title != null:
			field_title.add_theme_font_size_override("font_size", 11 if compact else 13)

		var field_column: VBoxContainer = game_screen.find_child(
			"FieldContent", true, false
		) as VBoxContainer
		if field_column != null:
			field_column.add_theme_constant_override("separation", 3 if compact else 6)

		var player_avatar: Control = game_screen.find_child(
			"PlayerAvatar", true, false
		) as Control
		if player_avatar != null:
			player_avatar.visible = not compact

		var player_name: Label = game_screen.find_child(
			"PlayerNickname", true, false
		) as Label
		if player_name != null:
			player_name.custom_minimum_size = Vector2(130, 25) if compact else Vector2(154, 40)
			player_name.add_theme_font_size_override("font_size", 15 if compact else 17)

	if battle_layout != null:
		battle_layout.columns = 1 if portrait else 2
		battle_layout.add_theme_constant_override("v_separation", 3 if compact else 6)
		battle_layout.size_flags_vertical = (
			Control.SIZE_SHRINK_BEGIN if compact else Control.SIZE_EXPAND_FILL
		)
	if field_panel != null:
		field_panel.size_flags_vertical = (
			Control.SIZE_SHRINK_BEGIN if compact else Control.SIZE_EXPAND_FILL
		)
	if game_screen != null:
		var hand_spacer: Control = game_screen.find_child(
			"HandSpacer", true, false
		) as Control
		if hand_spacer != null:
			hand_spacer.visible = compact
	if hand_actions_layout != null:
		hand_actions_layout.columns = 1 if portrait else 2
		hand_actions_layout.add_theme_constant_override("v_separation", 3 if compact else 7)
	if deck_info != null:
		deck_info.size_flags_horizontal = (
			Control.SIZE_EXPAND_FILL if compact else
			(Control.SIZE_SHRINK_CENTER if portrait else Control.SIZE_SHRINK_END)
		)
		deck_info.alignment = BoxContainer.ALIGNMENT_CENTER
		deck_info.add_theme_constant_override("separation", 0 if compact else 12)
		var desktop_deck: Control = deck_info.find_child("DeckSection", false, false) as Control
		var desktop_trump: Control = deck_info.find_child("TrumpSection", false, false) as Control
		if desktop_deck != null:
			desktop_deck.visible = not compact
		if desktop_trump != null:
			desktop_trump.visible = not compact
	if mobile_deck_strip != null:
		mobile_deck_strip.visible = compact
		mobile_deck_strip.custom_minimum_size = (
			Vector2(0, 50 if very_short else 54) if compact else Vector2.ZERO
		)
	if deck_panel != null:
		deck_panel.visible = not compact and not deck.is_empty()
	if trump_icon_row != null:
		trump_icon_row.custom_minimum_size = Vector2(74, 25) if compact else Vector2(74, 44)
	if trump_label != null:
		trump_label.custom_minimum_size = Vector2(74, 17) if compact else Vector2(74, 29)

	var portrait_deck: Control = (
		game_screen.find_child("DeckSection", true, false)
		if game_screen != null else null
	)
	if portrait_deck != null:
		portrait_deck.add_theme_constant_override("separation", 1 if compact else 4)
	var portrait_trump: Control = (
		game_screen.find_child("TrumpSection", true, false)
		if game_screen != null else null
	)
	if portrait_trump != null:
		portrait_trump.add_theme_constant_override("separation", 1 if compact else 4)

	card_width = card_size_for_screen(viewport_size)
	card_height = card_width * 1.5
	slot_width = card_width + (12.0 if compact else 18.0)
	slot_height = card_height + (20.0 if compact else 22.0)

	if field_panel != null:
		field_panel.custom_minimum_size = Vector2(
			5.0 * slot_width + 4.0 * (4.0 if compact else 6.0) + 16.0,
			2.0 * slot_height + (4.0 if compact else 7.0) + (27.0 if compact else 40.0)
		)
	if table_grid != null:
		table_grid.columns = 5
		table_grid.add_theme_constant_override("h_separation", 4 if compact else 6)
		table_grid.add_theme_constant_override("v_separation", 4 if compact else 7)
	if enemy_back_scroll != null:
		enemy_back_scroll.custom_minimum_size.y = (
			36.0 if compact and viewport_size.y < 680.0 else (44.0 if compact else (clampf(viewport_size.y * 0.095, 44.0, 69.0) if not portrait else 69.0))
		)
	if hand_scroll != null:
		hand_scroll.custom_minimum_size.y = card_height + (5.0 if compact else 8.0)

	if status_label != null:
		status_label.custom_minimum_size.y = (31.0 if compact else 48.0)
		status_label.max_lines_visible = 2 if compact else -1
		status_label.add_theme_font_size_override("font_size", 11 if compact else 13)

	var player_row: Control = (
		game_screen.find_child("PlayerInfoRow", true, false)
		if game_screen != null else null
	)
	if player_row != null:
		player_row.custom_minimum_size.y = 25.0 if compact else 52.0

	var action_buttons: GridContainer = (
		game_screen.find_child("ActionButtons", true, false) as GridContainer
		if game_screen != null else null
	)
	if action_buttons != null:
		action_buttons.columns = 3 if compact else 2
		action_buttons.size_flags_horizontal = Control.SIZE_EXPAND_FILL if compact else Control.SIZE_SHRINK_END
		for node in action_buttons.get_children():
			if node is Button:
				var action_button: Button = node as Button
				action_button.custom_minimum_size.y = 44.0 if compact else 46.0
				action_button.add_theme_font_size_override("font_size", 14 if compact else 15)

	# Force texture cache invalidation when viewport geometry changes.
	face_texture_cache.clear()
	last_enemy_visual_key = ""
	last_table_visual_key = ""
	last_hand_visual_key = ""
	last_trump_visual_key = ""
	if game_screen != null and game_screen.visible:
		update_ui()


func new_game() -> void:
	if is_game_paused or get_tree().paused:
		resume_game()
	elapsed_game_seconds = 0.0
	if timer_label != null:
		timer_label.text = "00:00"
	pending_replacement.clear()

	if replace_confirmation != null:
		replace_confirmation.hide()

	clear_finale()
	last_table_visual_key = ""
	last_hand_visual_key = ""
	replaced_throw_ranks.clear()
	remembered_table_faces.clear()
	last_enemy_visual_key = ""

	animation_serial += 1
	animation_busy = false

	if hand_row != null:
		hand_row.modulate.a = 1.0

	if enemy_backs != null:
		enemy_backs.modulate.a = 1.0

	if table_grid != null:
		table_grid.modulate.a = 1.0

	if motion_layer != null:
		clear_children(motion_layer)

	deck.clear()
	player_hand.clear()
	bot_hand.clear()
	table_cards.clear()
	discard_pile.clear()

	attacker = 0
	first_round = true
	bot_takes = false
	finished = false
	selected_index = -1
	selected_pair = -1
	pending_slot_id = -1

	joker_dialog.hide()
	result_dialog.hide()

	for suit in SUITS:
		for rank in range(2, 15):
			deck.append({
				"rank": rank,
				"suit": suit,
				"special": "",
				"joker_color": "",
				"copy_rank": -1,
				"copy_suit": ""
			})

	for joker_color in ["red", "black"]:
		deck.append({
			"rank": 20,
			"suit": "",
			"special": "joker",
			"joker_color": joker_color,
			"copy_rank": -1,
			"copy_suit": ""
		})

	deck.append({
		"rank": 22,
		"suit": "",
		"special": "mark",
		"joker_color": "",
		"copy_rank": -1,
		"copy_suit": ""
	})

	deck.shuffle()
	setup_trump(deck[0])

	draw_to_six(player_hand)
	draw_to_six(bot_hand)

	attacker = determine_first_attacker()

	if attacker == 1:
		status_text = (
			"У компьютера младший козырь — он ходит первым."
		)
	else:
		status_text = (
			"Твой первый ход: у тебя младший козырь или ничья."
		)

	adapt_layout()
	update_ui()
	pulse(deck_panel)

	if animation_enabled:
		play_deal_animation()
	elif attacker == 1:
		bot_attack()


func lowest_trump_rank(hand: Array) -> int:
	var lowest: int = 999

	for card in hand:
		if is_special(card):
			continue

		if is_trump(card):
			lowest = mini(
				lowest,
				card_rank(card)
			)

	return lowest


func determine_first_attacker() -> int:
	var player_lowest: int = lowest_trump_rank(
		player_hand
	)
	var bot_lowest: int = lowest_trump_rank(
		bot_hand
	)

	if bot_lowest < player_lowest:
		return 1

	return 0


func setup_trump(card: Dictionary) -> void:
	if is_mark(card):
		trump_mode = "none"
		trump_suit = "НЕТ"

	elif is_joker(card):
		if str(card["joker_color"]) == "red":
			trump_mode = "red"
			trump_suit = "♥ ♦"
		else:
			trump_mode = "black"
			trump_suit = "♠ ♣"

	else:
		trump_mode = "suit"
		trump_suit = str(card["suit"])


func trump_display_name() -> String:
	match trump_mode:
		"none":
			return "БЕЗ\nКОЗЫРЯ"
		"red":
			return "ЧЕРВЫ\nБУБНЫ"
		"black":
			return "ПИКИ\nТРЕФЫ"
		_:
			match trump_suit:
				"♥":
					return "ЧЕРВЫ"
				"♦":
					return "БУБНЫ"
				"♠":
					return "ПИКИ"
				"♣":
					return "ТРЕФЫ"
				_:
					return "НЕТ"


func update_trump_symbol() -> void:
	if trump_icon_row == null:
		return

	var visual_key: String = (
		trump_mode + "|" + trump_suit
	)

	if visual_key == last_trump_visual_key:
		return

	last_trump_visual_key = visual_key
	clear_children(trump_icon_row)

	var suits_to_draw: Array[String] = []

	match trump_mode:
		"red":
			suits_to_draw = ["♥", "♦"]
		"black":
			suits_to_draw = ["♠", "♣"]
		"none":
			suits_to_draw = ["mark"]
		_:
			suits_to_draw = [trump_suit]

	for suit in suits_to_draw:
		var icon: SuitIcon = SuitIcon.new()
		icon.name = "TrumpSuit"
		icon.suit = suit

		icon.ink = (
			Color("#D82E57")
			if suit == "♥" or suit == "♦"
			else Color("#F5E8FF")
		)

		if suit == "mark":
			icon.ink = GOLD

		icon.custom_minimum_size = (
			Vector2(25, 25) if get_viewport_rect().size.x <= 900.0
			and get_viewport_rect().size.y >= get_viewport_rect().size.x
			else Vector2(36, 44)
		)
		trump_icon_row.add_child(icon)


func draw_to_six(hand: Array) -> void:
	while hand.size() < 6 and not deck.is_empty():
		hand.append(deck.pop_back())


func is_joker(card: Dictionary) -> bool:
	return str(card.get("special", "")) == "joker"


func is_mark(card: Dictionary) -> bool:
	return str(card.get("special", "")) == "mark"


func is_special(card: Dictionary) -> bool:
	return is_joker(card) or is_mark(card)


func card_rank(card: Dictionary) -> int:
	if is_mark(card):
		return 100

	if is_joker(card):
		return int(card.get("copy_rank", -1))

	return int(card["rank"])


func card_suit(card: Dictionary) -> String:
	if is_mark(card):
		return ""

	if is_joker(card):
		return str(card.get("copy_suit", ""))

	return str(card["suit"])


func rank_name(rank: int) -> String:
	if rank < 2 or rank > 14:
		return "?"

	return str(RANKS[rank - 2])


func suit_short_name(suit: String) -> String:
	match suit:
		"♥":
			return "ЧЕРВ"
		"♦":
			return "БУБ"
		"♠":
			return "ПИК"
		"♣":
			return "ТРЕФ"
		_:
			return ""


func card_name(card: Dictionary) -> String:
	if is_mark(card):
		return "МЕТКА"

	if is_joker(card):
		var name: String = "Красный джокер"

		if str(card["joker_color"]) == "black":
			name = "Чёрный джокер"

		if card_rank(card) == 100:
			return name + " → Метка"

		if card_rank(card) >= 2:
			return (
				name
				+ " → "
				+ rank_name(card_rank(card))
				+ card_suit(card)
			)

		return name

	return (
		rank_name(card_rank(card))
		+ card_suit(card)
	)


func joker_copy_label(card: Dictionary) -> String:
	if not is_joker(card) or card_rank(card) < 2:
		return "НЕТ КОПИИ"

	if card_rank(card) == 100:
		return "МЕТКА"

	return (
		rank_name(card_rank(card))
		+ card_suit(card)
	)


func is_trump(card: Dictionary) -> bool:
	var suit: String = card_suit(card)

	match trump_mode:
		"none":
			return false
		"red":
			return suit == "♥" or suit == "♦"
		"black":
			return suit == "♠" or suit == "♣"
		_:
			return suit == trump_suit


func copy_joker(
	joker: Dictionary,
	target: Dictionary
) -> Dictionary:
	var result: Dictionary = joker.duplicate(true)

	result["copy_rank"] = card_rank(target)
	result["copy_suit"] = card_suit(target)

	return result


func reset_joker(card: Dictionary) -> Dictionary:
	if not is_joker(card):
		return card

	var result: Dictionary = card.duplicate(true)
	result["copy_rank"] = -1
	result["copy_suit"] = ""

	return result


func can_beat(card: Dictionary, target: Dictionary) -> bool:
	# A real Mark, and a Joker which deliberately COPIED Mark (rank 100),
	# both cover any attack, including trumps and another copied Mark.
	# This enables the requested Mark -> copied Mark -> copied Mark chain.
	if is_mark(card) or (is_joker(card) and card_rank(card) == 100):
		return true

	# A Mark or a Joker copying Mark cannot be defended with any
	# regular card, regular trump or Joker copying a normal card.
	if is_mark(target) or (is_joker(target) and card_rank(target) == 100):
		return false

	var defense_rank: int = card_rank(card)
	var attack_rank: int = card_rank(target)

	# Unassigned Joker: cannot defend until it copies a visible card.
	if is_joker(card) and defense_rank < 2:
		return false

	var defense_trump: bool = is_trump(card)
	var attack_trump: bool = is_trump(target)

	if attack_trump:
		if not defense_trump:
			return false
		if defense_rank > attack_rank:
			return true
		# The explicitly requested exception: a Joker copying a trump
		# can beat the exact SAME trump, unlike equal-rank regular cards.
		return (
			is_joker(card)
			and defense_rank == attack_rank
			and card_suit(card) == card_suit(target)
		)

	# A trump covers a nontrump. Otherwise rank must be strictly higher
	# and the suit must match; a copied nontrump never beats itself.
	if defense_trump:
		return true

	return (
		card_suit(card) == card_suit(target)
		and defense_rank > attack_rank
	)


func round_limit() -> int:
	return 8 if first_round else 10


func unbeaten_pair() -> int:
	for i in range(table_cards.size()):
		if table_cards[i]["defense"].is_empty():
			return i

	return -1


func all_defended() -> bool:
	return unbeaten_pair() == -1


func table_has_rank(rank: int) -> bool:
	if replaced_throw_ranks.has(rank):
		return true

	for pair in table_cards:
		if card_rank(pair["attack"]) == rank:
			return true

		if not pair["defense"].is_empty():
			if card_rank(pair["defense"]) == rank:
				return true

	return false


func slot_for_pair(pair_index: int) -> int:
	if pair_index < 0 or pair_index >= table_cards.size():
		return -1

	return int(
		table_cards[pair_index].get(
			"slot_id",
			pair_index
		)
	)


func pair_at_slot(slot_id: int) -> int:
	if slot_id < 0 or slot_id >= 10:
		return -1

	for i in range(table_cards.size()):
		if slot_for_pair(i) == slot_id:
			return i

	return -1


func free_table_slot(preferred: int = -1) -> int:
	if (
		preferred >= 0
		and preferred < 10
		and pair_at_slot(preferred) == -1
	):
		return preferred

	for slot_id in range(10):
		if pair_at_slot(slot_id) == -1:
			return slot_id

	return -1


func can_drop_on_slot(
	hand_index: int,
	slot_id: int
) -> bool:
	if animation_busy:
		return false

	if (
		finished
		or hand_index < 0
		or hand_index >= player_hand.size()
	):
		return false

	if slot_id < 0 or slot_id >= 10:
		return false

	var card: Dictionary = player_hand[hand_index]
	var pair_index: int = pair_at_slot(slot_id)

	# Игрок атакует.
	if attacker == 0:
		if pair_index != -1:
			return false

		if table_cards.is_empty():
			return not is_special(card)

		if table_cards.size() >= defender_attack_limit():
			return false

		if not bot_takes and not all_defended():
			return false

		return (
			is_joker(card)
			or (
				card_rank(card) != 100
				and table_has_rank(card_rank(card))
			)
		)

	# Игрок защищается или меняет защиту.
	if pair_index != -1:
		var pair: Dictionary = table_cards[pair_index]

		if pair["defense"].is_empty():
			return (
				is_joker(card)
				or can_beat(card, pair["attack"])
			)

		return (
			is_joker(card)
			or can_beat(card, pair["attack"])
		)

	# Перевод в свободную ячейку.
	if not can_transfer():
		return false

	if bot_hand.size() < table_cards.size() + 1:
		return false

	if is_joker(card):
		return true

	return (
		card_rank(card) != 100
		and table_has_rank(card_rank(card))
	)


func place_selected_on_slot(slot_id: int) -> void:
	if (
		selected_index < 0
		or selected_index >= player_hand.size()
	):
		status_text = "Сначала выбери карту из руки."
		update_ui()
		return

	place_in_slot(selected_index, slot_id)


func place_in_slot(
	hand_index: int,
	slot_id: int
) -> void:
	if not can_drop_on_slot(hand_index, slot_id):
		status_text = "Сюда эту карту положить нельзя."
		update_ui()
		return

	selected_index = hand_index

	var card: Dictionary = player_hand[hand_index]
	var pair_index: int = pair_at_slot(slot_id)

	if attacker == 0:
		if table_cards.is_empty():
			player_attack(hand_index, slot_id)

		elif is_joker(card):
			pending_slot_id = slot_id
			show_joker_choices(
				"throw",
				hand_index,
				-1
			)

		else:
			player_throw(hand_index, card, slot_id)

		return

	if pair_index == -1:
		if is_joker(card):
			pending_slot_id = slot_id
			show_joker_choices(
				"transfer",
				hand_index,
				-1
			)
		else:
			player_transfer(hand_index, card, slot_id)

		return

	if table_cards[pair_index]["defense"].is_empty():
		if is_joker(card):
			show_joker_choices(
				"defend",
				hand_index,
				pair_index
			)
		else:
			player_defend(
				hand_index,
				pair_index,
				card
			)
	else:
		if is_joker(card):
			show_joker_choices(
				"replace",
				hand_index,
				pair_index
			)
		else:
			player_replace(
				hand_index,
				pair_index,
				card
			)


func can_transfer() -> bool:
	if table_cards.is_empty():
		return false

	if table_cards.size() >= round_limit():
		return false

	if free_table_slot() == -1:
		return false

	for pair in table_cards:
		if not pair["defense"].is_empty():
			return false

	return true


func economy_cost(card: Dictionary) -> int:
	if is_mark(card):
		return 1000

	if is_joker(card):
		return 500

	var cost: int = card_rank(card)

	if is_trump(card):
		cost += 100

	return cost


func select_card(index: int) -> void:
	if (
		finished
		or animation_busy
		or index < 0
		or index >= player_hand.size()
	):
		return

	selected_index = index

	if attacker == 0:
		status_text = (
			"Карта выбрана. Нажми свободную ячейку для хода."
		)
	else:
		status_text = (
			"На атаку — отбиться; в пустую ячейку — перевести."
		)

	update_ui()


func field_pressed() -> void:
	place_selected_on_slot(
		free_table_slot()
	)


func table_card_pressed(
	role: String,
	pair_index: int
) -> void:
	if pair_index < 0 or pair_index >= table_cards.size():
		return

	var slot_id: int = slot_for_pair(pair_index)

	if selected_index >= 0:
		place_selected_on_slot(slot_id)
		return

	var target: Dictionary = (
		table_cards[pair_index]["attack"]
		if role == "attack"
		else table_cards[pair_index]["defense"]
	)

	if not target.is_empty() and is_joker(target):
		status_text = (
			"ДЖОКЕР СКОПИРОВАЛ: "
			+ joker_copy_label(target)
		)
		update_ui()
		return

	if role == "attack" and attacker == 1:
		selected_pair = pair_index
		status_text = (
			"Выбери карту для защиты и нажми на атаку."
		)
		update_ui()


func table_targets() -> Array:
	var targets: Array = []

	for pair in table_cards:
		targets.append(pair["attack"])

		if not pair["defense"].is_empty():
			targets.append(pair["defense"])

	return targets


func joker_action_valid(
	card: Dictionary,
	action: String,
	pair_index: int
) -> bool:
	if action == "throw":
		return (
			table_has_rank(card_rank(card))
			and table_cards.size() < defender_attack_limit()
		)

	if action == "transfer":
		return (
			can_transfer()
			and bot_hand.size() >= table_cards.size() + 1
			and table_has_rank(card_rank(card))
		)

	if (
		pair_index < 0
		or pair_index >= table_cards.size()
	):
		return false

	var pair: Dictionary = table_cards[pair_index]

	if action == "defend":
		return (
			pair["defense"].is_empty()
			and can_beat(card, pair["attack"])
		)

	if action == "replace":
		return (
			not pair["defense"].is_empty()
			and can_beat(card, pair["attack"])
		)

	return false


func show_joker_choices(
	action: String,
	index: int,
	pair_index: int
) -> void:
	if index < 0 or index >= player_hand.size():
		return

	pending_joker_action = action
	pending_joker_index = index
	pending_pair_index = pair_index
	clear_children(joker_options)

	var count: int = 0
	var seen: Array = []

	for target in table_targets():
		var key: String = (
			str(card_rank(target))
			+ card_suit(target)
		)

		if seen.has(key):
			continue

		seen.append(key)

		var copied: Dictionary = copy_joker(
			player_hand[index],
			target
		)

		if not joker_action_valid(
			copied,
			action,
			pair_index
		):
			continue

		var button: Button = make_button(
			"Копировать " + card_name(target),
			choose_joker.bind(
				target.duplicate(true)
			)
		)

		joker_options.add_child(button)
		count += 1

	if count == 0 and action == "transfer":
		status_text = (
			"Джокеру нечего копировать для перевода."
		)
		update_ui()
		return

	if count == 0:
		status_text = (
			"Нет подходящей карты для копирования."
		)
		update_ui()
		return

	joker_dialog.popup_centered(
		Vector2i(320, 300)
	)


func choose_joker(target: Dictionary) -> void:
	joker_dialog.hide()

	if (
		pending_joker_index < 0
		or pending_joker_index >= player_hand.size()
	):
		return

	var copied: Dictionary = copy_joker(
		player_hand[pending_joker_index],
		target
	)

	if not joker_action_valid(
		copied,
		pending_joker_action,
		pending_pair_index
	):
		return

	match pending_joker_action:
		"throw":
			player_throw(
				pending_joker_index,
				copied,
				pending_slot_id
			)

		"transfer":
			player_transfer(
				pending_joker_index,
				copied,
				pending_slot_id
			)

		"defend":
			player_defend(
				pending_joker_index,
				pending_pair_index,
				copied
			)

		"replace":
			player_replace(
				pending_joker_index,
				pending_pair_index,
				copied
			)


func player_attack(
	index: int,
	slot_id: int = 0
) -> void:
	if attacker != 0:
		return

	if not table_cards.is_empty():
		return

	if (
		slot_id < 0
		or slot_id >= 10
		or pair_at_slot(slot_id) != -1
	):
		return

	var card: Dictionary = player_hand[index]

	if is_special(card):
		status_text = "Джокер и метка не начинают атаку."
		update_ui()
		return

	player_hand.remove_at(index)

	table_cards.append({
		"attack": card,
		"defense": {},
		"slot_id": slot_id
	})

	selected_index = -1
	status_text = "Компьютер отбивается..."
	update_ui()
	bot_defend()


func player_defend(
	index: int,
	pair_index: int,
	card: Dictionary
) -> void:
	if attacker != 1:
		return

	if (
		pair_index < 0
		or pair_index >= table_cards.size()
	):
		return

	if not table_cards[pair_index]["defense"].is_empty():
		return

	if not can_beat(
		card,
		table_cards[pair_index]["attack"]
	):
		status_text = "Эта карта не отбивает атаку."
		update_ui()
		return

	player_hand.remove_at(index)
	table_cards[pair_index]["defense"] = card

	selected_index = -1
	selected_pair = -1

	status_text = "Отбито!"
	update_ui()

	if all_defended():
		bot_throw()


func player_replace(
	index: int,
	pair_index: int,
	card: Dictionary
) -> void:
	if finished or animation_busy or attacker != 1:
		return

	if index < 0 or index >= player_hand.size():
		return

	if pair_index < 0 or pair_index >= table_cards.size():
		return

	var pair: Dictionary = table_cards[pair_index]

	if pair["defense"].is_empty():
		return

	var old_card: Dictionary = pair["defense"]

	if not can_beat(card, pair["attack"]):
		status_text = "Новая карта не отбивает атаку."
		update_ui()
		return

	var wasteful: bool = (
		(is_trump(card) and not is_trump(old_card))
		or economy_cost(card) >= economy_cost(old_card)
	)

	if wasteful:
		pending_replacement = {
			"index": index,
			"pair": pair_index,
			"card": card.duplicate(true),
			"old": old_card.duplicate(true),
			"attack": pair["attack"].duplicate(true)
		}

		replace_confirmation.dialog_text = (
			"Точно заменить защиту?\n\n"
			+ "Атака: " + card_name(pair["attack"]) + "\n"
			+ "Старая защита: " + card_name(old_card) + "\n"
			+ "Новая защита: " + card_name(card) + "\n\n"
			+ (
				"⚠ Ты тратишь козырь!\n"
				if is_trump(card)
				else "⚠ Новая карта не экономнее старой.\n"
			)
			+ "Старая карта вернётся в руку, но её достоинство "
			+ "останется доступным для подкидывания."
		)

		replace_confirmation.popup_centered(
			Vector2i(370, 280)
		)
		return

	apply_replacement(index, pair_index, card)


func confirm_replacement() -> void:
	if pending_replacement.is_empty():
		return

	var request: Dictionary = (
		pending_replacement.duplicate(true)
	)
	pending_replacement.clear()

	var index: int = int(request["index"])
	var pair_index: int = int(request["pair"])

	if finished or animation_busy or attacker != 1:
		return

	if index < 0 or index >= player_hand.size():
		return

	if (
		pair_index < 0
		or pair_index >= table_cards.size()
	):
		return

	var pair: Dictionary = table_cards[pair_index]

	if (
		JSON.stringify(pair["defense"])
		!= JSON.stringify(request["old"])
	):
		return

	if (
		JSON.stringify(pair["attack"])
		!= JSON.stringify(request["attack"])
	):
		return

	if is_joker(request["card"]):
		if not is_joker(player_hand[index]):
			return

		if (
			str(request["card"]["joker_color"])
			!= str(player_hand[index]["joker_color"])
		):
			return

	elif (
		JSON.stringify(player_hand[index])
		!= JSON.stringify(request["card"])
	):
		return

	apply_replacement(
		index,
		pair_index,
		request["card"]
	)


func apply_replacement(
	index: int,
	pair_index: int,
	card: Dictionary
) -> void:
	if (
		pair_index < 0
		or pair_index >= table_cards.size()
	):
		return

	if index < 0 or index >= player_hand.size():
		return

	var pair: Dictionary = table_cards[pair_index]

	if (
		pair["defense"].is_empty()
		or not can_beat(card, pair["attack"])
	):
		return

	var old_card: Dictionary = pair["defense"]

	if not replaced_throw_ranks.has(
		card_rank(old_card)
	):
		replaced_throw_ranks.append(
			card_rank(old_card)
		)

	table_cards[pair_index]["defense"] = card
	player_hand[index] = reset_joker(old_card)
	selected_index = -1

	status_text = (
		"Защита заменена на "
		+ card_name(card)
		+ ". Бот может подкинуть достоинство старой защиты."
	)

	update_ui()

	if all_defended():
		bot_throw()


func player_throw(
	index: int,
	card: Dictionary,
	slot_id: int = -1
) -> void:
	if attacker != 0:
		return

	if table_cards.is_empty():
		return

	if not bot_takes and not all_defended():
		status_text = "Компьютер ещё отбивается."
		update_ui()
		return

	if table_cards.size() >= defender_attack_limit():
		status_text = "Лимит карт на столе."
		update_ui()
		return

	if slot_id == -1:
		slot_id = free_table_slot()

	if (
		slot_id < 0
		or slot_id >= 10
		or pair_at_slot(slot_id) != -1
	):
		status_text = (
			"Выбери свободную ячейку для подкидывания."
		)
		update_ui()
		return

	if (
		(card_rank(card) == 100 and not is_joker(card))
		or not table_has_rank(card_rank(card))
	):
		status_text = "Нельзя подкинуть эту карту."
		update_ui()
		return

	player_hand.remove_at(index)

	table_cards.append({
		"attack": card,
		"defense": {},
		"slot_id": slot_id
	})

	selected_index = -1
	status_text = "Карта подкинута!"
	update_ui()

	if not bot_takes:
		bot_defend()


func player_transfer(
	index: int,
	card: Dictionary,
	slot_id: int = -1
) -> void:
	if attacker != 1:
		return

	if not can_transfer():
		return

	if (
		(card_rank(card) == 100 and not is_joker(card))
		or not table_has_rank(card_rank(card))
		or bot_hand.size() < table_cards.size() + 1
	):
		status_text = "Перевод невозможен."
		update_ui()
		return

	if slot_id == -1:
		slot_id = free_table_slot()

	if (
		slot_id < 0
		or slot_id >= 10
		or pair_at_slot(slot_id) != -1
	):
		status_text = (
			"Для перевода выбери свободную ячейку."
		)
		update_ui()
		return

	player_hand.remove_at(index)

	table_cards.append({
		"attack": card,
		"defense": {},
		"slot_id": slot_id
	})

	attacker = 0
	selected_index = -1
	selected_pair = -1

	status_text = "Перевод! Компьютер защищается."
	update_ui()
	bot_defend()


func bot_cost(card: Dictionary) -> int:
	return economy_cost(card)


func bot_matching_card(index: int) -> Dictionary:
	var card: Dictionary = bot_hand[index]

	if is_mark(card):
		return {}

	if not is_joker(card):
		if table_has_rank(card_rank(card)):
			return card
		return {}

	for target in table_targets():
		var copied: Dictionary = copy_joker(
			card,
			target
		)

		if table_has_rank(card_rank(copied)):
			return copied

	return {}


func bot_try_transfer() -> bool:
	if bot_difficulty == 0:
		return false

	if attacker != 0:
		return false

	if not can_transfer():
		return false

	if player_hand.size() < table_cards.size() + 1:
		return false

	var best_index: int = -1
	var best_card: Dictionary = {}
	var best_cost: int = 9999

	for i in range(bot_hand.size()):
		var candidate: Dictionary = bot_matching_card(i)

		if candidate.is_empty():
			continue

		if bot_cost(candidate) < best_cost:
			best_index = i
			best_card = candidate
			best_cost = bot_cost(candidate)

	if best_index == -1:
		return false

	var transfer_chance: int = (
		40 if bot_difficulty == 1 else 85
	)

	if randi_range(1, 100) > transfer_chance:
		return false

	bot_hand.remove_at(best_index)

	table_cards.append({
		"attack": best_card,
		"defense": {},
		"slot_id": free_table_slot()
	})

	attacker = 1
	selected_pair = -1

	status_text = "Компьютер перевёл! Защищайся."
	update_ui()
	return true


func bot_defend() -> void:
	if bot_takes:
		status_text = (
			"Компьютер забирает. "
			+ "Подкинь или нажми «Бито!»."
		)
		update_ui()
		return

	if bot_try_transfer():
		return

	while true:
		var pair_index: int = unbeaten_pair()

		if pair_index == -1:
			break

		var attack_card: Dictionary = (
			table_cards[pair_index]["attack"]
		)

		var best_index: int = -1
		var best_card: Dictionary = {}
		var best_cost: int = 9999

		for i in range(bot_hand.size()):
			var candidate: Dictionary = bot_hand[i]
			var possibilities: Array = []

			if is_joker(candidate):
				for target in table_targets():
					possibilities.append(
						copy_joker(candidate, target)
					)
			else:
				possibilities.append(candidate)

			for test_card in possibilities:
				if can_beat(test_card, attack_card):
					var cost: int = bot_cost(test_card)

					if bot_difficulty == 0:
						cost = randi_range(0, 999)

					elif bot_difficulty == 2:
						if is_trump(test_card):
							cost += 70

						if is_joker(test_card):
							cost += 100

					if cost < best_cost:
						best_index = i
						best_card = test_card
						best_cost = cost

		if best_index == -1:
			# Бот добирает только до шести карт.
			if (
				bot_hand.size() < 6
				and not deck.is_empty()
			):
				bot_hand.append(deck.pop_back())
				status_text = (
					"Компьютер добирает 1 карту для защиты..."
				)
				update_ui()

				fly_back(
					local_ghost_point(deck_panel if deck_panel.visible else deck_info),
					local_ghost_point(enemy_back_scroll),
					0.27
				)
				continue

			bot_takes = true
			status_text = (
				"Компьютер забирает! "
				+ "Подкинь или нажми «Бито!»."
			)
			update_ui()
			return

		bot_hand.remove_at(best_index)

		table_cards[pair_index]["defense"] = (
			best_card
		)

	status_text = (
		"Компьютер отбился. "
		+ "Подкинь или нажми «Бито!»."
	)
	update_ui()


func bot_throw() -> void:
	if attacker != 1:
		return

	if free_table_slot() == -1:
		return

	if not all_defended():
		return

	if (
		table_cards.size() >= defender_attack_limit()
		or player_hand.is_empty()
	):
		status_text = "Нажми «Бито!»."
		update_ui()
		return

	var best_index: int = -1
	var best_card: Dictionary = {}
	var best_cost: int = 9999

	for i in range(bot_hand.size()):
		var candidate: Dictionary = bot_matching_card(i)

		if candidate.is_empty():
			continue

		if bot_cost(candidate) < best_cost:
			best_index = i
			best_card = candidate
			best_cost = bot_cost(candidate)

	if best_index == -1:
		status_text = (
			"Компьютеру нечего подкинуть. "
			+ "Нажми «Бито!»."
		)
		update_ui()
		return

	var throw_chance: int = (
		20 if bot_difficulty == 0
		else (70 if bot_difficulty == 1 else 100)
	)

	if randi_range(1, 100) > throw_chance:
		status_text = (
			"Компьютер больше не подкидывает. "
			+ "Нажми «Бито!»."
		)
		update_ui()
		return

	bot_hand.remove_at(best_index)

	table_cards.append({
		"attack": best_card,
		"defense": {},
		"slot_id": free_table_slot()
	})

	selected_pair = table_cards.size() - 1

	status_text = (
		"Компьютер подкинул "
		+ card_name(best_card)
	)
	update_ui()


func bot_attack() -> void:
	draw_to_six(bot_hand)

	var best_index: int = -1
	var best_score: int = 99999

	for i in range(bot_hand.size()):
		var candidate: Dictionary = bot_hand[i]

		if is_special(candidate):
			continue

		if bot_difficulty == 0:
			if (
				best_index == -1
				or randi_range(0, 1) == 0
			):
				best_index = i

		else:
			var score: int = card_rank(candidate)

			if bot_difficulty == 2:
				score = economy_cost(candidate)

				for j in range(bot_hand.size()):
					if (
						i != j
						and card_rank(bot_hand[j])
						== card_rank(candidate)
					):
						score -= 12

			if score < best_score:
				best_index = i
				best_score = score

	if best_index == -1:
		check_winner()

		if finished:
			return

		attacker = 0
		status_text = (
			"Компьютер пропускает ход. Твой ход!"
		)
		update_ui()
		return

	var card: Dictionary = bot_hand[best_index]
	bot_hand.remove_at(best_index)

	table_cards.append({
		"attack": card,
		"defense": {},
		"slot_id": free_table_slot()
	})

	attacker = 1
	selected_pair = 0
	bot_takes = false

	status_text = (
		"Компьютер атакует: "
		+ card_name(card)
	)
	update_ui()


func draw_cards() -> void:
	if finished or animation_busy:
		return

	if deck.is_empty():
		status_text = "Колода закончилась."

	elif player_hand.size() >= 6:
		status_text = "У тебя уже 6 карт."

	else:
		player_hand.append(deck.pop_back())
		status_text = "Добрана 1 карта."
		pulse(deck_panel)

	update_ui()


func take_cards() -> void:
	if finished or animation_busy:
		return

	if attacker != 1 or table_cards.is_empty():
		return

	var animation_expected: int = animation_serial

	if animation_enabled:
		status_text = "Карты возвращаются в твою руку..."
		update_ui()

		await animate_collection(false)

		if animation_expected != animation_serial:
			return

	for pair in table_cards:
		player_hand.append(
			reset_joker(pair["attack"])
		)

		if not pair["defense"].is_empty():
			player_hand.append(
				reset_joker(pair["defense"])
			)

	table_cards.clear()
	replaced_throw_ranks.clear()
	remembered_table_faces.clear()

	draw_to_six(player_hand)
	draw_to_six(bot_hand)

	first_round = false
	selected_index = -1
	selected_pair = -1
	attacker = 1
	bot_takes = false

	check_winner()

	if finished:
		return

	status_text = "Ты забрал карты. Ход компьютера."
	update_ui()
	bot_attack()


func finish_round() -> void:
	if finished or animation_busy:
		return

	if table_cards.is_empty():
		return

	if not bot_takes and not all_defended():
		status_text = "Нельзя Бито: не все карты отбиты."
		update_ui()
		return

	var animation_expected: int = animation_serial

	if animation_enabled:
		status_text = (
			"Бот забирает карты..."
			if bot_takes
			else "Бито! Карты уходят в отбой..."
		)
		update_ui()

		await animate_collection(
			bot_takes,
			not bot_takes
		)

		if animation_expected != animation_serial:
			return

	if bot_takes:
		for pair in table_cards:
			bot_hand.append(
				reset_joker(pair["attack"])
			)

			if not pair["defense"].is_empty():
				bot_hand.append(
					reset_joker(pair["defense"])
				)

		table_cards.clear()
		replaced_throw_ranks.clear()
		remembered_table_faces.clear()

		bot_takes = false
		attacker = 0

	elif all_defended():
		for pair in table_cards:
			discard_pile.append(
				pair["attack"]
			)

			if not pair["defense"].is_empty():
				discard_pile.append(
					pair["defense"]
				)

		table_cards.clear()
		replaced_throw_ranks.clear()
		remembered_table_faces.clear()

		if attacker == 0:
			draw_to_six(player_hand)
			draw_to_six(bot_hand)
			attacker = 1
		else:
			draw_to_six(bot_hand)
			draw_to_six(player_hand)
			attacker = 0

	else:
		status_text = (
			"Сначала отбей все карты "
			+ "или забери их."
		)
		update_ui()
		return

	draw_to_six(player_hand)
	draw_to_six(bot_hand)

	first_round = false
	selected_index = -1
	selected_pair = -1

	check_winner()

	if finished:
		return

	if attacker == 0:
		status_text = "Твой ход!"
	else:
		status_text = "Ход компьютера."

	update_ui()

	if attacker == 1:
		bot_attack()


func clear_finale() -> void:
	finale_id += 1

	if (
		finale_overlay != null
		and is_instance_valid(finale_overlay)
	):
		finale_overlay.queue_free()

	finale_overlay = null


func show_finale(
	won: bool,
	result_text: String
) -> void:
	if not animation_enabled:
		result_dialog.dialog_text = result_text
		result_dialog.popup_centered()
		return

	clear_finale()

	var cycle: int = finale_id
	var bounds: Vector2 = get_viewport_rect().size
	var mid: Vector2 = bounds * 0.5

	var accent: Color = (
		Color("#FFD88A")
		if won
		else Color("#FF648A")
	)

	finale_overlay = Control.new()
	finale_overlay.name = "GameFinale"
	finale_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(finale_overlay)

	finale_overlay.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	var shade: ColorRect = ColorRect.new()
	shade.color = Color(0.05, 0.0, 0.1, 0.0)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	finale_overlay.add_child(shade)
	shade.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	var shade_tween: Tween = create_tween()

	shade_tween.tween_property(
		shade,
		"color",
		Color(0.04, 0.01, 0.08, 0.9)
		if won
		else Color(0.16, 0.01, 0.07, 0.94),
		0.46
	)

	for i in range(40 if won else 22):
		var particle: Label = Label.new()
		particle.mouse_filter = Control.MOUSE_FILTER_IGNORE

		particle.text = str(
			["✦", "★", "♥", "♦", "♠", "♣"][i % 6]
			if won
			else ["✦", "◆", "♦"][i % 3]
		)

		particle.add_theme_font_size_override(
			"font_size",
			randi_range(13, 29)
		)

		particle.add_theme_color_override(
			"font_color",
			[
				Color("#FFE9A9"),
				Color("#DAB0FF"),
				Color("#FF77CD"),
				Color("#89EEFF")
			][i % 4]
			if won
			else [
				Color("#FF386B"),
				Color("#9640B0")
			][i % 2]
		)

		finale_overlay.add_child(particle)

		var source: Vector2 = (
			mid
			if won
			else Vector2(
				randf() * bounds.x,
				randf_range(-100.0, -25.0)
			)
		)

		var angle: float = randf_range(0.0, TAU)
		var distance: float = randf_range(
			90.0,
			maxf(
				110.0,
				minf(bounds.x, bounds.y) * 0.57
			)
		)

		var destination: Vector2 = (
			source
			+ Vector2(cos(angle), sin(angle)) * distance
			if won
			else Vector2(
				source.x
				+ randf_range(-100.0, 100.0),
				bounds.y + 40.0
			)
		)

		particle.position = source
		particle.modulate.a = 0.0

		var flight: Tween = create_tween()
		flight.set_parallel(true)

		flight.tween_property(
			particle,
			"position",
			destination,
			randf_range(1.4, 2.5)
		).set_trans(
			Tween.TRANS_QUAD
		).set_ease(
			Tween.EASE_OUT
		)

		flight.tween_property(
			particle,
			"rotation",
			randf_range(-4.0, 4.0),
			1.6
		)

		flight.tween_property(
			particle,
			"modulate:a",
			1.0,
			0.23
		)

		flight.chain().tween_property(
			particle,
			"modulate:a",
			0.0,
			0.7
		).set_delay(0.65)

	var centered: CenterContainer = CenterContainer.new()
	finale_overlay.add_child(centered)
	centered.set_anchors_and_offsets_preset(
		Control.PRESET_FULL_RECT
	)

	var panel: PanelContainer = PanelContainer.new()
	panel.custom_minimum_size = Vector2(
		minf(380.0, bounds.x - 24.0),
		282.0
	)

	panel.add_theme_stylebox_override(
		"panel",
		make_style(
			Color("#291044")
			if won
			else Color("#2A0918"),
			accent,
			18
		)
	)
	centered.add_child(panel)

	var body: VBoxContainer = VBoxContainer.new()
	body.add_theme_constant_override(
		"separation",
		11
	)
	panel.add_child(body)

	var icon_line: Label = make_label(
		"✦ ✦ ✦"
		if won
		else "◆ ◆ ◆",
		29,
		accent
	)
	body.add_child(icon_line)

	var heading: Label = make_label(
		"ПОБЕДА!"
		if won
		else "ПОРАЖЕНИЕ",
		33,
		accent
	)
	body.add_child(heading)

	var details: Label = make_label(
		result_text,
		15,
		LIGHT
	)
	details.custom_minimum_size = Vector2(0, 44)
	body.add_child(details)

	var replay: Button = make_button(
		"↻  ИГРАТЬ СНОВА",
		new_game
	)
	replay.name = "FinaleReplay"
	replay.custom_minimum_size.y = 47
	replay.disabled = true
	replay.modulate.a = 0.0
	body.add_child(replay)

	var home: Button = make_button(
		"⌂  ГЛАВНОЕ МЕНЮ",
		show_menu
	)
	home.name = "FinaleHome"
	home.custom_minimum_size.y = 47
	home.disabled = true
	home.modulate.a = 0.0
	body.add_child(home)

	panel.pivot_offset = (
		panel.custom_minimum_size * 0.5
	)
	panel.scale = Vector2(0.70, 0.70)
	panel.modulate.a = 0.0

	var entry: Tween = create_tween()
	entry.set_parallel(true)

	entry.tween_property(
		panel,
		"scale",
		Vector2.ONE,
		0.58
	).set_trans(
		Tween.TRANS_BACK
	).set_ease(
		Tween.EASE_OUT
	)

	entry.tween_property(
		panel,
		"modulate:a",
		1.0,
		0.36
	)

	entry.chain().tween_property(
		replay,
		"modulate:a",
		1.0,
		0.28
	).set_delay(0.34)
	entry.parallel().tween_property(
		home, "modulate:a", 1.0, 0.28
	)

	entry.chain().tween_callback(
		func() -> void:
			if (
				finale_id == cycle
				and is_instance_valid(replay)
				and is_instance_valid(home)
			):
				replay.disabled = false
				home.disabled = false
	)

	var shimmer: Tween = create_tween()
	shimmer.set_loops(3)

	shimmer.tween_property(
		icon_line,
		"modulate",
		Color("#FFFFFF"),
		0.22
	)

	shimmer.tween_property(
		icon_line,
		"modulate",
		accent,
		0.33
	)


func only_special(hand: Array) -> bool:
	if hand.is_empty():
		return false

	for card in hand:
		if not is_special(card):
			return false

	return true


func check_winner() -> void:
	if (
		finished
		or not deck.is_empty()
		or not table_cards.is_empty()
	):
		return

	var result: String = ""

	if player_hand.is_empty() and bot_hand.is_empty():
		result = "Ничья!"

	elif player_hand.is_empty():
		result = player_nick + ", ты победил!"

	elif bot_hand.is_empty():
		result = "Компьютер победил!"

	elif only_special(player_hand) and attacker == 0:
		result = (
			"Компьютер победил! "
			+ "У тебя остались особые карты."
		)

	elif only_special(bot_hand) and attacker == 1:
		result = (
			player_nick
			+ ", ты победил! "
			+ "У бота остались особые карты."
		)

	if result.is_empty():
		return

	finished = true
	var won: bool = result.contains("ты победил")
	show_finale(won, result)


func local_ghost_point(control: Control) -> Vector2:
	if control == null or motion_layer == null:
		return Vector2.ZERO

	return (
		control.get_global_rect().get_center()
		- motion_layer.get_global_rect().position
	)


func fly_back(
	start: Vector2,
	finish: Vector2,
	duration: float = 0.23
) -> void:
	if not animation_enabled or motion_layer == null:
		return

	var ghost: PanelContainer = make_card_back(
		maxf(37.0, card_width * 0.60),
		maxf(49.0, card_width * 0.80)
	)

	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	motion_layer.add_child(ghost)
	ghost.position = (
		start - ghost.custom_minimum_size * 0.5
	)

	var tween: Tween = create_tween()

	tween.tween_property(
		ghost,
		"position",
		finish - ghost.custom_minimum_size * 0.5,
		duration
	).set_trans(
		Tween.TRANS_CUBIC
	).set_ease(
		Tween.EASE_OUT
	)

	tween.parallel().tween_property(
		ghost,
		"modulate:a",
		0.20,
		duration
	)
	tween.tween_callback(ghost.queue_free)


func fly_face(
	card: Dictionary,
	start: Vector2,
	finish: Vector2,
	duration: float = 0.32
) -> void:
	if not animation_enabled or motion_layer == null:
		return

	var ghost: GameCard = make_card_view(
		card,
		"ghost",
		-1,
		-1
	)

	ghost.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ghost.disabled = true
	motion_layer.add_child(ghost)
	ghost.position = (
		start - ghost.custom_minimum_size * 0.5
	)

	var tween: Tween = create_tween()

	tween.tween_property(
		ghost,
		"position",
		finish - ghost.custom_minimum_size * 0.5,
		duration
	).set_trans(
		Tween.TRANS_CUBIC
	).set_ease(
		Tween.EASE_OUT
	)

	tween.parallel().tween_property(
		ghost,
		"modulate:a",
		0.12,
		duration
	)

	tween.tween_callback(ghost.queue_free)


func play_deal_animation() -> void:
	animation_busy = true
	var serial: int = animation_serial

	hand_row.modulate.a = 0.0
	enemy_backs.modulate.a = 0.0
	status_text = "Перемешиваем колоду..."
	update_ui()

	for i in range(5):
		if serial != animation_serial:
			return

		var center: Vector2 = local_ghost_point(
			deck_panel if deck_panel.visible else deck_info
		)

		var direction: float = (
			-1.0 if i % 2 == 0 else 1.0
		)

		fly_back(
			center + Vector2(direction * 19.0, -14.0),
			center + Vector2(-direction * 19.0, 14.0),
			0.19
		)

		await get_tree().create_timer(
			0.075, false
		).timeout

	if serial != animation_serial:
		return

	status_text = "Раздаём карты..."
	update_ui()

	for i in range(6):
		if serial != animation_serial:
			return

		var deck_center: Vector2 = local_ghost_point(
			deck_panel if deck_panel.visible else deck_info
		)

		fly_back(
			deck_center,
			local_ghost_point(enemy_back_scroll),
			0.23
		)

		await get_tree().create_timer(
			0.07, false
		).timeout

		if serial != animation_serial:
			return

		fly_back(
			deck_center,
			local_ghost_point(hand_scroll),
			0.23
		)

		await get_tree().create_timer(
			0.09, false
		).timeout

	if serial != animation_serial:
		return

	hand_row.modulate.a = 1.0
	enemy_backs.modulate.a = 1.0
	animation_busy = false

	status_text = (
		"Первым ходит компьютер."
		if attacker == 1
		else "Твой ход."
	)

	update_ui()

	if attacker == 1:
		bot_attack()


func animate_collection(
	to_bot: bool,
	to_discard: bool = false
) -> void:
	if not animation_enabled or motion_layer == null:
		return

	animation_busy = true
	var serial: int = animation_serial

	var destination: Control = (
		(deck_panel if deck_panel.visible else deck_info)
		if to_discard
		else (
			enemy_back_scroll
			if to_bot
			else hand_scroll
		)
	)

	var finish: Vector2 = local_ghost_point(
		destination
	)

	for pair_index in range(table_cards.size()):
		var pair: Dictionary = table_cards[pair_index]
		var slot: int = slot_for_pair(pair_index)

		if (
			slot < 0
			or slot >= table_grid.get_child_count()
		):
			continue

		var slot_node: Control = (
			table_grid.get_child(slot) as Control
		)

		var start: Vector2 = local_ghost_point(
			slot_node
		)

		fly_face(
			pair["attack"],
			start,
			finish,
			0.34
		)

		if not pair["defense"].is_empty():
			fly_face(
				pair["defense"],
				start + Vector2(8.0, 18.0),
				finish + Vector2(12.0, 0.0),
				0.36
			)

	table_grid.modulate.a = 0.42

	await get_tree().create_timer(
		0.41, false
	).timeout

	if serial != animation_serial:
		return

	table_grid.modulate.a = 1.0
	animation_busy = false


func animate_table_card(
	card_view: GameCard,
	defense: bool,
	from_bot: bool
) -> void:
	if not animation_enabled:
		return

	var target: Vector2 = card_view.position
	var offset: Vector2

	if defense:
		offset = Vector2(-6.0, 12.0)
	else:
		offset = Vector2(
			0.0,
			-card_width * 0.26 if from_bot else card_width * 0.26
		)

	card_view.position = target + offset
	card_view.modulate.a = 0.45

	var tween: Tween = create_tween()

	tween.tween_property(
		card_view,
		"position",
		target,
		0.22
	).set_trans(
		Tween.TRANS_CUBIC
	).set_ease(
		Tween.EASE_OUT
	)

	tween.parallel().tween_property(
		card_view,
		"modulate:a",
		1.0,
		0.22
	)


func make_card_view(
	card: Dictionary,
	role: String,
	hand_index: int,
	pair_index: int
) -> GameCard:
	var view: GameCard = GameCard.new()

	view.game = self
	view.card = card.duplicate(true)
	view.role = role
	view.hand_index = hand_index
	view.pair_index = pair_index
	# Fingers need a larger target on narrow screens, even if the
	# portrait card art itself must remain small to fit five slots.
	var touch_width: float = card_width
	if role == "hand" and get_viewport_rect().size.y >= get_viewport_rect().size.x:
		touch_width = maxf(44.0, card_width)
	view.custom_minimum_size = Vector2(touch_width, card_height)
	view.size = view.custom_minimum_size
	view.clip_contents = true

	var uses_original_art: bool = card_face_texture(card) != null

	if uses_original_art:
		# The original image has a black edge, not a white paper edge.
		# Disable the old white Godot Button background and its 6 px margins.
		view.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		var plain: StyleBoxFlat = make_style(
			Color("#010005"), Color("#010005"), 0
		)
		plain.set_border_width_all(0)
		plain.set_content_margin_all(0)
		plain.set_corner_radius_all(0)
		view.add_theme_stylebox_override("normal", plain)
		view.add_theme_stylebox_override("hover", plain)
		view.add_theme_stylebox_override("pressed", plain)
		view.add_theme_stylebox_override("focus", plain)
		view.add_theme_stylebox_override("disabled", plain)
	else:
		# Fall back to the existing drawn cards if the atlas is missing.
		var background: Color = Color("#FFF8FF")
		var border: Color = Color("#8D50BC")
		if role == "hand" and hand_index == selected_index:
			background = Color("#E4C6FF")
			border = Color.WHITE
		view.add_theme_stylebox_override(
			"normal", make_style(background, border, 9)
		)
		view.add_theme_stylebox_override(
			"hover", make_style(Color("#F1DCFF"), Color.WHITE, 9)
		)
		view.add_theme_stylebox_override(
			"pressed", make_style(Color("#E4C6FF"), Color.WHITE, 9)
		)

	if role == "hand":
		if hand_index == selected_index:
			view.modulate = Color("#E8C8FF")
		view.pressed.connect(select_card.bind(hand_index))
	else:
		view.pressed.connect(table_card_pressed.bind(role, pair_index))

	return view

func update_ui() -> void:
	if game_screen == null:
		return

	if not game_screen.visible:
		return

	refresh_enemy_backs()

	bot_label.text = (
		"КОМПЬЮТЕР · %d карт"
		% bot_hand.size()
	)

	player_label.text = (
		"%s · %d карт"
		% [
			player_nick,
			player_hand.size()
		]
	)

	deck_label.text = (
		"%d карт" % deck.size()
	)

	discard_label.text = (
		"БИТО: %d" % discard_pile.size()
	)

	trump_label.text = trump_display_name()
	update_trump_symbol()

	var screen_size: Vector2 = get_viewport_rect().size
	var compact_deck: bool = (
		screen_size.y >= screen_size.x and screen_size.x <= 900.0
	)
	deck_panel.visible = not deck.is_empty() and not compact_deck
	if mobile_deck_label != null:
		mobile_deck_label.text = "КОЛОДА · %d" % deck.size()
	if mobile_discard_label != null:
		mobile_discard_label.text = "БИТО · %d" % discard_pile.size()
	if mobile_trump_label != null:
		var short_trump: String = trump_display_name().replace("\n", " + ")
		if trump_mode == "suit":
			short_trump = trump_suit + " " + short_trump
		mobile_trump_label.text = short_trump
	status_label.text = status_text

	var table_key: String = (
		JSON.stringify(table_cards)
		+ "|"
		+ str(snapped(card_width, 0.1))
		+ "|"
		+ str(selected_index)
		+ "|"
		+ str(attacker)
		+ "|"
		+ str(bot_takes)
	)

	if table_key != last_table_visual_key:
		last_table_visual_key = table_key
		clear_children(table_grid)

		for i in range(10):
			var slot: TableSlot = TableSlot.new()
			slot.name = "Slot_%d" % i
			slot.game = self
			slot.slot_id = i
			slot.custom_minimum_size = Vector2(
				slot_width,
				slot_height
			)
			table_grid.add_child(slot)

			var pair_index: int = pair_at_slot(i)

			if pair_index == -1:
				var empty_place: PanelContainer = (
					PanelContainer.new()
				)

				empty_place.mouse_filter = (
					Control.MOUSE_FILTER_IGNORE
				)
				empty_place.custom_minimum_size = Vector2(
					card_width,
					card_height
				)

				empty_place.add_theme_stylebox_override(
					"panel",
					make_style(
						Color("#241238"),
						Color("#58377A"),
						9
					)
				)

				slot.add_child(empty_place)
				empty_place.position = Vector2(4, 2)

				if (
					selected_index >= 0
					and can_drop_on_slot(selected_index, i)
				):
					var hint: Label = make_label(
						"ХОД"
						if attacker == 0
						else "ПЕРЕВОД",
						10,
						GOLD
					)

					hint.mouse_filter = (
						Control.MOUSE_FILTER_IGNORE
					)
					hint.custom_minimum_size = Vector2(
						card_width,
						30
					)

					slot.add_child(hint)
					hint.position = Vector2(
						4,
						card_height * 0.40
					)

				continue

			var pair: Dictionary = table_cards[pair_index]

			var attack_card: GameCard = make_card_view(
				pair["attack"],
				"attack",
				-1,
				pair_index
			)

			slot.add_child(attack_card)
			attack_card.position = Vector2(1, 1)
			attack_card.tooltip_text = "АТАКА: " + card_name(pair["attack"])

			var attack_visual_key: String = (
				"%d:attack" % i
			)
			var attack_signature: String = (
				JSON.stringify(pair["attack"])
			)

			if (
				remembered_table_faces.get(
					attack_visual_key,
					""
				) != attack_signature
			):
				remembered_table_faces[
					attack_visual_key
				] = attack_signature

				animate_table_card(
					attack_card,
					false,
					attacker == 1
				)

			if pair["defense"].is_empty():
				var defend_button: Button = make_button(
					"↘ ЗАЩИТА",
					table_card_pressed.bind(
						"attack",
						pair_index
					)
				)

				defend_button.custom_minimum_size = Vector2(
					card_width,
					26
				)
				defend_button.add_theme_font_size_override(
					"font_size",
					10
				)

				slot.add_child(defend_button)
				defend_button.position = Vector2(
					0,
					card_height + 1
				)

			else:
				var defense_card: GameCard = make_card_view(
					pair["defense"],
					"defense",
					-1,
					pair_index
				)

				slot.add_child(defense_card)
				defense_card.position = Vector2(12, 12) if landscape_mode == false else Vector2(16, 15)
				defense_card.tooltip_text = "ЗАЩИТА: " + card_name(pair["defense"])

				var defense_visual_key: String = (
					"%d:defense" % i
				)
				var defense_signature: String = (
					JSON.stringify(pair["defense"])
				)

				if (
					remembered_table_faces.get(
						defense_visual_key,
						""
					) != defense_signature
				):
					remembered_table_faces[
						defense_visual_key
					] = defense_signature

					animate_table_card(
						defense_card,
						true,
						attacker == 0
					)

			animate_in(
				slot,
				minf(float(i) * 0.02, 0.16)
			)

	# Карты в руке игрока.
	var hand_key: String = (
		JSON.stringify(player_hand)
		+ "|"
		+ str(selected_index)
	)

	if hand_key != last_hand_visual_key:
		last_hand_visual_key = hand_key
		clear_children(hand_row)

		for i in range(player_hand.size()):
			var hand_card: GameCard = make_card_view(
				player_hand[i],
				"hand",
				i,
				-1
			)

			hand_row.add_child(hand_card)

			animate_in(
				hand_card,
				minf(float(i) * 0.025, 0.15)
			)
