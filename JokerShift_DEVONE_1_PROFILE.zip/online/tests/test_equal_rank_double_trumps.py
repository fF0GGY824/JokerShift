"""Double-trump equal-rank defense works in server-validated multiplayer."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from game import Game, RuleError


def card(card_id: int, rank: int, suit: str) -> dict:
    return {"id": card_id, "rank": rank, "suit": suit, "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""}


@pytest.mark.parametrize("mode,trump,attack,defense", [
    ("red", "♥ ♦", "♥", "♦"),
    ("red", "♥ ♦", "♦", "♥"),
    ("black", "♠ ♣", "♠", "♣"),
    ("black", "♠ ♣", "♣", "♠"),
])
def test_equal_rank_other_trump_suit_accepted_by_actual_defense(mode, trump, attack, defense):
    game = Game(["A", "B"])
    game.trump_mode, game.trump_suit = mode, trump
    game.table = [{"attack": card(880, 3, attack), "defense": None}]
    game.hands[game.defender].append(card(881, 3, defense))
    game.act(game.defender, {"action": "defend", "card_id": 881, "pair_index": 0})
    assert game.table[0]["defense"]["id"] == 881


@pytest.mark.parametrize("mode,attack,defense", [
    ("red", "♥", "♥"),
    ("red", "♥", "♠"),
    ("black", "♠", "♠"),
    ("black", "♠", "♥"),
    ("suit", "♥", "♦"),
])
def test_equal_rank_unrelated_suits_rejected(mode, attack, defense):
    game = Game(["A", "B"])
    game.trump_mode, game.trump_suit = mode, "♥" if mode == "suit" else ""
    assert not game._beats(card(882, 3, defense), card(883, 3, attack))


def test_lower_other_trump_suit_does_not_defend():
    game = Game(["A", "B"])
    game.trump_mode = "red"
    assert not game._beats(card(886, 2, "♦"), card(887, 3, "♥"))
