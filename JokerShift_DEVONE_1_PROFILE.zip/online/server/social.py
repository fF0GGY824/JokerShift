"""Small persistent friends directory. Never stores chat messages or plaintext auth tokens.

Identity is a random secret saved on each device; player IDs alone are not credentials.
Use SQLite for single-process WebSocket server deployment. Back up the DB to preserve friends.
"""
from __future__ import annotations

import hashlib
import secrets
import sqlite3
from pathlib import Path


class SocialStore:
    def __init__(self, path: str = "jokershift_social.db"):
        self.db = sqlite3.connect(path)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS accounts (
                id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL, name TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS friendships (
                a TEXT NOT NULL, b TEXT NOT NULL, PRIMARY KEY(a,b),
                FOREIGN KEY(a) REFERENCES accounts(id), FOREIGN KEY(b) REFERENCES accounts(id)
            );
            CREATE TABLE IF NOT EXISTS requests (
                sender TEXT NOT NULL, receiver TEXT NOT NULL, PRIMARY KEY(sender, receiver),
                FOREIGN KEY(sender) REFERENCES accounts(id), FOREIGN KEY(receiver) REFERENCES accounts(id)
            );
            CREATE TABLE IF NOT EXISTS blocks (
                blocker TEXT NOT NULL, blocked TEXT NOT NULL, PRIMARY KEY(blocker, blocked),
                FOREIGN KEY(blocker) REFERENCES accounts(id), FOREIGN KEY(blocked) REFERENCES accounts(id)
            );
            CREATE TABLE IF NOT EXISTS limited_promo_claims (
                code TEXT NOT NULL,
                account_id TEXT NOT NULL REFERENCES accounts(id),
                claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(code, account_id)
            );
        """)
        self.db.commit()

    def authenticate(self, token: str, name: str) -> tuple[str, str, str]:
        if token:
            if not isinstance(token, str) or len(token) != 64:
                raise ValueError("Неверный ключ аккаунта.")
            try:
                bytes.fromhex(token)
            except ValueError as exc:
                raise ValueError("Неверный ключ аккаунта.") from exc
            digest = hashlib.sha256(token.encode("ascii")).hexdigest()
            row = self.db.execute("SELECT id,name FROM accounts WHERE token_hash=?", (digest,)).fetchone()
            if not row:
                raise ValueError("Профиль не найден. Проверь сохранённый ключ на устройстве.")
            user_id, _ = row
            self.db.execute("UPDATE accounts SET name=? WHERE id=?", (name, user_id))
            self.db.commit()
            return user_id, token, name
        token = secrets.token_hex(32)
        digest = hashlib.sha256(token.encode("ascii")).hexdigest()
        while True:
            user_id = f"{secrets.randbelow(90000000) + 10000000:08d}"
            if self.name_of(user_id) is None:
                break
        self.db.execute("INSERT INTO accounts VALUES (?,?,?)", (user_id, digest, name))
        self.db.commit()
        return user_id, token, name

    def redeem_limited_promo(self, account_id: str, code: str, max_profiles: int = 5) -> str:
        """Global limit for DISTINCT authenticated accounts; one claim per account.

        A single SQLite write transaction prevents two simultaneous clients from
        both claiming the last slot. Requires a persistent database on hosting.
        """
        if max_profiles < 1 or not self.name_of(account_id):
            return "invalid"
        self.db.execute("BEGIN IMMEDIATE")
        try:
            if self.db.execute(
                "SELECT 1 FROM limited_promo_claims WHERE code=? AND account_id=?",
                (code, account_id),
            ).fetchone():
                result = "already"
            elif self.db.execute(
                "SELECT COUNT(*) FROM limited_promo_claims WHERE code=?", (code,),
            ).fetchone()[0] >= max_profiles:
                result = "exhausted"
            else:
                self.db.execute(
                    "INSERT INTO limited_promo_claims (code,account_id) VALUES (?,?)",
                    (code, account_id),
                )
                result = "success"
            self.db.commit()
            return result
        except Exception:
            self.db.rollback()
            raise

    def name_of(self, user_id: str) -> str | None:
        result = self.db.execute("SELECT name FROM accounts WHERE id=?", (user_id,)).fetchone()
        return result[0] if result else None

    def blocked(self, a: str, b: str) -> bool:
        return self.db.execute("SELECT 1 FROM blocks WHERE (blocker=? AND blocked=?) OR (blocker=? AND blocked=?)", (a,b,b,a)).fetchone() is not None

    def is_friend(self, a: str, b: str) -> bool:
        x, y = sorted((a, b))
        return self.db.execute("SELECT 1 FROM friendships WHERE a=? AND b=?", (x,y)).fetchone() is not None

    def request(self, sender: str, receiver: str) -> None:
        if sender == receiver:
            raise ValueError("Нельзя добавить самого себя.")
        if not self.name_of(receiver):
            raise ValueError("Игрок с таким ID не найден.")
        if self.blocked(sender,receiver):
            raise ValueError("Заявка недоступна.")
        if self.is_friend(sender, receiver):
            raise ValueError("Этот игрок уже в друзьях.")
        if self.db.execute("SELECT 1 FROM requests WHERE sender=? AND receiver=?", (sender,receiver)).fetchone():
            raise ValueError("Заявка уже отправлена.")
        if self.db.execute("SELECT 1 FROM requests WHERE sender=? AND receiver=?", (receiver,sender)).fetchone():
            raise ValueError("Этот игрок уже отправил тебе заявку. Прими её.")
        self.db.execute("INSERT INTO requests VALUES (?,?)", (sender, receiver))
        self.db.commit()

    def respond(self, receiver: str, sender: str, accept: bool) -> None:
        if not self.db.execute("SELECT 1 FROM requests WHERE sender=? AND receiver=?", (sender,receiver)).fetchone():
            raise ValueError("Заявка не найдена.")
        self.db.execute("DELETE FROM requests WHERE sender=? AND receiver=?", (sender,receiver))
        if accept and not self.blocked(sender,receiver):
            a,b = sorted((sender, receiver))
            self.db.execute("INSERT OR IGNORE INTO friendships VALUES (?,?)", (a,b))
        self.db.commit()

    def remove(self, owner: str, target: str) -> None:
        a,b=sorted((owner,target))
        self.db.execute("DELETE FROM friendships WHERE a=? AND b=?", (a,b))
        self.db.commit()

    def block(self, owner: str, target: str) -> None:
        if owner == target or not self.name_of(target):
            raise ValueError("Игрок не найден.")
        self.db.execute("INSERT OR IGNORE INTO blocks VALUES (?,?)", (owner,target))
        a,b=sorted((owner,target))
        self.db.execute("DELETE FROM friendships WHERE a=? AND b=?", (a,b))
        self.db.execute("DELETE FROM requests WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?)", (owner,target,target,owner))
        self.db.commit()

    def snapshot(self, owner: str, online: set[str]) -> dict:
        friends = self.db.execute("""SELECT CASE WHEN a=? THEN b ELSE a END FROM friendships WHERE a=? OR b=?""", (owner,owner,owner)).fetchall()
        received = self.db.execute("SELECT sender FROM requests WHERE receiver=?", (owner,)).fetchall()
        sent = self.db.execute("SELECT receiver FROM requests WHERE sender=?", (owner,)).fetchall()
        def profile(uid: str) -> dict:
            return {"id": uid, "name": self.name_of(uid) or "Игрок", "online": uid in online}
        return {"type":"social", "friends":sorted([profile(x[0]) for x in friends],key=lambda x:x["name"]),
                "requests":[profile(x[0]) for x in received],"sent":[profile(x[0]) for x in sent]}

    def close(self) -> None:
        self.db.close()
