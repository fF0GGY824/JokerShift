"""Checks DEVONE has one global claimant, independently of DEV9999's five."""
import asyncio
import json
import tempfile
from pathlib import Path

from websockets.asyncio.server import serve
from websockets.asyncio.client import connect

from server import Hub, DEV_PROMO_PROFILE_LIMIT, DEV_SINGLE_PROMO_LIMIT


async def main():
    assert DEV_PROMO_PROFILE_LIMIT == 5
    assert DEV_SINGLE_PROMO_LIMIT == 1
    with tempfile.TemporaryDirectory() as temp:
        dbpath = str(Path(temp) / "game.db")
        hub = Hub(dbpath)
        async with serve(hub.connection, "127.0.0.1", 0) as service:
            port = service.sockets[0].getsockname()[1]
            async def redeem(name, code, token=""):
                async with connect(f"ws://127.0.0.1:{port}") as ws:
                    await ws.send(json.dumps({"type":"promo_redeem","name":name,"code":code,"token":token}))
                    return json.loads(await asyncio.wait_for(ws.recv(), timeout=3))

            a, b = await asyncio.gather(redeem("One", "DEVONE"), redeem("Two", "DEVONE"))
            assert sorted([a["status"],b["status"]]) == ["exhausted", "success"], (a,b)
            winner = a if a["status"]=="success" else b
            loser = b if winner is a else a
            assert winner["sapphires"] == winner["bells"] == 9999
            assert loser["sapphires"] == loser["bells"] == 0
            assert loser["message"] == "Лимит промокода исчерпан"
            again = await redeem("Owner", "DEVONE", winner["token"])
            assert again["status"]=="already" and again["code"]=="DEVONE"
            other = await redeem("Third", "DEVONE")
            assert other["status"] == "exhausted"
            # DEV9999's separate quota stays available.
            bonus = await redeem("Other", "DEV9999", loser["token"])
            assert bonus["status"] == "success" and bonus["code"] == "DEV9999"
            one_count = hub.social.db.execute("SELECT COUNT(*) FROM limited_promo_claims WHERE code='DEVONE'").fetchone()[0]
            five_count = hub.social.db.execute("SELECT COUNT(*) FROM limited_promo_claims WHERE code='DEV9999'").fetchone()[0]
            assert (one_count, five_count) == (1,1)
        hub.social.close()
        resumed = Hub(dbpath)
        try:
            assert resumed.social.redeem_limited_promo(winner["id"], "DEVONE", 1) == "already"
            uid, _, _ = resumed.social.authenticate("", "New")
            assert resumed.social.redeem_limited_promo(uid, "DEVONE", 1) == "exhausted"
            assert resumed.social.redeem_limited_promo(uid, "DEV9999", 5) == "success"
        finally:
            resumed.social.close()
    print("PASS: DEVONE 1 global account + DEV9999 5 separate slots, concurrency, persistence")

if __name__ == "__main__":
    asyncio.run(main())
