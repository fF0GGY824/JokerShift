"""Run with `python test_limited_promo.py`: verifies global 5-account DEV9999 limit."""
import asyncio
import json
import tempfile
from pathlib import Path

from websockets.asyncio.server import serve
from websockets.asyncio.client import connect

from server import Hub, DEV_PROMO_PROFILE_LIMIT


async def check_live() -> None:
    assert DEV_PROMO_PROFILE_LIMIT == 5, DEV_PROMO_PROFILE_LIMIT
    with tempfile.TemporaryDirectory() as temporary:
        database_path = str(Path(temporary) / "accounts.db")
        hub = Hub(database_path)
        async with serve(hub.connection, "127.0.0.1", 0) as service:
            port = service.sockets[0].getsockname()[1]

            async def redeem(name: str, token: str = "", code: str = "DEV9999") -> dict:
                async with connect(f"ws://127.0.0.1:{port}") as ws:
                    await ws.send(json.dumps({"type": "promo_redeem", "name": name, "token": token, "code": code}))
                    return json.loads(await asyncio.wait_for(ws.recv(), timeout=3))

            first = await redeem("Tester_1")
            assert first["status"] == "success", first
            assert first["sapphires"] == first["bells"] == 9999
            assert first["message"] == "Промокод активирован"
            assert len(first["token"]) == 64

            repeat = await redeem("Tester_1", first["token"])
            assert repeat["status"] == "already", repeat
            assert repeat["id"] == first["id"]
            assert repeat["sapphires"] == repeat["bells"] == 9999

            invalid = await redeem("Tester_X", code="WRONG")
            assert invalid["status"] == "invalid", invalid
            # Profiles 2 through 4 are allowed.
            for i in range(2, 5):
                result = await redeem(f"Tester_{i}")
                assert result["status"] == "success", result
                assert result["sapphires"] == result["bells"] == 9999

            # Two concurrent contenders for slot 5: only one may win.
            fifth, sixth = await asyncio.gather(redeem("Tester_5"), redeem("Tester_6"))
            assert sorted([fifth["status"], sixth["status"]]) == ["exhausted", "success"], (fifth, sixth)
            exhausted = fifth if fifth["status"] == "exhausted" else sixth
            assert exhausted["sapphires"] == exhausted["bells"] == 0
            assert exhausted["message"] == "Лимит промокода исчерпан"

            seventh = await redeem("Tester_7")
            assert seventh["status"] == "exhausted", seventh

            rows = hub.social.db.execute("SELECT code, account_id FROM limited_promo_claims ORDER BY account_id").fetchall()
            assert len(rows) == 5, rows
            assert len({row[1] for row in rows}) == 5
            assert all(code == "DEV9999" for code, _ in rows)
        hub.social.close()

        # Restart server on the SAME DB: the limit and the original claims persist.
        hub2 = Hub(database_path)
        try:
            count = hub2.social.db.execute("SELECT COUNT(*) FROM limited_promo_claims").fetchone()[0]
            assert count == 5, count
            newcomer_id, _tok, _ = hub2.social.authenticate("", "Newcomer")
            assert hub2.social.redeem_limited_promo(newcomer_id, "DEV9999") == "exhausted"
            original_id, old_token, _ = hub2.social.authenticate(first["token"], "Tester_1")
            assert original_id == first["id"] and old_token == first["token"]
            assert hub2.social.redeem_limited_promo(original_id, "DEV9999") == "already"
        finally:
            hub2.social.close()

    print("PASS: 5 global profiles, one per profile, concurrency, invalid code, persistence")


if __name__ == "__main__":
    asyncio.run(check_live())
