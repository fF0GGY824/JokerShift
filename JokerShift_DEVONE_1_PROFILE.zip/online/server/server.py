"""JokerShift WebSocket lobby and game server. Python 3.11+, websockets 13-16."""
from __future__ import annotations

import asyncio
import json
import logging
from http import HTTPStatus
import os
import secrets
import time
from dataclasses import dataclass, field
from collections import defaultdict, deque
from typing import Any

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed
from game import Game, RuleError
from social import SocialStore

LOG = logging.getLogger("jokershift")
ROOM_TTL = 60 * 30
MAX_ROOMS = int(os.environ.get("MAX_ROOMS", "500"))
MAX_CONNECTIONS = int(os.environ.get("MAX_CONNECTIONS", "1200"))
MAX_ACTIONS_PER_10S = 30
MAX_CHAT_LENGTH = 240
INVITE_TTL = 300
# Debug-only developer rewards: DEV9999 for 5 distinct profiles,
# DEVONE for the first 1 profile. NEVER grant from the client.
DEV_PROMO_CODE = os.environ.get("DEV_PROMO_CODE", "DEV9999").strip().upper()
DEV_PROMO_PROFILE_LIMIT = max(1, int(os.environ.get("DEV_PROMO_PROFILE_LIMIT", "5")))
DEV_SINGLE_PROMO_CODE = "DEVONE"
DEV_SINGLE_PROMO_LIMIT = 1


@dataclass
class Room:
    code: str
    clients: list[Any] = field(default_factory=list)
    names: list[str] = field(default_factory=list)
    ready: set[int] = field(default_factory=set)
    game: Game | None = None
    touched: float = field(default_factory=time.monotonic)


class Hub:
    def __init__(self, db_path: str | None = None) -> None:
        self.social = SocialStore(db_path or os.environ.get("SOCIAL_DB", "jokershift_social.db"))
        self.sessions: dict[Any, str] = {}
        self.online: dict[str, Any] = {}
        self.invitations: dict[tuple[str, str], tuple[str, float]] = {}
        self.rooms: dict[str, Room] = {}
        self.users: dict[Any, tuple[str, int]] = {}
        self.attempts: dict[Any, deque[float]] = defaultdict(deque)
        self.connected: set[Any] = set()

    async def send(self, ws: Any, message: dict) -> None:
        try:
            await ws.send(json.dumps(message, ensure_ascii=False, separators=(",", ":")))
        except ConnectionClosed:
            pass

    async def error(self, ws: Any, message: str) -> None:
        await self.send(ws, {"type": "error", "message": message})

    def check_rate(self, ws: Any) -> bool:
        now = time.monotonic()
        queue = self.attempts[ws]
        while queue and queue[0] < now - 10:
            queue.popleft()
        if len(queue) >= MAX_ACTIONS_PER_10S:
            return False
        queue.append(now)
        return True

    def prune_rooms(self) -> None:
        now = time.monotonic()
        for code, room in list(self.rooms.items()):
            if room.game is None and now - room.touched > ROOM_TTL:
                self.rooms.pop(code, None)
                for ws in room.clients:
                    self.users.pop(ws, None)

    async def announce_room(self, room: Room) -> None:
        for seat, ws in enumerate(room.clients):
            await self.send(ws, {
                "type": "room", "code": room.code, "seat": seat,
                "players": room.names, "ready": sorted(room.ready),
                "stage": "game" if room.game else "waiting",
            })

    async def broadcast_state(self, room: Room) -> None:
        if room.game:
            for seat, ws in enumerate(room.clients):
                state = room.game.state_for(seat)
                state["code"] = room.code
                await self.send(ws, state)

    async def social_snapshot(self, *people: str) -> None:
        online = set(self.online)
        for uid in set(people):
            sock = self.online.get(uid)
            if sock is not None:
                await self.send(sock, self.social.snapshot(uid, online))

    async def all_social_snapshots(self) -> None:
        await self.social_snapshot(*self.online.keys())

    def message_text(self, raw: Any) -> str:
        if not isinstance(raw, str):
            raise ValueError("Сообщение должно быть текстом.")
        value = "".join(ch for ch in raw.strip() if ch.isprintable() or ch == "\n")
        if not value or len(value) > MAX_CHAT_LENGTH:
            raise ValueError("Сообщение: от 1 до 240 символов.")
        return value

    async def social_command(self, ws: Any, packet: dict, kind: str) -> bool:
        if kind == "hello":
            if ws in self.sessions:
                await self.error(ws, "Профиль уже подключён.")
                return True
            name = self.clean_name(packet.get("name"))
            try:
                uid, token, saved_name = self.social.authenticate(packet.get("token", ""), name)
            except ValueError as exc:
                await self.error(ws, str(exc))
                return True
            if uid in self.online:
                await self.error(ws, "Этот профиль уже используется на другом устройстве.")
                return True
            self.sessions[ws] = uid
            self.online[uid] = ws
            await self.send(ws,{"type":"hello", "id":uid, "token":token, "name":saved_name})
            await self.all_social_snapshots()
            return True
        if kind not in ("friend_request", "friend_accept", "friend_decline", "friend_remove", "friend_block", "invite", "invite_accept", "dm", "room_chat", "social_list"):
            return False
        uid = self.sessions.get(ws)
        if not uid:
            await self.error(ws, "Сначала подключи профиль к серверу.")
            return True
        target = packet.get("id", "")
        if kind in ("friend_request", "friend_accept", "friend_decline", "friend_remove", "friend_block", "invite", "dm"):
            if not isinstance(target, str) or len(target) != 8 or not target.isascii() or not target.isdigit():
                await self.error(ws, "ID игрока состоит из 8 цифр.")
                return True
        try:
            if kind == "social_list":
                await self.social_snapshot(uid)
            elif kind == "friend_request":
                self.social.request(uid, target)
                await self.social_snapshot(uid,target)
                await self.send(ws, {"type":"notice", "message":"Заявка отправлена."})
            elif kind in ("friend_accept", "friend_decline"):
                self.social.respond(uid, target, kind == "friend_accept")
                await self.social_snapshot(uid,target)
            elif kind == "friend_remove":
                self.social.remove(uid,target)
                await self.social_snapshot(uid,target)
            elif kind == "friend_block":
                self.social.block(uid,target)
                await self.social_snapshot(uid,target)
            elif kind == "invite":
                if not self.social.is_friend(uid,target) or self.social.blocked(uid,target):
                    raise ValueError("Приглашать можно только друзей.")
                if ws not in self.users:
                    raise ValueError("Сначала создай комнату.")
                code, seat = self.users[ws]
                room=self.rooms.get(code)
                if not room or seat != 0 or len(room.clients) != 1 or room.game is not None:
                    raise ValueError("Приглашать можно из комнаты, пока ждёшь второго игрока.")
                other=self.online.get(target)
                if other is None:
                    raise ValueError("Друг сейчас не в сети.")
                if other in self.users:
                    raise ValueError("Друг уже играет в комнате.")
                self.invitations[(target,code)] = (uid,time.monotonic()+INVITE_TTL)
                await self.send(other,{"type":"invite", "from_id":uid, "from_name":self.social.name_of(uid),"code":code})
                await self.send(ws,{"type":"notice", "message":"Приглашение отправлено."})
            elif kind == "invite_accept":
                code=packet.get("code", "")
                if not isinstance(code,str) or not code.isascii() or not code.isdigit() or len(code) != 6:
                    raise ValueError("Неверный код приглашения.")
                invitation = self.invitations.get((uid,code))
                if invitation is None or invitation[1] < time.monotonic():
                    raise ValueError("Приглашение уже недействительно.")
                if ws in self.users:
                    raise ValueError("Сначала покинь текущую комнату.")
                self.invitations.pop((uid,code),None)
                await self.handle(ws,{"type":"join", "code":code, "name":self.social.name_of(uid)})
            elif kind == "dm":
                if not self.social.is_friend(uid,target) or self.social.blocked(uid,target):
                    raise ValueError("Личный чат доступен только друзьям.")
                other = self.online.get(target)
                if other is None:
                    raise ValueError("Друг сейчас не в сети.")
                body = self.message_text(packet.get("text"))
                msg={"type":"dm", "from_id":uid, "to_id":target, "from_name":self.social.name_of(uid), "text":body}
                await self.send(other,msg)
                await self.send(ws,msg)
            elif kind == "room_chat":
                if ws not in self.users:
                    raise ValueError("Чат комнаты доступен во время игры и ожидания.")
                code, seat = self.users[ws]
                room = self.rooms.get(code)
                if not room:
                    raise ValueError("Комната закрыта.")
                body=self.message_text(packet.get("text"))
                msg={"type":"room_chat", "from_id":uid, "from_name":self.social.name_of(uid),"text":body}
                for other in room.clients:
                    await self.send(other,msg)
        except ValueError as exc:
            await self.error(ws,str(exc))
        return True

    async def developer_promo_command(self, ws: Any, packet: dict) -> None:
        # A profile is the server-side 8-digit account tied to a secret token,
        # not a nickname or device-local file. Token is returned only to the
        # same socket and must be saved by the client.
        code = str(packet.get("code", "")).strip().upper()
        raw_token = packet.get("token", "")
        if not isinstance(raw_token, str):
            await self.send(ws, {"type": "promo_result", "status": "invalid", "message": "Неверный ключ профиля."})
            return
        promo_limits = {
            DEV_PROMO_CODE: DEV_PROMO_PROFILE_LIMIT,
            DEV_SINGLE_PROMO_CODE: DEV_SINGLE_PROMO_LIMIT,
        }
        if code not in promo_limits or not code:
            await self.send(ws, {"type": "promo_result", "status": "invalid", "message": "Неверный промокод."})
            return
        name = self.clean_name(packet.get("name", "Игрок"))
        try:
            account_id, token, _name = self.social.authenticate(raw_token, name)
        except ValueError as exc:
            await self.send(ws, {"type": "promo_result", "status": "invalid", "message": str(exc)})
            return
        result = self.social.redeem_limited_promo(account_id, code, promo_limits[code])
        messages = {
            "success": "Промокод активирован",
            "already": "Промокод уже активирован",
            "exhausted": "Лимит промокода исчерпан",
            "invalid": "Не удалось проверить профиль.",
        }
        await self.send(ws, {
            "type": "promo_result", "status": result, "code": code,
            "message": messages.get(result, "Ошибка активации."),
            "token": token, "id": account_id,
            # Idempotent receipt: if a client lost the first reply after the
            # server claimed the slot, it can recover its ORIGINAL reward.
            # This does not create a third claim or increment any balance.
            "sapphires": 9999 if result in ("success", "already") else 0,
            "bells": 9999 if result in ("success", "already") else 0,
        })

    async def handle(self, ws: Any, packet: dict) -> None:
        if not self.check_rate(ws):
            await self.error(ws, "Слишком много команд. Подожди немного.")
            return
        kind = packet.get("type")
        if kind == "promo_redeem":
            await self.developer_promo_command(ws, packet)
            return
        if await self.social_command(ws, packet, kind):
            return
        if kind == "ping":
            await self.send(ws, {"type": "pong"})
            return
        if kind == "leave":
            await self.leave(ws)
            return
        if kind == "create":
            if ws in self.users:
                await self.error(ws, "Сначала покинь текущую комнату.")
                return
            self.prune_rooms()
            if len(self.rooms) >= MAX_ROOMS:
                await self.error(ws, "Все комнаты заняты. Попробуй позднее.")
                return
            name = self.clean_name(packet.get("name"))
            while True:
                code = f"{secrets.randbelow(900000) + 100000:06d}"
                if code not in self.rooms:
                    break
            room = Room(code=code, clients=[ws], names=[name])
            self.rooms[code] = room
            self.users[ws] = (code, 0)
            await self.announce_room(room)
            return
        if kind == "join":
            if ws in self.users:
                await self.error(ws, "Сначала покинь текущую комнату.")
                return
            code = packet.get("code")
            if not isinstance(code, str) or len(code) != 6 or not code.isascii() or not code.isdigit():
                await self.error(ws, "Код комнаты состоит из 6 цифр.")
                return
            room = self.rooms.get(code)
            if not room or room.game is not None or len(room.clients) >= 2:
                await self.error(ws, "Комната не найдена или уже занята.")
                return
            name = self.clean_name(packet.get("name"))
            room.clients.append(ws)
            room.names.append(name)
            room.touched = time.monotonic()
            self.users[ws] = (code, 1)
            await self.announce_room(room)
            return
        if ws not in self.users:
            await self.error(ws, "Сначала создай комнату или подключись по коду.")
            return
        code, seat = self.users[ws]
        room = self.rooms.get(code)
        if not room or seat >= len(room.clients) or room.clients[seat] is not ws:
            await self.error(ws, "Комната уже закрыта.")
            return
        room.touched = time.monotonic()
        if kind == "ready":
            if room.game:
                await self.error(ws, "Игра уже началась.")
                return
            if len(room.clients) != 2:
                await self.error(ws, "Ждём второго игрока.")
                return
            room.ready.add(seat)
            if len(room.ready) == 2:
                room.game = Game(room.names)
                await self.announce_room(room)
                await self.broadcast_state(room)
            else:
                await self.announce_room(room)
            return
        if kind == "action":
            if not room.game:
                await self.error(ws, "Сначала оба игрока должны нажать «Готов».")
                return
            if room.game.finished:
                await self.error(ws, "Игра завершена.")
                return
            try:
                room.game.act(seat, packet)
            except RuleError as exc:
                await self.error(ws, str(exc))
                return
            await self.broadcast_state(room)
            return
        await self.error(ws, "Неизвестная команда.")

    @staticmethod
    def clean_name(value: Any) -> str:
        if not isinstance(value, str):
            return "Игрок"
        cleaned = "".join(ch for ch in value.strip() if ch.isprintable())[:18]
        return cleaned if cleaned else "Игрок"

    async def leave(self, ws: Any) -> None:
        self.attempts.pop(ws, None)
        assignment = self.users.pop(ws, None)
        if not assignment:
            return
        code, seat = assignment
        room = self.rooms.pop(code, None)
        if not room:
            return
        for other in room.clients:
            self.users.pop(other, None)
            if other is not ws:
                await self.send(other, {"type": "peer_left", "message": "Соперник отключился. Комната закрыта."})
        LOG.info("Room %s closed, disconnected seat %s", code, seat)

    async def connection(self, ws: Any) -> None:
        if len(self.connected) >= MAX_CONNECTIONS:
            await ws.close(code=1013, reason="Too many clients")
            return
        self.connected.add(ws)
        LOG.info("Client connected")
        try:
            async for raw in ws:
                if not isinstance(raw, str):
                    await self.error(ws, "Нужны текстовые JSON-сообщения.")
                    continue
                try:
                    packet = json.loads(raw)
                except json.JSONDecodeError:
                    await self.error(ws, "Неверный формат JSON.")
                    continue
                if not isinstance(packet, dict):
                    await self.error(ws, "Ожидается JSON-объект.")
                    continue
                await self.handle(ws, packet)
        except ConnectionClosed:
            pass
        finally:
            await self.leave(ws)
            uid = self.sessions.pop(ws, None)
            if uid and self.online.get(uid) is ws:
                self.online.pop(uid,None)
                await self.all_social_snapshots()
            self.connected.discard(ws)


def render_health_check(connection: Any, request: Any) -> Any:
    # Render probes the same port as the WebSocket upgrade.
    if request.path == "/health":
        return connection.respond(HTTPStatus.OK, "JokerShift online server is running\n")
    return None


async def serve_forever(host: str | None = None, port: int | None = None) -> None:
    host = host or os.environ.get("HOST", "127.0.0.1")
    port = port or int(os.environ.get("PORT", "8765"))
    hub = Hub()
    async with serve(hub.connection, host, port, max_size=8192, max_queue=16, ping_interval=20, ping_timeout=20, process_request=render_health_check):
        LOG.info("JokerShift WebSocket server listening at ws://%s:%s", host, port)
        await asyncio.Future()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        asyncio.run(serve_forever())
    except KeyboardInterrupt:
        print("Stopping server")
