extends Node
## One-shot connection to JokerShift server for globally limited developer codes.
## The authoritative limit is maintained by the server, not user://profile.cfg.

signal completed(response: Dictionary)

const CONNECTION_PATH: String = "user://jokershift_online.cfg"
const BUNDLED_URL_PATH: String = "res://online/connection.json"
const TIMEOUT_MS: int = 90000

var socket: WebSocketPeer
var started_at: int = 0
var code: String = ""
var player_name: String = "Игрок"
var _submitted: bool = false
var _awaiting_hello: bool = false


func _url() -> String:
	var cfg: ConfigFile = ConfigFile.new()
	if cfg.load(CONNECTION_PATH) == OK:
		var saved: String = str(cfg.get_value("connection", "url", "")).strip_edges()
		if not saved.is_empty():
			return saved
	if FileAccess.file_exists(BUNDLED_URL_PATH):
		var data: Variant = JSON.parse_string(FileAccess.get_file_as_string(BUNDLED_URL_PATH))
		if data is Dictionary:
			return str(data.get("server_url", "")).strip_edges()
	return ""


func redeem(promo_code: String, nickname: String) -> void:
	code = promo_code.strip_edges().to_upper()
	player_name = nickname
	var address: String = _url()
	if not address.begins_with("wss://") and not address.begins_with("ws://"):
		completed.emit({"status": "not_configured", "message": "Для промокода требуется подключённый онлайн-сервер. Укажи его адрес в разделе «Играть онлайн»."})
		return
	socket = WebSocketPeer.new()
	started_at = Time.get_ticks_msec()
	_submitted = false
	var err: Error = socket.connect_to_url(address)
	if err != OK:
		_finish({"status": "offline", "message": "Не удалось соединиться с сервером."})
		return
	set_process(true)


func _process(_delta: float) -> void:
	if socket == null:
		set_process(false)
		return
	socket.poll()
	if Time.get_ticks_msec() - started_at > TIMEOUT_MS:
		_finish({"status": "offline", "message": "Сервер не ответил. Попробуй позже."})
		return
	var connection_state: int = socket.get_ready_state()
	if connection_state == WebSocketPeer.STATE_OPEN:
		if not _submitted:
			var cfg: ConfigFile = ConfigFile.new()
			cfg.load(CONNECTION_PATH)
			var token: String = str(cfg.get_value("account", "token", ""))
			if token.length() == 64:
				socket.send_text(JSON.stringify({"type": "promo_redeem", "code": code, "token": token, "name": player_name}))
			else:
				# Save the identity token FIRST so an interrupted redemption
				# can be retried by the same account without using another slot.
				socket.send_text(JSON.stringify({"type": "hello", "token": "", "name": player_name}))
				_awaiting_hello = true
			_submitted = true
		while socket.get_available_packet_count() > 0:
			var data: PackedByteArray = socket.get_packet()
			if not socket.was_string_packet():
				continue
			var message: Variant = JSON.parse_string(data.get_string_from_utf8())
			if not message is Dictionary:
				continue
			var response_type: String = str(message.get("type", ""))
			if response_type == "hello" and _awaiting_hello:
				var token: String = str(message.get("token", ""))
				if token.length() != 64:
					_finish({"status": "invalid"})
					return
				var cfg: ConfigFile = ConfigFile.new()
				cfg.load(CONNECTION_PATH)
				cfg.set_value("account", "token", token)
				if cfg.save(CONNECTION_PATH) != OK:
					_finish({"status": "offline"})
					return
				_awaiting_hello = false
				socket.send_text(JSON.stringify({"type": "promo_redeem", "code": code, "token": token, "name": player_name}))
			elif response_type == "error":
				_finish({"status": "offline"})
				return
			elif response_type == "promo_result":
				var saved_token: String = str(message.get("token", ""))
				if saved_token.length() == 64:
					var cfg: ConfigFile = ConfigFile.new()
					cfg.load(CONNECTION_PATH)
					cfg.set_value("account", "token", saved_token)
					if cfg.save(CONNECTION_PATH) != OK:
						_finish({"status": "offline"})
						return
				_finish(message)
				return
	elif connection_state == WebSocketPeer.STATE_CLOSED:
		_finish({"status": "offline", "message": "Соединение с сервером закрыто. Награда не начислена."})


func _finish(message: Dictionary) -> void:
	if socket != null:
		if socket.get_ready_state() == WebSocketPeer.STATE_OPEN:
			socket.close(1000, "Finished")
		socket = null
	set_process(false)
	completed.emit(message)
