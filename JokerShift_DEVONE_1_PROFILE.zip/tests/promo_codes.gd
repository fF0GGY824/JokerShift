extends SceneTree

var failures: int = 0

func check(condition: bool, description: String) -> void:
	if condition:
		print("PASS: ", description)
	else:
		push_error("FAIL: " + description)
		failures += 1

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var profile_path: String = ProjectSettings.globalize_path("user://profile.cfg")
	var had_profile: bool = FileAccess.file_exists(profile_path)
	var backup: PackedByteArray = FileAccess.get_file_as_bytes(profile_path) if had_profile else PackedByteArray()
	if had_profile:
		DirAccess.remove_absolute(profile_path)
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	var game = scene.instantiate()
	root.add_child(game)
	await process_frame
	game.animation_enabled = false
	game.open_shop()
	await process_frame
	var promo_panel: Control = game.shop_screen.find_child("PromoPanel", true, false) as Control
	var input: LineEdit = game.shop_screen.find_child("PromoCodeInput", true, false) as LineEdit
	var button: Button = game.shop_screen.find_child("PromoActivateButton", true, false) as Button
	var feedback: Label = game.shop_screen.find_child("PromoStatus", true, false) as Label
	check(promo_panel != null and input != null and button != null and feedback != null, "promo inputs displayed in store")
	check(game.profile_sapphires == 100 and game.profile_bells == 10, "initial balance preserved")
	check(not game.redeem_promo_code(""), "empty code rejected")
	check(not game.redeem_promo_code("notreal"), "invalid code rejected")
	check(game.profile_sapphires == 100 and game.profile_bells == 10, "invalid codes award nothing")
	input.text = " joker2026 "
	game._activate_promo_from_input()
	check(game.profile_sapphires == 135, "sapphire code rewards 35 sapphires")
	check(input.text.is_empty(), "successful redemption clears input")
	check(feedback.text == "Промокод активирован", "short successful promo message")
	check(game.shop_sapphire_balance.text.contains("135"), "balance updates immediately")
	check(not game.redeem_promo_code("JOKER2026"), "duplicate code rejected")
	check(game.profile_sapphires == 135, "duplicate awards no sapphires")
	check(game.redeem_promo_code("bellgift"), "bell reward code accepted")
	check(game.profile_bells == 12, "bell code rewards only 2 bells")
	check(game.redeem_promo_code("darkjester"), "cosmetic code accepted")
	check(game.shop_owned_items.has("title_jester"), "cosmetic unlocked permanently")
	check(game.profile_bells == 12 and game.shop_equipped_title == "title_default", "free cosmetic does not charge or force equip")
	check(game.shop_purchase_or_equip("title_jester"), "redeemed item can be equipped free")
	check(game.profile_bells == 12, "equipping redeemed item does not charge")
	game.queue_free()
	await process_frame
	var relaunched = scene.instantiate()
	root.add_child(relaunched)
	await process_frame
	check(relaunched.profile_sapphires == 135 and relaunched.profile_bells == 12, "currency rewards saved after restart")
	check(relaunched.shop_owned_items.has("title_jester"), "cosmetic reward saved after restart")
	check(relaunched.redeemed_promo_codes.size() == 3, "used codes saved")
	check(not relaunched.redeem_promo_code("BELLGIFT"), "used code cannot be repeated after restart")
	check(relaunched.profile_bells == 12, "no repeat reward on restart")
	relaunched.queue_free()
	await process_frame
	if had_profile:
		var f: FileAccess = FileAccess.open(profile_path, FileAccess.WRITE)
		if f != null:
			f.store_buffer(backup)
			f.close()
	else:
		DirAccess.remove_absolute(profile_path)
	print("PROMO CODE CHECK: ", "OK" if failures == 0 else "%d FAILURES" % failures)
	quit(0 if failures == 0 else 1)
