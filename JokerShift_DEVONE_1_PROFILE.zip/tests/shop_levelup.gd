extends SceneTree

var errors: int = 0

func check(yes: bool, msg: String) -> void:
	if yes:
		print("PASS: ", msg)
	else:
		errors += 1
		push_error("FAIL: " + msg)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var storage: String = ProjectSettings.globalize_path("user://profile.cfg")
	var had_saved: bool = FileAccess.file_exists(storage)
	var backup: PackedByteArray = PackedByteArray()
	if had_saved:
		backup = FileAccess.get_file_as_bytes(storage)
		DirAccess.remove_absolute(storage)
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	var game = scene.instantiate()
	root.add_child(game)
	await process_frame
	check(game.profile_level == 1 and game.bot_level() == 1, "Player and bot start at level 1")
	check(game.profile_sapphires == 100 and game.profile_bells == 10, "New players have 100 sapphires and 10 bells")
	check(game.profile_sapphire_label != null and game.profile_bell_label != null, "Currency labels shown in main menu")
	check(game.shop_screen != null and game.shop_grid.get_child_count() >= 9, "Shop has functional catalog")
	var shop_btn: Button = game.menu_screen.find_child("Feature_1", true, false) as Button
	check(shop_btn != null and shop_btn.text.contains("Магазин"), "Store entry in old neon main menu")
	game.open_shop()
	await process_frame
	check(game.shop_screen.visible and not game.menu_screen.visible, "Store opens from menu")
	check(game.shop_grid.find_child("ShopBuy_frame_sapphire", true, false) != null, "Store has purchase button")
	check(not game.shop_purchase_or_equip("frame_sapphire"), "Expensive sapphire frame cannot be purchased for starting 100")
	check(game.profile_sapphires == 100, "Failed expensive purchase is free")
	# Fund a purchase test account without changing the initial wallet in the game.
	game.profile_sapphires = 300
	check(game.shop_purchase_or_equip("frame_sapphire"), "First purchase succeeds")
	check(game.profile_sapphires == 180 and game.profile_bells == 10, "Purchase deducted exactly 120 sapphires")
	check(game.shop_purchase_or_equip("frame_sapphire"), "Reequip purchased item succeeds")
	check(game.profile_sapphires == 180, "No double charge")
	check(game.shop_purchase_or_equip("back_sapphire"), "Another category can be purchased")
	check(game.profile_sapphires == 90, "Second item deducted 90 sapphires")
	check(game.shop_purchase_or_equip("title_master"), "A profile title can be purchased")
	check(game.profile_sapphires == 15, "A profile title costs 75 sapphires")
	check(game.shop_purchase_or_equip("frame_gold"), "Premium currency purchase works")
	check(game.profile_bells == 1 and game.shop_equipped_frame == "frame_gold", "9 bells deducted and frame equipped")
	check(not game.shop_purchase_or_equip("title_jester"), "Insufficient bells handled")
	check(game.profile_bells == 1, "Failed purchase did not charge")
	check(game.shop_purchase_or_equip("frame_default"), "Default cosmetics can be re-equipped free")
	game.profile_level = 1
	game.profile_xp = 90
	game.bot_difficulty = 1
	game.save_profile()
	check(game.award_match_xp("bot", "win") == 24, "XP for match unchanged")
	check(game.profile_level == 2 and game.bot_level() == 2, "Bot levels up with player")
	check(game.profile_xp == 14 and game.last_level_gains == 1, "XP carried and level tracked")
	check(game.profile_sapphires == 18 and game.last_level_sapphire_reward == 3, "Level up only gives 3 sapphires")
	check(game.profile_bells == 1, "No bells for leveling")
	check(game.award_match_xp("online", "win", "test-online-5") == 40, "Online rewards XP normally")
	check(game.award_match_xp("online", "win", "test-online-5") == 0, "Online replay does not give extra reward")
	check(game.profile_sapphires == 18, "Online duplicate did not give sapphires")
	game.profile_level = 6
	game.profile_xp = 0
	game.save_profile()
	check(game.bot_level() == 6 and game.bot_ai_difficulty() == 2, "Bot AI gets stronger as levels grow")
	game.load_profile()
	check(game.shop_owned_items.has("frame_gold") and game.shop_owned_items.has("back_sapphire"), "Ownership saved")
	check(game.shop_equipped_frame == "frame_default" and game.shop_equipped_back == "back_sapphire", "Equipped choices saved")
	check(game.profile_sapphires == 18 and game.profile_bells == 1, "Wallet and level bonus persisted")
	game.show_menu()
	await process_frame
	check(game.menu_screen.visible and not game.shop_screen.visible, "Return from store to menu")
	check(game.shop_purchase_or_equip("frame_gold"), "Can equip previously purchased frame again for free")
	check(game.profile_bells == 1, "Changing bought frame never double charges")
	game.queue_free()
	await process_frame
	# Verify persisted purchases AND their appearance are restored in _ready.
	var restarted = scene.instantiate()
	root.add_child(restarted)
	await process_frame
	check(restarted.shop_equipped_frame == "frame_gold", "Equipped frame restored on actual game relaunch")
	var frame_box: PanelContainer = restarted.menu_screen.find_child("MenuAvatarBox", true, false) as PanelContainer
	var frame_style: StyleBoxFlat = frame_box.get_theme_stylebox("panel") as StyleBoxFlat
	check(frame_style.border_color.is_equal_approx(Color("#F8C85B")), "Purchased gold frame displayed on relaunch")
	check(restarted.shop_equipped_back == "back_sapphire" and restarted._shop_back_color().is_equal_approx(Color("#173D79")), "Purchased card back restored on relaunch")
	check(restarted.profile_sapphires == 18 and restarted.profile_bells == 1, "Currency balances restored on relaunch")
	# Multiple level thresholds in one award pay 3 gems each (never duplicate).
	restarted.profile_level = 1
	restarted.profile_xp = 220
	var balance_before: int = restarted.profile_sapphires
	restarted.award_match_xp("bot", "win")
	check(restarted.profile_level == 3 and restarted.last_level_gains == 2, "Two level-ups give two rewards")
	check(restarted.profile_sapphires == balance_before + 6, "Two levels grant only 6 sapphires")
	restarted.queue_free()
	await process_frame
	if had_saved:
		var f: FileAccess = FileAccess.open(storage, FileAccess.WRITE)
		if f != null:
			f.store_buffer(backup)
			f.close()
	else:
		DirAccess.remove_absolute(storage)
	print("SHOP LEVELUP CHECK: ", "OK" if errors == 0 else "%d ERRORS" % errors)
	quit(0 if errors == 0 else 1)
