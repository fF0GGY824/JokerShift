extends SceneTree

var errors: int = 0

func c(rank: int, suit: String) -> Dictionary:
	return {"rank":rank, "suit":suit, "special":"", "joker_color":"", "copy_rank":-1, "copy_suit":""}

func special(kind: String, color: String = "") -> Dictionary:
	return {"rank":22 if kind == "mark" else 20, "suit":"", "special":kind, "joker_color":color, "copy_rank":-1, "copy_suit":""}

func verify(value: bool, msg: String) -> void:
	if value:
		print("PASS: " + msg)
	else:
		errors += 1
		push_error("FAIL: " + msg)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var game = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.trump_mode = "red"
	game.trump_suit = "♥ ♦"
	game.player_hand = [c(10, "♦"), c(8, "♣"), special("mark"), c(4, "♥"), c(6, "♠"), c(2, "♦"), special("joker", "red"), c(5, "♠"), c(3, "♥"), c(3, "♣")]
	game.selected_index = 3 # ♥4 before the sort
	game.sort_player_hand()
	var ordered: Array[String] = []
	for card in game.player_hand:
		ordered.append(game.card_name(card))
	verify(ordered == ["Красный джокер", "МЕТКА", "5♠", "6♠", "3♣", "8♣", "3♥", "4♥", "2♦", "10♦"], "Special left, normal suits grouped and ascending, red trumps right")
	verify(game.card_name(game.player_hand[game.selected_index]) == "4♥", "Selected card survives sorting")
	game.trump_mode = "black"
	game.trump_suit = "♠ ♣"
	game.sort_player_hand()
	verify(game.card_name(game.player_hand[2]) == "3♥" and game.card_name(game.player_hand[-1]) == "8♣", "Black trumps sort last on right")
	game.trump_mode = "suit"
	game.trump_suit = "♦"
	game.sort_player_hand()
	verify(game.card_name(game.player_hand[-1]) == "10♦", "Single-suit trump sorts last")
	game.trump_mode = "none"
	game.sort_player_hand()
	verify(game.card_name(game.player_hand[2]) == "5♠" and game.card_name(game.player_hand[-1]) == "8♣", "No-trump sorts only by suit")

	game.animation_busy = false
	game.finished = false
	game.trump_mode = "suit"
	game.trump_suit = "♥"
	game.attacker = 1
	game.bot_hand = [c(5,"♠"),c(7,"♦")]
	game.table_cards = [{"attack":c(12,"♥"), "defense":{},"slot_id":0}]
	game.player_hand = [c(2,"♠"), c(3,"♦")]
	verify(game.recommended_table_action() == "take", "Take recommended only when no defense or transfer exists")
	game.player_hand.append(c(13,"♥"))
	verify(game.recommended_table_action() == "", "No premature Take when a defending card exists")
	game.attacker = 0
	game.player_hand = [c(3,"♦")]
	game.table_cards = [{"attack":c(5,"♣"),"defense":c(7,"♣"),"slot_id":0}]
	verify(game.recommended_table_action() == "finish", "Bito recommended when no cards can be thrown")
	game.player_hand = [c(5,"♥")]
	verify(game.recommended_table_action() == "", "Bito not highlighted if a legal throw exists")
	game.player_hand = [c(4,"♠")]
	game.table_cards[0]["defense"] = {}
	game.bot_takes = true
	verify(game.recommended_table_action() == "finish", "Bito highlighted when bot takes and cannot throw")

	game.open_online()
	await process_frame
	var ui = game.online_view
	ui.state = {"trump_mode":"red", "trump_suit":"", "your_hand":[
		c(9,"♦").merged({"id":1}), c(3,"♠").merged({"id":2}),
		special("mark").merged({"id":3}), c(2,"♦").merged({"id":4}),
		c(5,"♠").merged({"id":5})]}
	var online_sorted: Array = ui._sorted_online_hand()
	verify([int(online_sorted[0].get("id",0)),int(online_sorted[1].get("id",0)),int(online_sorted[2].get("id",0)),int(online_sorted[3].get("id",0)),int(online_sorted[4].get("id",0))] == [3,2,5,4,1], "Online sorted visually but card IDs unchanged")
	verify(game.status_label.get_theme_font_size("font_size") >= 16, "Status messages are readable")
	game.queue_free()
	await process_frame
	print("HAND SORT & ACTION HINTS:", "PASS" if errors == 0 else "FAIL")
	quit(0 if errors == 0 else 1)
