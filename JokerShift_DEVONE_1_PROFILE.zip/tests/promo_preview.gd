extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	var game = scene.instantiate()
	root.add_child(game)
	game.animation_enabled = false
	game.open_shop()
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw
	var sz: Vector2i = DisplayServer.window_get_size()
	var path: String = "/mnt/data/JokerShift_PROMO_SHOP_%d.png" % sz.x
	var img: Image = root.get_texture().get_image()
	var err: Error = img.save_png(path)
	print("PROMO PREVIEW: ", path, " size ", img.get_width(), "x", img.get_height(), " err ", err)
	quit(0 if err == OK else 1)
