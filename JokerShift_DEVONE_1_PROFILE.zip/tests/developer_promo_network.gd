extends SceneTree

var finished: bool = false
var result: Dictionary = {}

func _initialize() -> void:
	call_deferred("_run")

func _receive(response: Dictionary) -> void:
	result = response
	finished = true

func _run() -> void:
	var cfg_path: String = ProjectSettings.globalize_path("user://jokershift_online.cfg")
	var had_config: bool = FileAccess.file_exists(cfg_path)
	var original: PackedByteArray = FileAccess.get_file_as_bytes(cfg_path) if had_config else PackedByteArray()
	var cfg: ConfigFile = ConfigFile.new()
	cfg.set_value("connection", "url", "ws://127.0.0.1:18775")
	cfg.set_value("account", "token", "")
	cfg.save(cfg_path)
	var script: Script = load("res://online/dev_promo_client.gd") as Script
	var client: Node = Node.new()
	client.set_script(script)
	root.add_child(client)
	client.completed.connect(_receive)
	client.redeem("DEV9999", "AutoTest")
	var started: int = Time.get_ticks_msec()
	while not finished and Time.get_ticks_msec() - started < 10000:
		await process_frame
	var success: bool = finished and str(result.get("status", "")) == "success" and int(result.get("bells", 0)) == 9999
	print("PROMO NETWORK TEST: ", "OK" if success else "FAIL %s" % [result])
	client.queue_free()
	await process_frame
	if had_config:
		var file: FileAccess = FileAccess.open(cfg_path, FileAccess.WRITE)
		if file != null:
			file.store_buffer(original)
			file.close()
	else:
		DirAccess.remove_absolute(cfg_path)
	quit(0 if success else 1)
