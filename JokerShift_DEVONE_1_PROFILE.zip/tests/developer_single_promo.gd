extends SceneTree

var failures: int = 0

func check(condition: bool, name: String) -> void:
	if not condition:
		push_error("FAIL " + name)
		failures += 1

func _initialize() -> void:
	call_deferred("run_tests")

func run_tests() -> void:
	var profile_path: String = ProjectSettings.globalize_path("user://profile.cfg")
	var original: PackedByteArray = FileAccess.get_file_as_bytes(profile_path) if FileAccess.file_exists(profile_path) else PackedByteArray()
	var had_original: bool = FileAccess.file_exists(profile_path)
	if had_original:
		DirAccess.remove_absolute(profile_path)
	var game_scene: PackedScene = load("res://control.tscn") as PackedScene
	var game = game_scene.instantiate()
	root.add_child(game)
	await process_frame
	check(game.PROMO_CODES.has("DEVONE"), "DEVONE listed")
	game._on_developer_promo_result({"status": "success", "code": "DEVONE", "sapphires": 9999, "bells": 9999})
	check(game.promo_status_label.text == "Промокод активирован", "short success")
	check(game.profile_sapphires == 9999 and game.profile_bells == 9999, "wallet updated")
	check(game.redeemed_promo_codes.has("DEVONE"), "saved code claimed")
	check(not game.redeemed_promo_codes.has("DEV9999"), "original code remains free")
	check(game.profile_sapphire_label.text.begins_with("9999") and game.profile_bell_label.text.begins_with("9999"), "profile reflects wallet")
	game._on_developer_promo_result({"status": "already", "code": "DEVONE", "sapphires": 9999, "bells": 9999})
	check(game.promo_status_label.text == "Промокод уже активирован", "already says short text")
	game.queue_free()
	await process_frame
	var again = game_scene.instantiate()
	root.add_child(again)
	await process_frame
	check(again.redeemed_promo_codes.has("DEVONE"), "code persisted after restart")
	check(again.profile_sapphires == 9999 and again.profile_bells == 9999, "wallet persisted after restart")
	check(not again.redeem_promo_code("DEVONE"), "repeat blocked")
	again.queue_free()
	await process_frame
	if had_original:
		var output: FileAccess = FileAccess.open(profile_path, FileAccess.WRITE)
		if output != null:
			output.store_buffer(original)
			output.close()
	else:
		DirAccess.remove_absolute(profile_path)
	print("DEVONE UI CHECK: ", "OK" if failures == 0 else "FAIL %d" % failures)
	quit(0 if failures == 0 else 1)
