extends SceneTree

var errors: int = 0

func check(test: bool, message: String) -> void:
	if test:
		print("PASS:", message)
	else:
		push_error("FAIL: " + message)
		errors += 1

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var profile_path: String = ProjectSettings.globalize_path("user://profile.cfg")
	var backup: PackedByteArray = PackedByteArray()
	var has_old: bool = FileAccess.file_exists(profile_path)
	if has_old:
		backup = FileAccess.get_file_as_bytes(profile_path)
		DirAccess.remove_absolute(profile_path)
	var game = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	check(game.profile_sapphires == 100 and game.profile_bells == 10, "start wallet: 100 sapphires and 10 bells")
	var menu: Control = game.menu_screen
	var sapphire_icon: TextureRect = menu.find_child("SapphireIcon", true, false) as TextureRect
	var bell_icon: TextureRect = menu.find_child("BellIcon", true, false) as TextureRect
	check(sapphire_icon != null and sapphire_icon.texture != null, "real sapphire icon visible in profile")
	check(bell_icon != null and bell_icon.texture != null, "real bell icon visible in profile")
	check(game.profile_sapphire_label.text.contains("САПФИРОВ"), "sapphires clearly labeled")
	check(game.profile_bell_label.text.contains("КОЛОКОЛЬЧИКОВ"), "bells clearly labeled")
	game.open_shop()
	await process_frame
	check(game.shop_grid.get_child_count() == 9, "nine default cosmetics in two-column grid")
	check(game.shop_premium_grid.get_child_count() == 3, "three premium exclusives in separate two-column grid")
	check(game.shop_bell_balance.text == "10 КОЛОКОЛЬЧИКОВ", "bell shop balance correctly labeled")
	check(game.shop_sapphire_balance.text == "100 САПФИРОВ", "sapphire shop balance correctly labeled")
	var pack_row = game.shop_screen.find_child("BellPackGrid", true, false)
	check(pack_row != null and pack_row.get_child_count() == 3, "three visible donation packs")
	game._request_bell_pack(25)
	check(game.profile_bells == 10, "payment preview cannot grant bells")
	check(game.shop_message_label.text.contains("оплата пока не подключена"), "payment status honest")
	check(not game.shop_purchase_or_equip("frame_royal"), "premium expensive frame blocked without bells")
	check(game.profile_bells == 10, "failed premium purchase doesn't charge")
	var owned_before = game.shop_owned_items.size()
	game.profile_bells = 100
	game.save_profile()
	check(game.shop_purchase_or_equip("frame_royal"), "premium aura can be equipped when account has bells")
	check(game.profile_bells == 78, "premium frame costs 22 bells")
	check(game.shop_purchase_or_equip("back_crown"), "premium crowned back can be bought")
	check(game.profile_bells == 50, "premium back costs 28 bells")
	check(game.shop_purchase_or_equip("title_legend"), "premium legend title can be bought")
	check(game.profile_bells == 32, "premium title costs 18 bells")
	check(game.shop_owned_items.size() == owned_before + 3, "premium ownership recorded")
	check(game.shop_purchase_or_equip("frame_royal") and game.profile_bells == 32, "equipping owned premium cosmetic never double charges")
	game.queue_free()
	await process_frame
	var restarted = load("res://control.tscn").instantiate()
	root.add_child(restarted)
	await process_frame
	check(restarted.shop_owned_items.has("title_legend"), "premium ownership survived restart")
	check(restarted.shop_equipped_frame == "frame_royal", "premium frame survived restart")
	check(restarted.shop_equipped_title == "title_legend", "premium title survived restart")
	check(restarted.profile_bells == 32, "premium currency saved")
	restarted.queue_free()
	await process_frame
	if has_old:
		var f: FileAccess = FileAccess.open(profile_path, FileAccess.WRITE)
		if f != null:
			f.store_buffer(backup)
			f.close()
	else:
		DirAccess.remove_absolute(profile_path)
	print("PREMIUM SHOP CHECK: ", "OK" if errors == 0 else "%d ERRORS" % errors)
	quit(0 if errors == 0 else 1)
