extends SceneTree

var failures: int = 0

func check(ok: bool, label: String) -> void:
	if ok:
		print("PASS: ", label)
	else:
		push_error("FAIL: " + label)
		failures += 1

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var save_path: String = ProjectSettings.globalize_path("user://profile.cfg")
	var had_save: bool = FileAccess.file_exists(save_path)
	var saved_data: PackedByteArray = FileAccess.get_file_as_bytes(save_path) if had_save else PackedByteArray()
	if had_save:
		DirAccess.remove_absolute(save_path)

	var scene: PackedScene = load("res://control.tscn") as PackedScene
	var game = scene.instantiate()
	root.add_child(game)
	await process_frame
	check(game.profile_sapphires == 100 and game.profile_bells == 10, "new profile starts with 100/10")
	if OS.is_debug_build():
		game._on_developer_promo_result({"status": "exhausted", "message": "Older server message long"})
		check(game.promo_status_label.text == "Лимит промокода исчерпан", "third profile sees short exhausted message")
		check(game.profile_sapphires == 100 and game.profile_bells == 10, "third profile receives no reward")
		check(not game.redeemed_promo_codes.has("DEV9999"), "exhausted does not mark activation")
		game._on_developer_promo_result({"status": "success", "sapphires": 9999, "bells": 9999})
		check(game.promo_status_label.text == "Промокод активирован", "only short success message")
		check(game.profile_sapphires == 9999 and game.profile_bells == 9999, "confirmed reward reaches actual profile wallet")
		check(game.profile_sapphire_label.text.begins_with("9999") and game.profile_bell_label.text.begins_with("9999"), "profile wallet labels refreshed")
		check(game.shop_sapphire_balance.text.begins_with("9999") and game.shop_bell_balance.text.begins_with("9999"), "store wallet labels refreshed")
		check(game.redeemed_promo_codes.has("DEV9999") and game.developer_reward_applied, "one-use claim and delivered marker saved")
		game._on_developer_promo_result({"status": "already", "sapphires": 9999, "bells": 9999})
		check(game.promo_status_label.text == "Промокод уже активирован", "same profile cannot use code twice")
		check(game.redeemed_promo_codes.count("DEV9999") == 1, "duplicate does not claim again")
		game.queue_free()
		await process_frame
		var again = scene.instantiate()
		root.add_child(again)
		await process_frame
		check(again.profile_sapphires == 9999 and again.profile_bells == 9999, "balances persist after restart")
		check(not again.redeem_promo_code("DEV9999"), "local same profile cannot activate again")
		again.queue_free()
		await process_frame

		# Older client used the code but did not update wallet. Repair exactly once.
		var saved: ConfigFile = ConfigFile.new()
		saved.load(save_path)
		saved.set_value("promo", "redeemed", PackedStringArray(["DEV9999"]))
		saved.set_value("promo", "developer_reward_applied", false)
		saved.set_value("wallet", "sapphires", 100)
		saved.set_value("wallet", "bells", 10)
		saved.save(save_path)
		var legacy = scene.instantiate()
		root.add_child(legacy)
		await process_frame
		check(legacy.profile_sapphires == 9999 and legacy.profile_bells == 9999, "legacy confirmed claim recovers previously missing wallet")
		check(legacy.developer_reward_applied, "migration marker set")
		legacy.profile_sapphires -= 200
		legacy.profile_bells -= 3
		legacy.save_profile()
		legacy.queue_free()
		await process_frame
		var after_spend = scene.instantiate()
		root.add_child(after_spend)
		await process_frame
		check(after_spend.profile_sapphires == 9799 and after_spend.profile_bells == 9996, "old claim does not refill wallet after spending")
		after_spend.queue_free()
		await process_frame

		# An interrupted reply can be recovered from the server's existing claim.
		DirAccess.remove_absolute(save_path)
		var recovery = scene.instantiate()
		root.add_child(recovery)
		await process_frame
		recovery._on_developer_promo_result({"status": "already", "sapphires": 9999, "bells": 9999})
		check(recovery.profile_sapphires == 9999 and recovery.profile_bells == 9999, "lost server reply can be recovered without a new slot")
		check(recovery.promo_status_label.text == "Промокод активирован", "recovered reward has short confirmation")
		recovery.queue_free()
		await process_frame
	else:
		check(not game.redeem_promo_code("DEV9999"), "release cannot redeem developer code")
		check(game.profile_sapphires == 100 and game.profile_bells == 10, "release unchanged")
		game.queue_free()
		await process_frame

	if had_save:
		var f: FileAccess = FileAccess.open(save_path, FileAccess.WRITE)
		if f != null:
			f.store_buffer(saved_data)
			f.close()
	else:
		DirAccess.remove_absolute(save_path)
	print("DEVELOPER PROMO UI: ", "OK" if failures == 0 else "FAILED %d" % failures)
	quit(0 if failures == 0 else 1)
