extends SceneTree

var failures: int = 0

func card(rank: int, suit: String) -> Dictionary:
	return {"rank": rank, "suit": suit, "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""}

func verify(value: bool, explanation: String) -> void:
	if value:
		print("PASS: " + explanation)
	else:
		failures += 1
		push_error("FAIL: " + explanation)

func _initialize() -> void:
	call_deferred("run_tests")

func run_tests() -> void:
	var game = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.trump_mode = "red"
	game.trump_suit = "♥ ♦"
	verify(game.can_beat(card(3, "♦"), card(3, "♥")), "3 diamonds beats 3 hearts when red double trump")
	verify(game.can_beat(card(3, "♥"), card(3, "♦")), "3 hearts beats 3 diamonds when red double trump")
	verify(not game.can_beat(card(3, "♥"), card(3, "♥")), "Same suit equal rank never beats itself")
	verify(not game.can_beat(card(2, "♦"), card(3, "♥")), "Lower rank other red suit cannot defend")
	verify(not game.can_beat(card(3, "♠"), card(3, "♥")), "Nontrump cannot defend equal red trump")
	verify(game.can_beat(card(4, "♥"), card(3, "♦")), "Higher rank red trump always defends")
	game.trump_mode = "black"
	game.trump_suit = "♠ ♣"
	verify(game.can_beat(card(3, "♣"), card(3, "♠")), "3 clubs beats 3 spades when black double trump")
	verify(game.can_beat(card(3, "♠"), card(3, "♣")), "3 spades beats 3 clubs when black double trump")
	verify(not game.can_beat(card(3, "♦"), card(3, "♣")), "Red nontrump cannot defend black trump")
	game.trump_mode = "suit"
	game.trump_suit = "♥"
	verify(not game.can_beat(card(3, "♦"), card(3, "♥")), "Classic single-suit trump remains unchanged")
	verify(game.can_beat(card(3, "♥"), card(3, "♦")), "Classic trump beats any equal-rank nontrump")
	verify(game.can_beat(card(4, "♥"), card(3, "♥")), "Higher single-suit trump beats lower trump")
	game.queue_free()
	await process_frame
	print("DOUBLE TRUMP CLIENT:", "PASS" if failures == 0 else "FAIL")
	quit(0 if failures == 0 else 1)
