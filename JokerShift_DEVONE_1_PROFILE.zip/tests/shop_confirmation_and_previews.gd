extends SceneTree

var failures: int = 0
func check(condition: bool, description: String) -> void:
	if condition:
		print("PASS: ", description)
	else:
		push_error("FAIL: " + description)
		failures += 1

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var cfg: String = ProjectSettings.globalize_path("user://profile.cfg")
	var existed: bool = FileAccess.file_exists(cfg)
	var saved: PackedByteArray = FileAccess.get_file_as_bytes(cfg) if existed else PackedByteArray()
	if existed:
		DirAccess.remove_absolute(cfg)
	var game = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.animation_enabled = false
	game.open_shop()
	await process_frame
	var ids: Array[String] = ["frame_royal", "back_crown", "title_legend", "frame_sapphire"]
	for id in ids:
		var tile: Control = game.shop_screen.find_child("ShopItem_" + id, true, false)
		var art: TextureRect = tile.find_child("ShopArt_" + id, true, false)
		check(art != null and art.texture != null, "product has separate illustration: " + id)
		check(tile.find_child("ShopNameLabel", true, false) != null, "product has title: " + id)
		check(tile.find_child("TileHint", true, false) == null, "no description on product tile: " + id)
	var images: Array[String] = []
	for id in ids:
		var tile: Control = game.shop_screen.find_child("ShopItem_" + id, true, false)
		images.append(str((tile.find_child("ShopArt_" + id, true, false) as TextureRect).texture.resource_path))
	check(images[0] != images[1] and images[1] != images[2], "exclusive art textures are distinct")
	var before: int = game.profile_bells
	game._shop_tile_action("frame_royal")
	await process_frame
	check(game.shop_purchase_overlay.visible, "confirm overlay opens when BUY pressed")
	check(game.profile_bells == before, "not charged before confirmation")
	check(game.shop_purchase_title.text == "Королевская аура", "dialog contains product name")
	check(game.shop_purchase_description.text.contains("Эксклюзивная розовая рамка"), "description moved to dialog")
	check(game.shop_purchase_badge.text.contains("22"), "dialog shows price")
	check(game.shop_purchase_confirm_button.disabled, "confirm disabled on insufficient funds")
	game._cancel_shop_purchase()
	await process_frame
	check(game.profile_bells == before and not game.shop_purchase_overlay.visible, "cancel keeps the balance")
	game.profile_bells = 60
	game._shop_tile_action("frame_royal")
	await process_frame
	check(not game.shop_purchase_confirm_button.disabled, "confirm enabled with enough bells")
	check(game.profile_bells == 60, "funded preview still does not charge")
	game._confirm_shop_purchase()
	await process_frame
	check(game.profile_bells == 38, "confirm spends exactly 22 bells")
	check(game.shop_owned_items.has("frame_royal"), "confirmed item owned")
	check(not game.shop_purchase_overlay.visible, "modal dismissed after purchase")
	game._shop_tile_action("frame_royal")
	check(game.profile_bells == 38, "equipping owned item never charges twice")
	game.queue_free()
	await process_frame
	if existed:
		var out: FileAccess = FileAccess.open(cfg, FileAccess.WRITE)
		if out != null:
			out.store_buffer(saved)
			out.close()
	else:
		DirAccess.remove_absolute(cfg)
	print("SHOP CONFIRMATION CHECK: ", "OK" if failures == 0 else str(failures) + " FAILURES")
	quit(0 if failures == 0 else 1)
