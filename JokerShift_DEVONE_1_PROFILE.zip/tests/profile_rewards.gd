extends SceneTree

var errors: int = 0

func check(condition: bool, message: String) -> void:
	if condition:
		print("PASS: " + message)
	else:
		errors += 1
		push_error("FAIL: " + message)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	check(scene != null, "Godot project loaded")
	if scene == null:
		quit(1)
		return

	# Save/restore any profile from earlier local test runs.
	var storage: String = ProjectSettings.globalize_path("user://profile.cfg")
	var had_saved: bool = FileAccess.file_exists(storage)
	var backup: PackedByteArray = PackedByteArray()
	if had_saved:
		backup = FileAccess.get_file_as_bytes(storage)
		DirAccess.remove_absolute(storage)

	var game: Control = scene.instantiate()
	root.add_child(game)
	await process_frame

	check(game.profile_level == 1 and game.profile_xp == 0, "New players start at level 1 and 0 XP")
	check(game.profile_sapphires == 100 and game.profile_bells == 10, "New players have 100 sapphires and 10 bells")
	check(game.profile_level_label.text == "УРОВЕНЬ 1", "Main menu shows the real level")
	check(game.profile_xp_label.text == "0 / 100 XP", "Profile XP bar starts at zero")
	check(game.profile_sapphire_label != null and game.profile_bell_label != null,
		"Currencies are displayed again in the main menu")
	for old_name in ["Feature_3", "Feature_0", "ShareButton"]:
		check(game.menu_screen.find_child(old_name, true, false) == null, "Removed obsolete menu button " + old_name)
	check(game.menu_screen.find_child("PlayOnlineButton", true, false) != null, "Online lobby still has its own button")

	# XP from completed games only; offline rewards smaller than online.
	check(game.award_match_xp("bot", "win") == 24, "Bot win awards 24 XP")
	check(game.profile_level == 1 and game.profile_xp == 24, "Bot XP increases the progress bar")
	check(game.award_match_xp("bot", "loss") == 12, "Bot loss awards 12 XP")
	check(game.award_match_xp("online", "win", "server:user:match-1") == 40, "Online win awards 40 XP")
	check(game.profile_level == 1 and game.profile_xp == 76, "Online reward is slightly higher than bot but stays balanced")
	check(game.award_match_xp("online", "win", "server:user:match-1") == 0, "Duplicate result cannot farm XP")
	check(game.award_match_xp("online", "loss", "") == 0, "Online XP requires server match ID")
	check(game.award_match_xp("bot", "quit") == 0, "Quitting a match yields zero XP")
	check(game.award_match_xp("online", "draw", "server:user:match-2") == 26, "Online draw awards 26 XP")
	check(game.profile_xp_label.text == "2 / 125 XP", "Level up at 100 XP, carry remaining XP")
	check(game.profile_sapphires == 103 and game.profile_bells == 10, "Only 3 sapphires awarded at level 2")
	check(game.bot_level() == 2, "Bot level matches player level")

	# Read saved progression, and verify settings/nickname and wallet persist.
	game.player_nick = "Профиль"
	game.profile_sapphires = 93
	game.profile_bells = 8
	game.save_profile()
	game.player_nick = "tmp"
	game.profile_level = 1
	game.profile_xp = 0
	game.profile_sapphires = 0
	game.profile_bells = 0
	game.rewarded_online_matches.clear()
	game.load_profile()
	check(game.player_nick == "Профиль", "Nickname persists")
	check(game.profile_level == 2 and game.profile_xp == 2, "Level and XP persist")
	check(game.profile_sapphires == 93 and game.profile_bells == 8, "Wallet persists")
	check(game.award_match_xp("online", "win", "server:user:match-1") == 0, "Reward replay stays prevented across reload")

	# check_winner must award exactly once and never for a match with table cards.
	game.animation_enabled = false
	game.deck.clear()
	game.table_cards.clear()
	game.player_hand.clear()
	game.bot_hand = [{"rank": 4, "suit": "♠", "special": ""}]
	game.finished = false
	var xp_before: int = game.profile_xp
	game.table_cards = [{"attack":{"rank":2, "suit":"♥", "special":""}, "defense":{"rank":3, "suit":"♥", "special":""}}]
	game.check_winner()
	check(not game.finished and game.profile_xp == xp_before, "Pending table prevents premature XP")
	game.table_cards.clear()
	game.check_winner()
	check(game.finished and game.profile_xp == xp_before + 24, "Real bot win awards XP once")
	game.check_winner()
	check(game.profile_xp == xp_before + 24, "Repeated winner detection does not re-award XP")

	game.queue_free()
	await process_frame
	if had_saved:
		var f: FileAccess = FileAccess.open(storage, FileAccess.WRITE)
		if f != null:
			f.store_buffer(backup)
			f.close()
	else:
		DirAccess.remove_absolute(storage)
	print("PROFILE TESTS:", " OK" if errors == 0 else " %d FAILURES" % errors)
	quit(0 if errors == 0 else 1)
