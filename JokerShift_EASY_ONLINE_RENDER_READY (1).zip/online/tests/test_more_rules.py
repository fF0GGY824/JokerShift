import sys
from pathlib import Path
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from game import Game, RuleError, normal_rank


def c(cid, rank, suit="♠", special=""):
    return {"id":cid,"rank":rank,"suit":suit,"special":special,"joker_color":"red" if special=="joker" else "","copy_rank":-1,"copy_suit":""}


def test_equal_trump_exception_and_mark_chain():
    game = Game(["A", "B"])
    game.trump_mode, game.trump_suit = "suit", "♠"
    attack = c(800,7)
    trump = c(801,7)
    joker = c(802,20, "", "joker")
    mark = c(803,22, "", "mark")
    assert not game._beats(trump,attack)
    copied = game._prepare(joker,{"copy_target":attack["id"]}) if False else joker | {"copy_rank":7,"copy_suit":"♠"}
    assert game._beats(copied,attack)
    assert game._beats(mark,copied)
    assert not game._beats(trump,mark)
    assert game._beats(joker | {"copy_rank":100,"copy_suit":""},mark)


def test_transfer_switches_attacker():
    game = Game(["A", "B"])
    a,d=game.attacker,game.defender
    original=c(810,9)
    matching=c(811,9,"♦")
    game.table=[{"attack":original,"defense":None}]
    game.hands[d].append(matching)
    game.act(d,{"action":"transfer","card_id":matching["id"]})
    assert game.attacker==d and game.defender==a
    assert len(game.table)==2
    assert game.table[1]["attack"]["id"]==matching["id"]


def test_draw_is_bounded_and_cannot_defend_when_taking():
    game=Game(["A","B"])
    a,d=game.attacker,game.defender
    with pytest.raises(RuleError):
        game.act(a,{"action":"draw"})
    game.table=[{"attack":c(820,9),"defense":None}]
    game.act(d,{"action":"take"})
    with pytest.raises(RuleError):
        game.act(d,{"action":"defend","pair_index":0,"card_id":game.hands[d][0]["id"]})


def test_throw_needs_rank_and_round_finish_needs_defense():
    game=Game(["A","B"])
    a=game.attacker
    attack=c(830,10)
    bad_throw=c(831,6)
    game.table=[{"attack":attack,"defense":None}]
    game.hands[a].append(bad_throw)
    with pytest.raises(RuleError):
        game.act(a,{"action":"finish"})
    with pytest.raises(RuleError):
        game.act(a,{"action":"throw","card_id":831})
    game.table[0]["defense"]=c(832,11)
    with pytest.raises(RuleError):
        game.act(a,{"action":"throw","card_id":831})
