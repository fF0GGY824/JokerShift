"""Durak round refills: previous attacker ALWAYS draws before defender."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from game import Game


def card(cid, rank=7):
    return {"id": cid, "rank": rank, "suit": "♠", "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""}


def prep(attacker, taking):
    g = Game(["A", "B"])
    g.attacker = attacker
    g.defender = 1-attacker
    g.hands = [[card(91)], [card(92)]]
    g.deck = [card(99)]
    g.table = [{"attack": card(85), "defense": None if taking else card(86, 8)}]
    g.taking = taking
    return g


def test_bito_original_attacker_refills_first():
    for attacker in (0, 1):
        g = prep(attacker, False)
        g.act(attacker, {"action": "finish"})
        assert 99 in [c["id"] for c in g.hands[attacker]]
        assert 99 not in [c["id"] for c in g.hands[1-attacker]]
        assert g.attacker == 1-attacker  # defender starts next round


def test_taking_original_attacker_refills_first():
    for attacker in (0, 1):
        g = prep(attacker, True)
        g.act(attacker, {"action": "finish"})
        assert 99 in [c["id"] for c in g.hands[attacker]]
        assert 99 not in [c["id"] for c in g.hands[1-attacker]]
        assert g.attacker == attacker  # same attacker continues
