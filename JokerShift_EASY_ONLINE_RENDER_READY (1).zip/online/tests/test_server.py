import asyncio
import json
import random
import sys
from pathlib import Path

import pytest
import websockets

ROOT = Path(__file__).resolve().parents[1] / "server"
sys.path.insert(0, str(ROOT))
from game import Game, RuleError, normal_rank
from server import Hub


def test_initial_deck_unique_hidden_cards():
    for seed in range(20):
        game = Game(["A", "B"])
        cards = game.deck + game.hands[0] + game.hands[1]
        assert len(cards) == 55
        assert len({c["id"] for c in cards}) == 55
        assert sorted([c["special"] for c in cards]).count("joker") == 2
        assert sorted([c["special"] for c in cards]).count("mark") == 1
        assert len(game.hands[0]) == 6 == len(game.hands[1])
        state = game.state_for(0)
        assert "opponent_hand" not in state
        assert "deck" not in state
        assert len(state["your_hand"]) == 6
        assert state["opponent_count"] == 6


def test_attacker_cannot_play_special_first():
    game = Game(["A", "B"])
    a = game.attacker
    game.hands[a].append({"id": 900, "rank": 22, "suit": "", "special": "mark", "copy_rank": -1, "copy_suit": ""})
    with pytest.raises(RuleError, match="не могут начинать"):
        game.act(a, {"action": "attack", "card_id": 900})
    with pytest.raises(RuleError):
        game.act(1-a, {"action": "attack", "card_id": game.hands[1-a][0]["id"]})
    # Legit initial attack creates exactly one pair.
    card = next(c for c in game.hands[a] if not c["special"])
    game.act(a, {"action": "attack", "card_id": card["id"]})
    assert len(game.table) == 1
    assert game.table[0]["attack"]["id"] == card["id"]


def test_mark_defends_anything_joker_copies_only_visible():
    game = Game(["A", "B"])
    attack = {"id": 666, "rank": 13, "suit": "♠", "special": "", "copy_rank": -1, "copy_suit": ""}
    mark = {"id": 667, "rank": 22, "suit": "", "special": "mark", "copy_rank": -1, "copy_suit": ""}
    joker = {"id": 668, "rank": 20, "suit": "", "special": "joker", "joker_color": "red", "copy_rank": -1, "copy_suit": ""}
    game.table = [{"attack": attack, "defense": None}]
    game.hands[game.defender].append(mark)
    assert game._beats(mark, attack)
    game.act(game.defender, {"action": "defend", "card_id": 667, "pair_index": 0})
    assert game.table[0]["defense"]["id"] == 667
    game.hands[game.defender].append(joker)
    with pytest.raises(RuleError, match="отсутствует"):
        game.act(game.defender, {"action": "replace", "card_id": 668, "pair_index": 0, "copy_target": 12345})
    game.act(game.defender, {"action": "replace", "card_id": 668, "pair_index": 0, "copy_target": 667})
    assert normal_rank(game.table[0]["defense"]) == 100
    assert any(c["id"] == 667 for c in game.hands[game.defender])


def test_finish_defended_switches_role():
    game = Game(["A", "B"])
    a, d = game.attacker, game.defender
    attack = {"id": 900, "rank": 2, "suit": "♠", "special": "", "copy_rank": -1, "copy_suit": ""}
    defense = {"id": 901, "rank": 22, "suit": "", "special": "mark", "copy_rank": -1, "copy_suit": ""}
    game.table = [{"attack": attack, "defense": defense}]
    game.act(a, {"action": "finish"})
    assert (game.attacker, game.defender) == (d, a)
    assert not game.table
    assert game.discard_count == 2
    assert game.first_round is False


def test_take_and_finish_keeps_attacker():
    game = Game(["A", "B"])
    a, d = game.attacker, game.defender
    attack = {"id": 990, "rank": 4, "suit": "♠", "special": "", "copy_rank": -1, "copy_suit": ""}
    game.table = [{"attack": attack, "defense": None}]
    game.act(d, {"action": "take"})
    with pytest.raises(RuleError):
        game.act(d, {"action": "finish"})
    game.act(a, {"action": "finish"})
    assert game.attacker == a
    assert any(c["id"] == 990 for c in game.hands[d])


def test_invalid_commands_cannot_alter_hidden_hands():
    game = Game(["A", "B"])
    before = [len(h) for h in game.hands]
    for seat in (0,1):
        for payload in [
            {"action":"defend","card_id":34,"pair_index":0},
            {"action":"throw","card_id":34},
            {"action":"finish"},
            {"action":"invalid","card_id":4},
            {"action":"attack","card_id":"not-an-int"},
        ]:
            with pytest.raises(RuleError):
                game.act(seat, payload)
    assert before == [len(h) for h in game.hands]


@pytest.mark.asyncio
async def test_realtime_rooms_and_privacy():
    from websockets.asyncio.server import serve
    hub = Hub()
    async with serve(hub.connection, "127.0.0.1", 0, max_size=4096) as svr:
        port = svr.sockets[0].getsockname()[1]
        async with websockets.connect(f"ws://127.0.0.1:{port}") as a:
            async with websockets.connect(f"ws://127.0.0.1:{port}") as b:
                async def send(ws, obj):
                    await ws.send(json.dumps(obj, ensure_ascii=False))
                async def recv(ws):
                    return json.loads(await asyncio.wait_for(ws.recv(), 3))
                await send(a, {"type":"create", "name":"Алиса"})
                first=await recv(a)
                assert first["type"] == "room" and len(first["code"]) == 6
                code=first["code"]
                await send(b, {"type":"join", "code":code, "name":"Боб"})
                assert (await recv(a))["type"] == "room"
                assert (await recv(b))["type"] == "room"
                await send(a, {"type":"ready"})
                assert (await recv(a))["type"] == "room"
                assert (await recv(b))["type"] == "room"
                await send(b, {"type":"ready"})
                assert (await recv(a))["type"] == "room"
                assert (await recv(b))["type"] == "room"
                s0=await recv(a); s1=await recv(b)
                assert s0["type"] == s1["type"] == "state"
                assert s0["your_seat"] != s1["your_seat"]
                assert "opponent_hand" not in s0
                assert not set(c["id"] for c in s0["your_hand"]) & set(c["id"] for c in s1["your_hand"])
                # Client cannot play a card held by the other player.
                wrong_id=s1["your_hand"][0]["id"]
                await send(a, {"type":"action", "action":"attack", "card_id":wrong_id})
                err=await recv(a)
                assert err["type"] == "error"
                attacker = s0["attacker"]
                ws_att=a if attacker == 0 else b
                active_state=s0 if attacker == 0 else s1
                regular=next(c for c in active_state["your_hand"] if not c["special"])
                await send(ws_att, {"type":"action", "action":"attack", "card_id":regular["id"]})
                state0=await recv(a); state1=await recv(b)
                assert len(state0["table"]) == len(state1["table"]) == 1
                assert state0["table"] == state1["table"]
                assert "deck" not in state0 and "deck" not in state1
                await a.close()
                left=await recv(b)
                assert left["type"] == "peer_left"
