"""Persistent profiles, consent-based friends and private direct messages."""
import asyncio
import json
import sys
from pathlib import Path

import pytest
import websockets
from websockets.asyncio.server import serve

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
from server import Hub
from social import SocialStore


def test_accounts_and_friendship_survive_restart(tmp_path):
    db=str(tmp_path/'social.db')
    store=SocialStore(db)
    a,token_a,_=store.authenticate('', 'Алиса')
    b,token_b,_=store.authenticate('', 'Боб')
    assert len(a)==len(b)==8 and a!=b
    assert len(token_a)==64
    assert store.authenticate(token_a,'Алиса2')[0]==a
    with pytest.raises(ValueError):
        store.authenticate('f'*64,'Проходимец')
    with pytest.raises(ValueError):
        store.request(a,'99999999')
    store.request(a,b)
    assert [x['id'] for x in store.snapshot(b,set())['requests']]==[a]
    store.respond(b,a,True)
    assert store.is_friend(a,b)
    store.close()
    reloaded=SocialStore(db)
    assert reloaded.is_friend(a,b)
    assert reloaded.authenticate(token_b,'Боб')[0]==b
    reloaded.block(b,a)
    assert not reloaded.is_friend(a,b)
    with pytest.raises(ValueError):
        reloaded.request(a,b)
    reloaded.close()


@pytest.mark.asyncio
async def test_two_clients_add_friend_chat_invite_and_play(tmp_path):
    hub = Hub(str(tmp_path / 'hub.db'))
    async with serve(hub.connection,'127.0.0.1',0,max_size=8192) as server:
        port=server.sockets[0].getsockname()[1]
        async with websockets.connect(f'ws://127.0.0.1:{port}') as a, websockets.connect(f'ws://127.0.0.1:{port}') as b:
            async def send(ws, obj):
                await ws.send(json.dumps(obj,ensure_ascii=False))
            async def recv(ws, packet_type=None):
                for _ in range(15):
                    packet=json.loads(await asyncio.wait_for(ws.recv(),3))
                    if packet_type is None or packet['type']==packet_type:
                        return packet
                assert False, f'Expected {packet_type}'
            await send(a,{'type':'hello','name':'Алиса'})
            profile_a=await recv(a,'hello')
            assert len(profile_a['id'])==8 and len(profile_a['token'])==64
            await recv(a,'social')
            await send(b,{'type':'hello','name':'Боб'})
            profile_b=await recv(b,'hello')
            await recv(a,'social'); await recv(b,'social')
            uid_a,uid_b=profile_a['id'],profile_b['id']
            await send(a,{'type':'dm','id':uid_b,'text':'Только друзьям!'})
            assert (await recv(a,'error'))['type']=='error'
            await send(a,{'type':'friend_request','id':uid_b})
            await recv(a,'social')
            incoming=await recv(b,'social')
            assert incoming['requests'][0]['id']==uid_a
            await recv(a,'notice')
            await send(b,{'type':'friend_accept','id':uid_a})
            assert (await recv(a,'social'))['friends'][0]['id']==uid_b
            assert (await recv(b,'social'))['friends'][0]['id']==uid_a
            await send(a,{'type':'dm','id':uid_b,'text':'Привет, сыграем?'})
            ma=await recv(a,'dm'); mb=await recv(b,'dm')
            assert ma['text']==mb['text']=='Привет, сыграем?'
            assert 'token' not in str(ma) and 'card' not in ma
            await send(a,{'type':'dm','id':uid_b,'text':'X'*241})
            assert (await recv(a,'error'))['type']=='error'
            await send(a,{'type':'create','name':'Алиса'})
            room=await recv(a,'room')
            code=room['code']
            await send(a,{'type':'invite','id':uid_b})
            invitation=await recv(b,'invite')
            assert invitation['code']==code and invitation['from_id']==uid_a
            await recv(a,'notice')
            await send(b,{'type':'invite_accept','code':code})
            assert (await recv(a,'room'))['players']==['Алиса','Боб']
            assert (await recv(b,'room'))['seat']==1
            await send(a,{'type':'room_chat','text':'Всем привет'})
            assert (await recv(a,'room_chat'))['text']=='Всем привет'
            assert (await recv(b,'room_chat'))['text']=='Всем привет'
            await send(a,{'type':'ready'})
            await recv(a,'room');await recv(b,'room')
            await send(b,{'type':'ready'})
            await recv(a,'room');await recv(b,'room')
            sa=await recv(a,'state'); sb=await recv(b,'state')
            assert len(sa['your_hand'])==len(sb['your_hand'])==6
            assert not set(c['id'] for c in sa['your_hand']) & set(c['id'] for c in sb['your_hand'])
            assert 'opponent_hand' not in sa
    hub.social.close()
