"""Final fully defended round ends without manually pressing Bito."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'server'))
from game import Game


def card(cid, rank, suit='♠'):
    return {'id': cid, 'rank': rank, 'suit': suit, 'special': '', 'joker_color': '', 'copy_rank': -1, 'copy_suit': ''}


def test_final_defense_finishes_automatically():
    game = Game(['Игрок 1', 'Игрок 2'])
    game.deck = []
    game.hands = [[], [card(6, 8)]]
    game.attacker = 0
    game.defender = 1
    game.first_round = False
    game.table = [{'attack':card(7,7), 'defense':None}]
    game.act(1, {'action':'defend', 'card_id': 6, 'pair_index':0})
    assert game.table == []
    assert game.finished
    assert game.winner is None
    assert game.discard_count >= 2


def test_open_attack_cannot_finish_early():
    game = Game(['Игрок 1', 'Игрок 2'])
    game.deck = []
    game.hands = [[], [card(6,8)]]
    game.attacker = 0
    game.defender = 1
    game.first_round = False
    game.table = [{'attack':card(7,7), 'defense':None}]
    game._auto_end_final_round()
    assert len(game.table) == 1
    assert not game.finished


def test_no_more_throw_when_defender_out_of_cards():
    game = Game(['Игрок 1', 'Игрок 2'])
    game.deck = []
    game.hands = [[card(44,7)], []]
    game.attacker = 0
    game.defender = 1
    game.first_round = False
    game.table = [{'attack':card(7,7), 'defense':card(8,8)}]
    game._auto_end_final_round()
    # When defender has no remaining cards and all attacks are defended,
    # there is no extra throw-in capacity: conclude the final round.
    assert game.table == []
    assert game.finished
