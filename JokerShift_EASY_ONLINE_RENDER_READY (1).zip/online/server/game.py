"""Authoritative two-player JokerShift rules. No client is trusted with deck or turn control."""
from __future__ import annotations

import secrets
from typing import Any

SUITS = ("♠", "♥", "♦", "♣")


class RuleError(Exception):
    pass


def normal_rank(card: dict) -> int:
    if card["special"] == "mark":
        return 100
    if card["special"] == "joker":
        return card.get("copy_rank", -1)
    return card["rank"]


def normal_suit(card: dict) -> str:
    if card["special"] == "joker":
        return card.get("copy_suit", "")
    return card["suit"]


def reset(card: dict) -> dict:
    fresh = card.copy()
    if fresh["special"] == "joker":
        fresh["copy_rank"] = -1
        fresh["copy_suit"] = ""
    return fresh


class Game:
    def __init__(self, names: list[str]) -> None:
        if len(names) != 2:
            raise ValueError("Exactly two players required")
        self.names = names[:]
        self.match_id: str = secrets.token_hex(12)
        self.hands: list[list[dict]] = [[], []]
        self.deck: list[dict] = []
        self.table: list[dict] = []
        self.discard_count = 0
        self.replaced_ranks: set[int] = set()
        self.first_round = True
        self.taking = False
        self.finished = False
        self.winner: int | None = None
        self.notice = "Партия началась!"
        self.round_number = 1
        serial = 1
        for suit in SUITS:
            for rank in range(2, 15):
                self.deck.append({"id": serial, "rank": rank, "suit": suit, "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""})
                serial += 1
        for color in ("red", "black"):
            self.deck.append({"id": serial, "rank": 20, "suit": "", "special": "joker", "joker_color": color, "copy_rank": -1, "copy_suit": ""})
            serial += 1
        self.deck.append({"id": serial, "rank": 22, "suit": "", "special": "mark", "joker_color": "", "copy_rank": -1, "copy_suit": ""})
        secrets.SystemRandom().shuffle(self.deck)
        self.trump_card = self.deck[0].copy()
        if self.trump_card["special"] == "mark":
            self.trump_mode, self.trump_suit = "none", ""
        elif self.trump_card["special"] == "joker":
            self.trump_mode, self.trump_suit = self.trump_card["joker_color"], ""
        else:
            self.trump_mode, self.trump_suit = "suit", self.trump_card["suit"]
        for h in self.hands:
            self._draw(h)
        lows = [self._lowest_trump(self.hands[0]), self._lowest_trump(self.hands[1])]
        if lows[0] == lows[1]:
            self.attacker = secrets.randbelow(2)
        else:
            self.attacker = 0 if lows[0] < lows[1] else 1
        self.defender = 1 - self.attacker

    def _lowest_trump(self, hand: list[dict]) -> int:
        return min((normal_rank(c) for c in hand if not c["special"] and self._is_trump(c)), default=999)

    def _is_trump(self, c: dict) -> bool:
        suit = normal_suit(c)
        if self.trump_mode == "none":
            return False
        if self.trump_mode == "red":
            return suit in ("♥", "♦")
        if self.trump_mode == "black":
            return suit in ("♠", "♣")
        return suit == self.trump_suit

    def _draw(self, hand: list[dict]) -> None:
        while len(hand) < 6 and self.deck:
            hand.append(self.deck.pop())

    def _beats(self, c: dict, a: dict) -> bool:
        if c["special"] == "mark" or (c["special"] == "joker" and normal_rank(c) == 100):
            return True
        if a["special"] == "mark" or (a["special"] == "joker" and normal_rank(a) == 100):
            return False
        cr, ar = normal_rank(c), normal_rank(a)
        if c["special"] == "joker" and cr < 2:
            return False
        ct, at = self._is_trump(c), self._is_trump(a)
        if at:
            return ct and (cr > ar or (c["special"] == "joker" and cr == ar and normal_suit(c) == normal_suit(a)))
        return ct or (normal_suit(c) == normal_suit(a) and cr > ar)

    def _table_ranks(self) -> set[int]:
        ranks = set(self.replaced_ranks)
        for pair in self.table:
            ranks.add(normal_rank(pair["attack"]))
            if pair["defense"]:
                ranks.add(normal_rank(pair["defense"]))
        return ranks

    def _all_defended(self) -> bool:
        return bool(self.table) and all(x["defense"] for x in self.table)

    def _limit(self) -> int:
        defended = sum(1 for p in self.table if p["defense"])
        available = len(self.hands[self.defender]) + defended
        return min(8 if self.first_round else 10, max(len(self.table), available))

    def _get_card(self, seat: int, cid: Any) -> tuple[int, dict]:
        if type(cid) is not int:
            raise RuleError("Нужно выбрать карту.")
        for i, c in enumerate(self.hands[seat]):
            if c["id"] == cid:
                return i, c
        raise RuleError("Этой карты нет в твоей руке.")

    def _get_pair(self, index: Any) -> dict:
        if type(index) is not int or not 0 <= index < len(self.table):
            raise RuleError("Сначала выбери карту на столе.")
        return self.table[index]

    def _prepare(self, card: dict, action: dict) -> dict:
        if card["special"] != "joker":
            return card.copy()
        target_id = action.get("copy_target")
        if type(target_id) is not int:
            raise RuleError("Джокер должен скопировать открытую карту на столе.")
        targets = [item for p in self.table for item in (p["attack"], p["defense"]) if item]
        target = next((c for c in targets if c["id"] == target_id), None)
        if target is None:
            raise RuleError("Карта для копирования отсутствует на столе.")
        result = card.copy()
        result["copy_rank"] = normal_rank(target)
        result["copy_suit"] = normal_suit(target)
        return result

    def _check_finished(self) -> None:
        if self.table or self.deck:
            return
        empty = [not h for h in self.hands]
        if empty[0] or empty[1]:
            self.finished = True
            self.winner = None if all(empty) else (0 if empty[0] else 1)
            self.notice = "Ничья!" if self.winner is None else "%s победил!" % self.names[self.winner]
        elif all(c["special"] for c in self.hands[self.attacker]):
            self.finished = True
            self.winner = self.defender
            self.notice = "%s победил: у соперника только особые карты." % self.names[self.winner]

    def _attacker_has_throw(self) -> bool:
        if not self.table or len(self.table) >= 10 or len(self.table) >= self._limit():
            return False
        ranks = self._table_ranks()
        visible = [c for pair in self.table for c in (pair["attack"], pair["defense"]) if c]
        for card in self.hands[self.attacker]:
            if card["special"] == "mark":
                continue
            if card["special"] == "joker":
                if any(normal_rank(target) in ranks for target in visible):
                    return True
            elif normal_rank(card) in ranks:
                return True
        return False

    def _end_round(self) -> None:
        old_attacker = self.attacker
        old_defender = self.defender
        if self.taking:
            for pair in self.table:
                self.hands[self.defender].append(reset(pair["attack"]))
                if pair["defense"]:
                    self.hands[self.defender].append(reset(pair["defense"]))
            self.notice = "%s забрал карты. Атакующий ходит снова." % self.names[self.defender]
        else:
            self.discard_count += sum(1 + bool(p["defense"]) for p in self.table)
            self.attacker, self.defender = self.defender, self.attacker
            self.notice = "Бито! Теперь ходит %s." % self.names[self.attacker]
        self.table.clear()
        self.replaced_ranks.clear()
        self.taking = False
        self.first_round = False
        self.round_number += 1
        self._draw(self.hands[old_attacker])
        self._draw(self.hands[old_defender])
        self._check_finished()

    def _auto_end_final_round(self) -> None:
        # Do not deny throw-ins or make an early win with cards still on the table.
        if self.finished or self.deck or not self.table:
            return
        if not (not self.hands[0] or not self.hands[1]):
            return
        if self.taking:
            if self.hands[self.attacker] or self._attacker_has_throw():
                return
        elif not self._all_defended() or self._attacker_has_throw():
            return
        self._end_round()

    def act(self, seat: int, msg: dict) -> None:
        if seat not in (0, 1) or self.finished:
            raise RuleError("Партия уже закончилась.")
        verb = msg.get("action")
        if verb not in ("attack", "throw", "defend", "replace", "transfer", "take", "finish", "draw"):
            raise RuleError("Неизвестное действие.")
        if verb == "draw":
            if self.taking or len(self.hands[seat]) >= 6 or not self.deck:
                raise RuleError("Сейчас нельзя добрать карту.")
            self.hands[seat].append(self.deck.pop())
            self.notice = "%s добрал карту." % self.names[seat]
            return
        if verb == "take":
            if seat != self.defender or not self.table or self.taking:
                raise RuleError("Забрать карты сейчас нельзя.")
            self.taking = True
            self.notice = "%s забирает карты. Соперник может подкинуть." % self.names[seat]
            self._auto_end_final_round()
            return
        if verb == "finish":
            if seat != self.attacker or not self.table or not (self.taking or self._all_defended()):
                raise RuleError("Завершить раунд пока нельзя.")
            self._end_round()
            return
        if verb == "attack":
            if seat != self.attacker or self.table:
                raise RuleError("Начать атаку сейчас нельзя.")
            i, c = self._get_card(seat, msg.get("card_id"))
            if c["special"]:
                raise RuleError("Джокер и метка не могут начинать атаку.")
            self.hands[seat].pop(i)
            self.table.append({"attack": c.copy(), "defense": None})
            self.notice = "%s атакует. %s отбивается." % (self.names[seat], self.names[self.defender])
            return
        if verb == "throw":
            if seat != self.attacker or not self.table:
                raise RuleError("Сейчас не твой ход для подкидывания.")
            if not self.taking and not self._all_defended():
                raise RuleError("Подожди, пока соперник отобьётся или заберёт карты.")
            if len(self.table) >= self._limit() or len(self.table) >= 10:
                raise RuleError("Достигнут лимит подкидывания.")
            i, card = self._get_card(seat, msg.get("card_id"))
            c = self._prepare(card, msg)
            if normal_rank(c) == 100 and card["special"] != "joker":
                raise RuleError("Метку нельзя подкинуть.")
            if normal_rank(c) not in self._table_ranks():
                raise RuleError("Подкинуть можно только достоинство со стола.")
            self.hands[seat].pop(i)
            self.table.append({"attack": c, "defense": None})
            self.notice = "%s подкинул карту." % self.names[seat]
            self._auto_end_final_round()
            return
        if verb == "defend":
            if seat != self.defender or self.taking:
                raise RuleError("Сейчас ты не отбиваешься.")
            p = self._get_pair(msg.get("pair_index"))
            if p["defense"]:
                raise RuleError("Атака уже отбита. Можно заменить защиту.")
            i, card = self._get_card(seat, msg.get("card_id"))
            c = self._prepare(card, msg)
            if not self._beats(c, p["attack"]):
                raise RuleError("Эта карта не отбивает атаку.")
            self.hands[seat].pop(i)
            p["defense"] = c
            self.notice = "%s отбился." % self.names[seat]
            self._auto_end_final_round()
            return
        if verb == "replace":
            if seat != self.defender or self.taking:
                raise RuleError("Защита сейчас недоступна.")
            p = self._get_pair(msg.get("pair_index"))
            if not p["defense"]:
                raise RuleError("Нечего заменять.")
            i, card = self._get_card(seat, msg.get("card_id"))
            c = self._prepare(card, msg)
            if not self._beats(c, p["attack"]):
                raise RuleError("Новая карта не отбивает атаку.")
            self.replaced_ranks.add(normal_rank(p["defense"]))
            old = reset(p["defense"])
            p["defense"] = c
            self.hands[seat][i] = old
            self.notice = "%s заменил карту защиты." % self.names[seat]
            self._auto_end_final_round()
            return
        if verb == "transfer":
            if seat != self.defender or self.taking or not self.table:
                raise RuleError("Перевести атаку сейчас нельзя.")
            if any(p["defense"] for p in self.table) or len(self.table) >= (8 if self.first_round else 10):
                raise RuleError("Перевод разрешён только до первого отбивания.")
            if len(self.hands[self.attacker]) < len(self.table) + 1:
                raise RuleError("У соперника не хватит карт на защиту.")
            i, card = self._get_card(seat, msg.get("card_id"))
            c = self._prepare(card, msg)
            if (normal_rank(c) == 100 and card["special"] != "joker") or normal_rank(c) not in self._table_ranks():
                raise RuleError("Для перевода нужно совпадающее достоинство.")
            self.hands[seat].pop(i)
            self.table.append({"attack": c, "defense": None})
            self.attacker, self.defender = self.defender, self.attacker
            self.notice = "%s перевёл атаку!" % self.names[seat]
            return

    def state_for(self, seat: int) -> dict:
        return {
            "type": "state",
            "stage": "finished" if self.finished else "game",
            "match_id": self.match_id,
            "your_seat": seat,
            "your_name": self.names[seat],
            "opponent_name": self.names[1 - seat],
            "your_hand": [c.copy() for c in self.hands[seat]],
            "opponent_count": len(self.hands[1 - seat]),
            "table": [dict(attack=p["attack"].copy(), defense=(p["defense"].copy() if p["defense"] else None)) for p in self.table],
            "deck_count": len(self.deck),
            "discard_count": self.discard_count,
            "trump_mode": self.trump_mode,
            "trump_suit": self.trump_suit,
            "attacker": self.attacker,
            "defender": self.defender,
            "taking": self.taking,
            "round": self.round_number,
            "first_round": self.first_round,
            "winner": self.winner,
            "notice": self.notice,
        }
