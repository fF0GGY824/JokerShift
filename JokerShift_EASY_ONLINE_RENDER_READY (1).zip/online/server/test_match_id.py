from game import Game

def test_unique_server_match_ids():
    a = Game(["First", "Second"])
    b = Game(["First", "Second"])
    assert a.match_id != b.match_id
    assert len(a.match_id) == 24
    assert a.state_for(0)["match_id"] == a.state_for(1)["match_id"]
    assert a.state_for(0)["stage"] == "game"
