JokerShift — portrait phone UI fix

INSTALL / OPEN
1) Extract this ZIP to an empty folder (do not try to open ZIP as a project).
2) Open Godot 4.x Project Manager > Import > choose project.godot.
3) Run F6/F5 to test the main menu and start a match.
4) Godot Android export requires Android SDK + export templates; this is not an APK.

MOBILE LAYOUT (portrait)
- Replaced the old squeezed "deck / trump" column with an independent 2-column information HUD.
- Deck count, discard count, and trump are updated with each game state change.
- Time, enemy hand, table, player hand, and action buttons remain in screen layout.
- 5x2 table card grid with narrower defense overlap; cards maintain 2:3 aspect.
- Phone menu starts at top; secondary items collapse on short screens.
- No mobile horizontal mode; sensor portrait orientation remains enabled.
- Vertical scrolling remains an emergency fallback for screens shorter than 610 logical pixels.

TEST LIMITATION
The archive and its resources were verified through code and ZIP integrity checks.
No Godot executable was available in this environment, so live in-engine screenshots
and on-device interaction tests were NOT run.
