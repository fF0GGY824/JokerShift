extends SceneTree

# Portrait regression checks (run in Godot, not in Python):
# godot --headless --path . --script res://tests/mobile_layout.gd

var errors: int = 0

func verify(condition: bool, message: String) -> void:
	if condition:
		print("PASS: ", message)
	else:
		errors += 1
		push_error("FAIL: " + message)

func _initialize() -> void:
	call_deferred("run_mobile_checks")

func run_mobile_checks() -> void:
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	if scene == null:
		push_error("Could not load game scene")
		quit(1)
		return
	var game: Control = scene.instantiate()
	root.add_child(game)
	await process_frame
	game.start_game()
	await process_frame

	verify(int(ProjectSettings.get_setting("display/window/handheld/orientation")) == 5,
		"Android requests sensor portrait orientation")
	verify(game.menu_screen.find_child("MenuBackground", true, false).stretch_mode == TextureRect.STRETCH_KEEP_ASPECT_COVERED,
		"Menu background crops rather than distorting")
	verify(game.mobile_deck_strip != null, "Mobile HUD is present")

	var dimensions: Array[Vector2i] = [
		Vector2i(320, 568),
		Vector2i(360, 640),
		Vector2i(390, 844),
		Vector2i(480, 854),
		Vector2i(720, 1280)
	]
	for screen in dimensions:
		root.size = screen
		await process_frame
		game.adapt_layout(Vector2(screen))
		await process_frame
		var label: String = "%dx%d" % [screen.x, screen.y]
		verify(game.battle_layout.columns == 1, label + " field above info HUD")
		verify(game.hand_actions_layout.columns == 1, label + " hand above action buttons")
		verify(game.game_screen.find_child("ActionButtons", true, false).columns == 3,
			label + " three action buttons in one row")
		verify(not game.deck_panel.visible, label + " no oversized desktop deck art")
		verify(game.mobile_deck_strip.visible, label + " compact info HUD visible")
		verify(game.field_panel.custom_minimum_size.x <= float(screen.x - 6),
			label + " five card slots fit viewport width")
		verify(game.mobile_deck_label.autowrap_mode == TextServer.AUTOWRAP_OFF,
			label + " deck label cannot become vertical letters")
		verify(game.mobile_trump_label.autowrap_mode == TextServer.AUTOWRAP_OFF,
			label + " trump label cannot become vertical letters")
		verify(game.menu_screen.find_child("MenuCenter", true, false).size_flags_vertical == Control.SIZE_SHRINK_BEGIN,
			label + " menu starts near the top")
		verify(game.game_screen.find_child("GameScroll", true, false).vertical_scroll_mode == ScrollContainer.SCROLL_MODE_AUTO,
			label + " scroll fallback prevents clipped buttons")
		verify(game.game_screen.find_child("HandSpacer", true, false).visible,
			label + " hand pinned near lower screen")
		var center_gap: Control = game.game_screen.find_child("TableCenterSpacer", true, false) as Control
		verify(center_gap != null and center_gap.visible,
			label + " dedicated flexible gap before playing field")
		verify(game.game_screen.find_child("HandSpacer", true, false).size_flags_vertical == Control.SIZE_EXPAND_FILL,
			label + " flexible gap below playing field")
		verify(game.battle_layout.size_flags_vertical == Control.SIZE_SHRINK_BEGIN,
			label + " field does not steal all vertical space")

	verify(game.menu_screen.find_child("PlayOnlineButton", true, false) != null,
		"Planned multiplayer entry retained")
	verify(game.menu_screen.find_child("PlayButton", true, false) != null,
		"Offline mode retained")
	print("Mobile checks: ", "PASS" if errors == 0 else "%d failures" % errors)
	quit(0 if errors == 0 else 1)
