extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func make_card(i: int) -> Dictionary:
	return {"rank": 2 + i % 12, "suit": "♠", "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": "", "id": i}

func verify() -> void:
	var game: Control = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	for original_attacker in [0, 1]:
		game.player_hand = [make_card(1)]
		game.bot_hand = [make_card(2)]
		game.deck = [make_card(99)]
		game.refill_after_turn(original_attacker)
		var correct: bool = (
			(game.player_hand as Array).any(func(c: Dictionary) -> bool: return c.get("id") == 99)
			if original_attacker == 0
			else (game.bot_hand as Array).any(func(c: Dictionary) -> bool: return c.get("id") == 99)
		)
		if not correct:
			push_error("Wrong draw order for attacker " + str(original_attacker))
			quit(1)
			return
		print("PASS: attacker %d draws before defender" % original_attacker)
	print("PASS: draw order independently of next attack")
	quit(0)
