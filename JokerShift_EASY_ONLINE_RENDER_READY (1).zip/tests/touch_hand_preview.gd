extends SceneTree

func _initialize() -> void:
	call_deferred("capture")

func make_card(i: int, rank: int) -> Dictionary:
	return {"id": i, "rank": rank, "suit": "♠", "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""}

func capture() -> void:
	root.size = Vector2i(480, 854)
	var game: Variant = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.animation_enabled = false
	game.start_game()
	game.player_hand = []
	for i in range(9):
		game.player_hand.append(make_card(i, 2 + i))
	game.selected_index = 4
	game.update_ui()
	game.adapt_layout(Vector2(480,854))
	await create_timer(0.40).timeout
	print("SIZE: HAND=", game.hand_scroll.size, " SELECTOR=", game.hand_picker_slider.size, " CARD=", game.hand_card_width, " TABLE=",game.card_width)
	var path: String = "/mnt/data/JokerShift_hand_slider_preview.png"
	var result: Error = root.get_texture().get_image().save_png(path)
	print("SCREENSHOT ", result, " -> ", path)
	quit(0 if result == OK else 1)
