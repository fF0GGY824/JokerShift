extends SceneTree

var issues: int = 0

func verify(value: bool, message: String) -> void:
	if value:
		print("PASS: ", message)
	else:
		issues += 1
		push_error("FAIL: " + message)

func _initialize() -> void:
	call_deferred("run_checks")

func run_checks() -> void:
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	var game: Variant = scene.instantiate()
	root.add_child(game)
	await process_frame
	game.animation_enabled = false
	for screen in [Vector2(320, 568), Vector2(360, 640), Vector2(390, 844), Vector2(480, 854), Vector2(720, 1280)]:
		game.adapt_layout(screen)
		game.show_coming_soon("Достижения")
		var achievement: Control = game.coming_soon_overlay
		var acard: PanelContainer = achievement.find_child("PremiumModalCard", true, false)
		verify(achievement.visible, "Achievements opens designed overlay %s" % screen)
		verify(acard.custom_minimum_size.x <= screen.x - 20.0, "Achievement card fits viewport width %s" % screen)
		verify(game.coming_soon_title_label.text == "ДОСТИЖЕНИЯ", "Achivement heading updated %s" % screen)
		var dismiss: Button = achievement.find_child("ComingSoonOkayButton", true, false)
		verify(dismiss != null and dismiss.custom_minimum_size.y >= 48, "Achievement button is touch-sized %s" % screen)
		dismiss.pressed.emit()
		verify(not achievement.visible, "Achievement popup dismisses %s" % screen)
		game.ask_exit_game()
		var exit_modal: Control = game.exit_overlay
		var card: PanelContainer = exit_modal.find_child("PremiumModalCard", true, false)
		verify(exit_modal.visible, "Exit uses custom overlay %s" % screen)
		verify(card.custom_minimum_size.x <= screen.x - 20.0, "Exit card fits viewport width %s" % screen)
		var stay: Button = exit_modal.find_child("ExitStayButton", true, false)
		var leave: Button = exit_modal.find_child("ExitLeaveButton", true, false)
		verify(stay != null and leave != null and stay.custom_minimum_size.y >= 48 and leave.custom_minimum_size.y >= 48, "Large Exit/Stay buttons %s" % screen)
		stay.pressed.emit()
		verify(not exit_modal.visible, "Stay cancels exit %s" % screen)
	verify(game.exit_overlay.find_child("ModalShade", true, false) != null, "Fullscreen dim background exists")
	verify(game.coming_soon_overlay.find_child("ModalIconPlate", true, false) != null, "Decorative badge exists")
	print("PREMIUM MODAL TESTS: ", "PASS" if issues == 0 else "%d failed" % issues)
	quit(0 if issues == 0 else 1)
