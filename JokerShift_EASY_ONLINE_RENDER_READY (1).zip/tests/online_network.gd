extends SceneTree

func _initialize() -> void:
	call_deferred("_test")


func _until(check: Callable, message: String) -> bool:
	for _step in range(250):
		if check.call():
			print("PASS: " + message)
			return true
		await create_timer(0.025).timeout
	push_error("TIMEOUT: " + message)
	return false


func _has_code(client: Control) -> bool:
	return client.current_code.length() == 6


func _game_started(client: Control) -> bool:
	return client.state.get("type", "") == "state"


func _table_attacked(client: Control) -> bool:
	return (client.state.get("table", []) as Array).size() == 1


func _test() -> void:
	var offline: Control = load("res://control.tscn").instantiate()
	root.add_child(offline)
	await process_frame
	offline.open_online()
	var a: Control = offline.online_view
	# Independent disposable accounts: do not reuse a real player's saved profile key.
	a.profile_storage_path = "user://online_network_host_" + str(Time.get_ticks_usec()) + ".cfg"
	var online_script: Script = load("res://online/online_ui.gd")
	var b: Control = online_script.new()
	b.offline_game = offline
	b.profile_storage_path = "user://online_network_guest_" + str(Time.get_ticks_usec()) + ".cfg"
	root.add_child(b)
	await process_frame
	a.url_input.text = "ws://127.0.0.1:8765"
	b.url_input.text = "ws://127.0.0.1:8765"
	offline.nick_input.text = "Алиса"  # Nickname is edited only in the main menu.
	a._begin_request("create")
	if not await _until(_has_code.bind(a), "Create room via Godot WebSocketPeer"):
		quit(1)
		return
	b.code_input.text = a.current_code
	b._begin_request("join")
	if not await _until(_has_code.bind(b), "Join room by six-digit code"):
		quit(1)
		return
	a._do_ready()
	b._do_ready()
	if not await _until(_game_started.bind(a), "Host received initial private game state"):
		quit(1)
		return
	if not await _until(_game_started.bind(b), "Guest received initial private game state"):
		quit(1)
		return
	if a.state.get("opponent_hand", null) != null or b.state.get("opponent_hand", null) != null:
		push_error("Opponent hidden hand was leaked")
		quit(1)
		return
	print("PASS: Neither client receives secret cards")
	var attacker: Control = a if int(a.state.get("attacker", -1)) == 0 else b
	var cid: int = -1
	for card in attacker.state.get("your_hand", []):
		if str(card.get("special", "")) == "":
			cid = int(card.get("id", -1))
			break
	if cid < 0:
		push_error("No ordinary card in attacker's hand")
		quit(1)
		return
	attacker.selected_card_id = cid
	attacker._on_table_selected(0)
	if not await _until(_table_attacked.bind(a), "Attack is synchronized to host"):
		quit(1)
		return
	if not await _until(_table_attacked.bind(b), "Attack is synchronized to guest"):
		quit(1)
		return
	print("PASS: Godot / Python online integration")
	a._do_leave()
	b._do_leave()
	quit(0)
