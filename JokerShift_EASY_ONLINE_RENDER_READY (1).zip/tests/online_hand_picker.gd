extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var game: Variant = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.open_online()
	await process_frame
	var ui: Variant = game.online_view
	var cards: Array = []
	for i in range(8):
		cards.append({"id":i+1, "rank": i+2, "suit":"♣", "special":"", "copy_rank":-1, "copy_suit":"", "joker_color":""})
	ui.state = {"your_hand":cards}
	ui._render_hand()
	await process_frame
	if ui.hand_row.get_child_count() != 8 or ui.online_hand_slider == null or ui.hand_row.get_child(0).size.x < 74:
		push_error("Online hand should be larger with slider")
		quit(1)
		return
	ui._select_online_hand_index(6.0)
	if ui.selected_card_id != 7 or int(ui.online_hand_slider.value) != 6:
		push_error("Online slider fails to select by card id")
		quit(1)
		return
	ui._step_online_hand_card(-1)
	if ui.selected_card_id != 6:
		push_error("Online previous card button fails")
		quit(1)
		return
	print("PASS: Online larger hand, card slider and arrow navigation")
	quit(0)
