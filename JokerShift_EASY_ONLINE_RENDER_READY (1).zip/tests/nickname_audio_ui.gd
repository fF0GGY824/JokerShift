extends SceneTree

func _initialize() -> void:
	call_deferred("_verify")

func _verify() -> void:
	var game: Control = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	if game.nick_input == null or game.sfx_slider == null:
		push_error("Main menu must contain nickname and SFX volume")
		quit(1)
		return
	game.open_online()
	await process_frame
	var online: Control = game.online_view
	for node in online.form_panel.find_children("*", "LineEdit", true, false):
		if "nick" in node.name.to_lower():
			push_error("Found duplicate nickname field in online page")
			quit(1)
			return
	if online.friends_section.find_children("*Nickname*", "LineEdit", true, false).size() > 0:
		push_error("Found duplicate nickname field in friends page")
		quit(1)
		return
	var nickname_before: String = game.nick_input.text
	game.nick_input.text = "ЕдиныйНик"
	game.on_nickname_live("ЕдиныйНик")
	if online._player_name() != "ЕдиныйНик":
		push_error("Online doesn't use the main menu nickname")
		quit(1)
		return
	game.nick_input.text = nickname_before
	game.on_nickname_live(nickname_before)
	print("PASS: nickname edited only in menu and shared with online")
	if game.sfx_pool.size() != 8:
		push_error("Sound effect player pool missing")
		quit(1)
		return
	print("PASS: 8 sound effect channels and volume slider")
	quit(0)
