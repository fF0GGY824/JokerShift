extends SceneTree

# Run from the Godot editor's bundled executable:
# godot --headless --path . --script res://tests/smoke.gd

var errors: int = 0

func verify(condition: bool, description: String) -> void:
	if condition:
		print("PASS: ", description)
	else:
		errors += 1
		push_error("FAIL: " + description)

func normal_card(rank: int, suit: String) -> Dictionary:
	return {
		"rank": rank,
		"suit": suit,
		"special": "",
		"joker_color": "",
		"copy_rank": -1,
		"copy_suit": ""
	}

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var scene: PackedScene = load("res://control.tscn") as PackedScene
	verify(scene != null, "Main scene loads")
	if scene == null:
		quit(1)
		return

	var game: Variant = scene.instantiate()
	root.add_child(game)
	await process_frame
	verify(game.menu_panel != null, "Premium home screen is present")
	verify(game.menu_screen.find_child("PlayButton", true, false) != null, "Large Play button is visible")
	var online_button: Button = game.menu_screen.find_child("PlayOnlineButton", true, false) as Button
	verify(online_button != null, "Online play button exists in the main menu")
	if online_button != null:
		var online_notice: Label = online_button.find_child("OnlinePlayNotice", true, false) as Label
		verify(online_notice != null and online_notice.text.contains("КОМНАТЫ ПО КОДУ"), "Online play offers six-digit room codes")
		online_button.pressed.emit()
		verify(game.online_view != null and game.online_view.form_panel != null, "Online button opens functional WebSocket lobby")
		game.online_view._do_leave()
	verify(game.menu_screen.find_child("MenuRulesButton", true, false) != null, "Rules button is in main menu")
	var news_button: Button = game.menu_screen.find_child("Feature_4", true, false) as Button
	verify(news_button != null, "News button exists in the main menu")
	if news_button != null:
		verify(news_button.text.contains("Новости"), "The Share button is now labeled Новости")
	verify(game.news_dialog != null, "A separate premium-styled News dialog exists")
	var news_link: Label = game.news_dialog.find_child("NewsChannelLink", true, false) as Label
	verify(news_link != null, "The News dialog displays the JokerShift Telegram address")
	if news_link != null:
		verify(news_link.text == "t.me/+HLR-m55X-bM2ZjAy", "The displayed Telegram link matches the user's channel")
	verify(game.TELEGRAM_NEWS_URL == "https://t.me/+HLR-m55X-bM2ZjAy", "Telegram open URL matches user-supplied invite link")
	verify(int(ProjectSettings.get_setting("display/window/handheld/orientation")) == 5, "Mobile starts in portrait sensor orientation")
	verify(game.menu_screen.find_child("MenuCenter", true, false).size_flags_vertical == Control.SIZE_SHRINK_BEGIN, "Mobile menu starts at the top rather than leaving empty space")
	verify(game.menu_screen.find_child("MenuBackground", true, false).stretch_mode == TextureRect.STRETCH_KEEP_ASPECT_COVERED, "Menu art crops without distortion")
	verify(game.game_screen.find_child("GameScroll", true, false).vertical_scroll_mode != ScrollContainer.SCROLL_MODE_SHOW_ALWAYS, "Mobile game keeps fallback scrolling when necessary")
	verify(game.game_screen.find_child("ActionButtons", true, false).columns == 3, "Three essential action buttons fit in one row")
	verify(not game.deck_panel.visible, "Mobile deck strip replaces tall art and saves room for hand")
	verify(game.mobile_deck_strip.visible, "Dedicated mobile info panel is visible")
	verify(game.mobile_deck_label.autowrap_mode == TextServer.AUTOWRAP_OFF, "Deck label stays horizontal on phone")
	var features: GridContainer = game.menu_screen.find_child("FeatureGrid", true, false) as GridContainer
	verify(features != null and features.get_child_count() == 4, "Friends, Items, News and Rules; removed achievements and honor board")
	game.show_coming_soon("Друзья")
	verify(game.coming_soon_overlay.visible and game.coming_soon_title_label.text == "ДРУЗЬЯ", "Feature button opens premium development notice")
	game.coming_soon_overlay.hide()
	verify(game.game_screen.find_child("ActionButtons", true, false).get_child_count() == 3, "No Rules button during a party")

	# Timer, pause and resume work without returning to the home screen.
	verify(game.game_screen.find_child("GameStopwatch", true, false) != null, "Stopwatch appears in the game's top bar")
	verify(game.game_screen.find_child("OpenPauseButton", true, false) != null, "Top-right bars open Pause instead of home")
	verify(game.pause_overlay != null, "Dedicated premium Pause overlay exists")
	verify(game.pause_overlay.find_child("PauseCard", true, false) != null, "Pause panel has scrollable adaptive sizing")
	var time_caption: Label = game.pause_overlay.find_child("PauseTimeCaption", true, false) as Label
	verify(time_caption != null and time_caption.autowrap_mode == TextServer.AUTOWRAP_OFF, "Pause time caption is always on one line")
	verify(game.pause_overlay.find_child("PauseTimePanel", true, false) != null, "Pause time uses a full-width styled panel")
	verify(game.game_screen.find_child("StopwatchCaption", true, false) != null, "In-game time has its own compact caption")
	verify(game.rules_dialog.process_mode == Node.PROCESS_MODE_ALWAYS, "Rules popup stays interactive during pause")
	for button_name in ["PauseContinue", "PauseRestart", "PauseRules", "PauseHome"]:
		verify(game.pause_overlay.find_child(button_name, true, false) != null, "Pause includes " + button_name)
	verify(game.format_game_time(65.0) == "01:05", "Timer displays minutes and seconds")
	verify(game.format_game_time(3661.0) == "01:01:01", "Long games display hours too")
	game.game_screen.show()
	game.menu_screen.hide()
	game.animation_busy = false
	game.finished = false
	game.elapsed_game_seconds = 82.0
	game._process(1.0)
	verify(game.timer_label.text == "01:23", "In-game clock counts active time")
	game.pause_game()
	verify(paused and game.is_game_paused and game.pause_overlay.visible, "Pause freezes the entire SceneTree")
	var frozen_time: float = game.elapsed_game_seconds
	game._process(9.0)
	verify(game.elapsed_game_seconds == frozen_time, "Stopwatch remains frozen on pause")
	verify(game.pause_timer_label.text == "01:23", "Pause panel shows current elapsed time")
	game.resume_game()
	verify(not paused and not game.is_game_paused and not game.pause_overlay.visible, "Continue resumes gameplay and hides pause overlay")
	game.pause_game()
	game.restart_from_pause()
	verify(not paused and game.elapsed_game_seconds == 0.0 and game.timer_label.text == "00:00", "Restart clears pause and resets session timer")
	game.pause_game()
	game.menu_from_pause()
	verify(not paused and game.menu_screen.visible and not game.game_screen.visible, "Main menu from pause exits cleanly")

	verify(game.get("face_image_cache") != null, "Individual face image cache is available")
	verify(game.card_face_key(normal_card(2, "♥")) == "h_2", "Each card has a separate image key")
	var readable_card: Button = game.make_card_view(normal_card(10, "♦"), "hand", 0, -1) as Button
	root.add_child(readable_card)
	await process_frame
	verify(readable_card.get_node_or_null("CardIdentity") == null, "Numbered cards keep only their printed rank and suit")
	readable_card.queue_free()
	var court_card: Button = game.make_card_view(normal_card(13, "♠"), "hand", 0, -1) as Button
	root.add_child(court_card)
	await process_frame
	verify(court_card.get_node_or_null("CardIdentity") == null, "Letter cards do not have overlapping rank or suit overlays")
	court_card.queue_free()
	verify(game.menu_panel.custom_minimum_size.x <= 456.0, "Menu has adaptive maximum width")
	verify(game.card_face_texture(normal_card(2, "♥")) != null, "Original heart rank 2 has image")
	verify(game.card_face_texture(normal_card(10, "♦")) != null, "Original diamond rank 10 has image")
	verify(game.card_face_texture(normal_card(14, "♠")) != null, "Generated missing ace rank has image")
	var actual_face: Texture2D = game.card_face_texture(normal_card(8, "♦"))
	verify(actual_face is ImageTexture, "Faces render from individual PNGs, not AtlasTexture")
	verify(actual_face.get_width() < 200 and actual_face.get_height() < 200, "Faces are pre-resized to game card size")
	verify(DirAccess.open("res://assets/faces/") != null, "Individual original-art card faces are present")


	var joker: Dictionary = {
		"rank": 20, "suit": "", "special": "joker",
		"joker_color": "red", "copy_rank": -1, "copy_suit": ""
	}
	var copied: Dictionary = game.copy_joker(joker, normal_card(9, "♣"))
	verify(game.joker_copy_label(copied) == "9♣", "Joker shows the exact card copied")

	# Real rank-and-suit rules for a Joker copying a visible table card.
	game.trump_mode = "suit"
	game.trump_suit = "♠"
	var joker_six_hearts: Dictionary = game.copy_joker(joker, normal_card(6, "♥"))
	var joker_seven_hearts: Dictionary = game.copy_joker(joker, normal_card(7, "♥"))
	var joker_three_spades: Dictionary = game.copy_joker(joker, normal_card(3, "♠"))
	var joker_four_spades: Dictionary = game.copy_joker(joker, normal_card(4, "♠"))
	verify(not game.can_beat(joker_six_hearts, normal_card(6, "♥")), "Same-rank copy never defends equal rank")
	verify(game.can_beat(joker_seven_hearts, normal_card(6, "♥")), "Copied nontrump one rank higher defends matching suit")
	verify(not game.can_beat(joker_seven_hearts, normal_card(6, "♦")), "Copied nontrump cannot beat a different suit")
	verify(not game.can_beat(joker_seven_hearts, normal_card(2, "♠")), "Copied nontrump cannot cover trump")
	verify(game.can_beat(joker_three_spades, normal_card(2, "♠")), "Higher copied trump beats lower trump")
	verify(not game.can_beat(joker_three_spades, normal_card(4, "♠")), "Lower copied trump cannot beat higher trump")
	verify(game.can_beat(joker_three_spades, normal_card(14, "♦")), "Copied trump still beats nontrump under Durak rules")
	var copied_mark: Dictionary = game.copy_joker(joker, {"rank": 22, "suit": "", "special": "mark", "joker_color": "", "copy_rank": -1, "copy_suit": ""})
	verify(game.can_beat(copied_mark, normal_card(2, "♠")), "Joker copying Mark covers trumps too")
	verify(game.can_beat(copied_mark, normal_card(9, "♦")), "Joker copying Mark covers nontrumps too")
	verify(game.can_beat(copied_mark, copied_mark), "A second Joker copying Mark can cover the first")
	verify(game.can_beat(copied_mark, {"rank":22, "suit":"", "special":"mark", "joker_color":"", "copy_rank":-1, "copy_suit":""}), "Copied Mark can cover an actual Mark")
	verify(not game.can_beat(joker_seven_hearts, copied_mark), "Ordinary-rank Joker copy cannot cover a Mark copy")
	verify(not game.can_beat(normal_card(14, "♠"), copied_mark), "Ordinary trump cannot cover a Mark copy")
	# The defender can select the copied Mark from the table, copy it
	# with another Joker in hand, and place the defense in the same slot.
	game.attacker = 1
	game.finished = false
	game.animation_busy = false
	game.bot_hand = [normal_card(2, "♣")]
	game.player_hand = [joker.duplicate(true)]
	game.table_cards = [{"attack": copied_mark.duplicate(true), "defense": {}, "slot_id": 0}]
	game.show_joker_choices("defend", 0, 0)
	verify(game.joker_options.get_child_count() >= 1, "Defender can choose another Joker to copy the table's Mark")
	game.choose_joker(copied_mark)
	verify(not game.table_cards[0]["defense"].is_empty() and game.card_rank(game.table_cards[0]["defense"]) == 100, "Joker copying Mark covers the incoming copied Mark")
	game.joker_dialog.hide()
	game.new_game()
	game.trump_mode = "suit"
	game.trump_suit = "♠"
	verify(game.can_beat(joker_four_spades, normal_card(4, "♠")), "EXCEPTION: Joker copied same trump covers that exact trump")
	verify(not game.can_beat(normal_card(4, "♠"), normal_card(4, "♠")), "Ordinary equal trump does not beat itself")
	game.trump_mode = "black"
	verify(not game.can_beat(joker_four_spades, normal_card(4, "♣")), "Equal rank in other trump suit does not qualify for exact-copy exception")
	game.trump_mode = "suit"
	verify(not game.can_beat(joker_six_hearts, normal_card(6, "♥")), "Copied nontrump equal rank still cannot beat itself")

	var joker_view: Button = game.make_card_view(copied, "ghost", -1, -1) as Button
	root.add_child(joker_view)
	await process_frame
	verify(joker_view.get_node_or_null("JokerCopiedValue") != null, "Joker has visible copy badge")
	joker_view.queue_free()

	game.first_round = false
	game.attacker = 0
	game.table_cards.clear()
	for index in range(4):
		game.table_cards.append({
			"attack": normal_card(6 + index, "♣"),
			"defense": normal_card(7 + index, "♣"),
			"slot_id": index
		})
	game.bot_hand = [normal_card(2, "♥"), normal_card(3, "♥")]
	verify(game.defender_attack_limit() == 6, "Four defended cards + two in hand permit only two more attacks")

	game.table_cards = [{"attack": normal_card(10, "♣"), "defense": {}, "slot_id": 0}]
	game.bot_hand = [normal_card(2, "♥"), normal_card(3, "♥"), normal_card(4, "♥"), normal_card(5, "♥"), normal_card(6, "♥"), normal_card(7, "♥")]
	game.trump_mode = "suit"
	game.trump_suit = "♠"
	game.bot_difficulty = 1
	game.bot_takes = false
	game.deck = [normal_card(12, "♣")]
	game.bot_defend()
	verify(game.bot_hand.size() == 6 and game.bot_takes, "Bot never draws above six when defending")
	verify(game.deck.size() == 1, "Deck unchanged when defending with six cards")

	game.attacker = 1
	game.finished = false
	game.bot_takes = false
	game.animation_busy = false
	game.trump_suit = "♥"
	game.table_cards = [{"attack": normal_card(4, "♦"), "defense": normal_card(14, "♦"), "slot_id": 0}]
	game.player_hand = [normal_card(2, "♥")]
	game.bot_hand = [normal_card(3, "♣")]
	game.player_replace(0, 0, game.player_hand[0])
	verify(not game.pending_replacement.is_empty(), "Trumpy replacement needs confirmation")
	verify(game.card_rank(game.table_cards[0]["defense"]) == 14, "Unconfirmed replacement keeps ace on table")
	game.confirm_replacement()
	verify(game.card_rank(game.table_cards[0]["defense"]) == 2, "Confirmed replacement places trump two on table")
	verify(game.card_rank(game.player_hand[0]) == 14, "Old ace returns to hand")

	print("JokerShift checks: ", "OK" if errors == 0 else str(errors) + " error(s)")
	quit(0 if errors == 0 else 1)
