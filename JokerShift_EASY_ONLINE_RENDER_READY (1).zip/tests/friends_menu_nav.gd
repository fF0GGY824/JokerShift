extends SceneTree

func _initialize() -> void:
	call_deferred("_verify")

func _check(condition: bool, caption: String) -> bool:
	if condition:
		print("PASS: " + caption)
	else:
		push_error("FAIL: " + caption)
	return condition

func _verify() -> void:
	var original: Control = load("res://control.tscn").instantiate()
	root.add_child(original)
	await process_frame
	var friend_tab: Button = original.menu_screen.find_child("Feature_2", true, false)
	if not _check(friend_tab != null, "Existing main-menu Friends button found"):
		quit(1); return
	friend_tab.pressed.emit()
	await process_frame
	var view: Control = original.online_view
	if not _check(view != null and view.visible and view.page == "friends", "Main-menu Friends button opens Friends page"):
		quit(1); return
	if not _check(view.friends_section.visible and not view.form_panel.visible and not view.room_label.visible, "Friends page shows friend controls, not room controls"):
		quit(1); return
	if not _check(view.social_id_label != null and view.social_friend_id != null and view.chat_dialog != null, "Friend ID, requests and chats are present"):
		quit(1); return
	if not _check(view.root.find_children("*", "Button", true, false).all(func(btn: Button) -> bool: return btn.text != "👥 ДРУЗЬЯ"), "No duplicate Friends button in online area"):
		quit(1); return
	view._do_leave()
	await process_frame
	if not _check(not view.visible and is_instance_valid(view), "Back to menu hides Friends without destroying session"):
		quit(1); return
	original.open_online()
	await process_frame
	if not _check(original.online_view == view and view.page == "online" and view.form_panel.visible and not view.friends_section.visible, "Online only shows room creation and entry"):
		quit(1); return
	original.open_friends_tab()
	await process_frame
	if not _check(view.page == "friends" and view.friends_section.visible, "Friends page reopens without duplicating client"):
		quit(1); return
	print("Friends menu navigation: PASS")
	quit(0)
