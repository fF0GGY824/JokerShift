extends SceneTree

func _initialize() -> void:
	call_deferred("_check")

func _check() -> void:
	var game: Control = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.open_online()
	var client: Control = game.online_view
	if client.form_panel == null or client.connection_panel == null:
		push_error("Missing easy online lobby or one-time connection settings")
		quit(1)
		return
	var panel: VBoxContainer = client.connection_panel
	if not panel.is_ancestor_of(client.url_input):
		push_error("Server address should be inside optional settings panel")
		quit(1)
		return
	if client.friend_server_input != client.url_input:
		push_error("Friends page duplicated server address input")
		quit(1)
		return
	var temporary_profile: String = "user://test_easy_online_" + str(Time.get_ticks_usec()) + ".cfg"
	client.profile_storage_path = temporary_profile
	client.url_input.text = "wss://example.onrender.com"
	client._save_server_url()
	var data: ConfigFile = ConfigFile.new()
	if data.load(temporary_profile) != OK or data.get_value("connection", "url") != "wss://example.onrender.com":
		push_error("One-time server URL was not saved")
		quit(1)
		return
	if client.connection_panel.visible:
		push_error("Settings panel should collapse after saving")
		quit(1)
		return
	print("PASS: One-time connection saved, hidden, reused in friends tab")
	client._do_leave()
	quit(0)
