extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var result: Error = change_scene_to_file("res://loading.tscn")
	if result != OK:
		push_error("Boot scene failed to open")
		quit(1)
		return
	await create_timer(2.0).timeout
	if current_scene == null or current_scene.name != "Control":
		push_error("Loader did not transition to JokerShift menu: " + str(current_scene))
		quit(1)
		return
	print("PASS: Loading screen enters the actual game")
	quit(0)
