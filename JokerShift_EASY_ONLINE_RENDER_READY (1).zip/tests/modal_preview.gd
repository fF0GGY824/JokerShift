extends SceneTree

func _initialize() -> void:
	call_deferred("capture")

func capture() -> void:
	var game: Variant = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	await process_frame
	game.adapt_layout(Vector2(480, 854))
	game.show_coming_soon("Достижения")
	await create_timer(0.6).timeout
	var path1: String = "/mnt/data/JokerShift_MODAL_achievement_preview.png"
	var result1: Error = root.get_texture().get_image().save_png(path1)
	print("PREVIEW ACHIEVEMENT:", result1)
	game.coming_soon_overlay.hide()
	game.ask_exit_game()
	await create_timer(0.6).timeout
	var path2: String = "/mnt/data/JokerShift_MODAL_exit_preview.png"
	var result2: Error = root.get_texture().get_image().save_png(path2)
	print("PREVIEW EXIT:", result2)
	quit(0 if result1 == OK and result2 == OK else 1)
