extends SceneTree

var issues: int = 0

func verify(value: bool, message: String) -> void:
	if value:
		print("PASS: ", message)
	else:
		issues += 1
		push_error("FAIL: " + message)

func card(i: int, rank: int) -> Dictionary:
	return {"id": i, "rank": rank, "suit": "♠", "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""}

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var game: Variant = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	game.animation_enabled = false
	game.start_game()
	await process_frame
	for dims in [Vector2(320, 568), Vector2(390, 844), Vector2(480, 854), Vector2(720, 1280)]:
		game.adapt_layout(dims)
		await process_frame
		verify(game.hand_card_width > game.card_width * 1.17, str(dims) + " larger cards in player hand")
		verify(game.hand_scroll.custom_minimum_size.y >= game.hand_card_height, str(dims) + " hand scroll tall enough")
		verify(game.hand_actions_layout.find_child("HandCardSlider", true, false) != null, str(dims) + " card selector slider visible")
		verify(game.hand_actions_layout.find_child("HandPreviousCard", true, false) != null, str(dims) + " left arrow available")
		verify(game.hand_actions_layout.find_child("HandNextCard", true, false) != null, str(dims) + " right arrow available")

	root.size = Vector2i(480, 854)
	game.adapt_layout(Vector2(480, 854))
	await process_frame
	game.player_hand = [card(1, 3), card(2, 4), card(3, 5), card(4, 6), card(5, 7), card(6, 8), card(7, 9)]
	game.selected_index = -1
	game.update_ui()
	await process_frame
	verify(game.hand_row.get_child_count() == 7, "All hand cards stay reachable through horizontal scroll")
	verify(game.hand_picker_label.text == "— / 7", "No selection is shown initially")
	game.step_hand_card(1)
	verify(game.selected_index == 0 and game.hand_picker_label.text == "1 / 7", "Right arrow selects first card")
	game.select_hand_card_on_slider(5.0)
	verify(game.selected_index == 5, "Slider picks sixth card")
	verify(int(game.hand_picker_slider.value) == 5, "Slider syncs with chosen hand card")
	await process_frame
	await process_frame
	verify(game.hand_scroll.scroll_horizontal > 0, "Selected distant card scrolls into view")
	game.step_hand_card(-1)
	verify(game.selected_index == 4, "Left arrow selects previous card")
	game.player_hand.clear()
	game.selected_index = -1
	game.update_ui()
	verify(not game.hand_picker_slider.editable, "Empty hand disables slider")

	# No automatic finish if a card is still uncovered.
	game.finished = false
	game.deck = []
	game.player_hand = []
	game.bot_hand = [card(8, 12)]
	game.attacker = 0
	game.bot_takes = false
	game.table_cards = [{"attack": card(12, 7), "defense": {}, "slot_id": 0}]
	verify(not game.is_final_round_ready(), "Cannot win before defending attack")
	game.deck = [card(89, 2)]
	game.table_cards[0]["defense"] = card(13, 8)
	verify(not game.is_final_round_ready(), "Cannot auto-end while deck still has cards")
	game.deck.clear()
	verify(game.is_final_round_ready(), "A truly final fully defended round is detected")
	verify(game.maybe_auto_finish_final_round(), "Winning round automatically schedules Bito")
	await process_frame
	await process_frame
	verify(game.table_cards.is_empty(), "Automatic Bito clears defended cards")
	verify(game.finished, "Win is registered without pressing Bito")

	print("HAND + AUTO VICTORY TEST: ", "PASS" if issues == 0 else "%d errors" % issues)
	quit(0 if issues == 0 else 1)
