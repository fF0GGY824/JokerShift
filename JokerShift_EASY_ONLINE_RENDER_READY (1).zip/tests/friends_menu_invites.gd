extends SceneTree

func _initialize() -> void:
	call_deferred("_test")

func _wait_until(check: Callable, description: String) -> bool:
	for _i in range(250):
		if check.call():
			print("PASS: " + description)
			return true
		await create_timer(0.025).timeout
	push_error("FAIL: " + description)
	return false

func _logged_in(view: Control) -> bool:
	return view.player_id.length() == 8

func _requested(view: Control) -> bool:
	return not (view.friends_state.get("requests", []) as Array).is_empty()

func _has_friend(view: Control) -> bool:
	return not (view.friends_state.get("friends", []) as Array).is_empty()

func _room_created(view: Control) -> bool:
	return view.current_code.length() == 6

func _invited(view: Control) -> bool:
	return view.invitation_code.length() == 6

func _test() -> void:
	var root_game: Control = load("res://control.tscn").instantiate()
	root.add_child(root_game)
	await process_frame
	root_game.open_friends_tab()
	var host: Control = root_game.online_view
	var guest: Control = (load("res://online/online_ui.gd") as Script).new()
	guest.offline_game = root_game
	root.add_child(guest)
	await process_frame
	host.profile_storage_path = "user://menu_invite_host_" + str(Time.get_ticks_usec()) + ".cfg"
	guest.profile_storage_path = "user://menu_invite_guest_" + str(Time.get_ticks_usec()) + ".cfg"
	host.friend_server_input.text = "ws://127.0.0.1:8765"
	guest.url_input.text = "ws://127.0.0.1:8765"
	root_game.nick_input.text = "Хост"  # Nickname lives in the main menu.
	host._begin_request("login")
	guest._begin_request("login")
	if not await _wait_until(_logged_in.bind(host), "Host logged in from Friends menu"):
		quit(1); return
	if not await _wait_until(_logged_in.bind(guest), "Guest logged in"):
		quit(1); return
	host.social_friend_id.text = guest.player_id
	host._add_friend()
	if not await _wait_until(_requested.bind(guest), "Friend request received"):
		quit(1); return
	guest._social_send("friend_accept", host.player_id)
	if not await _wait_until(_has_friend.bind(host), "Friend visible in menu"):
		quit(1); return
	guest._do_leave()
	await process_frame
	if guest.visible or not guest.logged_in:
		push_error("Guest connection closed when returning to menu")
		quit(1); return
	print("PASS: Guest stays connected while in main menu")
	if not host.current_code.is_empty():
		push_error("Host unexpectedly had a room before invitation")
		quit(1); return
	host._invite_friend(guest.player_id)
	if not await _wait_until(_room_created.bind(host), "Invitation from Friends menu auto-creates a room"):
		quit(1); return
	if not await _wait_until(_invited.bind(guest), "Invitation arrives while guest is in main menu"):
		quit(1); return
	if not guest.visible or guest.page != "friends":
		push_error("Friends invitation was not opened from main menu")
		quit(1); return
	print("PASS: Guest Friends page opens for invitation")
	guest._accept_invitation()
	if not await _wait_until(_room_created.bind(guest), "Guest joins automatically created room"):
		quit(1); return
	if guest.page != "online":
		push_error("Accepted invite did not switch to room screen")
		quit(1); return
	print("PASS: Accepted invite switches into online game lobby")
	host._do_leave()
	guest._do_leave()
	quit(0)
