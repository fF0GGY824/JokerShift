extends SceneTree

func _initialize() -> void:
	call_deferred("_check")

func demand(ok: bool, message: String) -> void:
	if not ok:
		push_error(message)
		quit(1)
		return
	print("PASS: " + message)

func _check() -> void:
	var game: Control = load("res://control.tscn").instantiate()
	root.add_child(game)
	await process_frame
	if game.settings_screen == null or game.settings_screen.visible:
		push_error("Settings screen must exist and start hidden")
		quit(1)
		return
	var settings_button: Button = game.menu_screen.find_child("OpenSettingsButton", true, false) as Button
	if settings_button == null:
		push_error("Main menu must contain a Settings button")
		quit(1)
		return
	if game.menu_screen.find_child("DifficultySelect", true, false) != null or game.menu_screen.find_child("SfxVolume", true, false) != null:
		push_error("Settings fields duplicated in main menu")
		quit(1)
		return
	print("PASS: settings reachable with one menu entry; no duplicates")
	game.open_settings()
	await process_frame
	if not game.settings_screen.visible or game.menu_screen.visible:
		push_error("Open Settings must hide the main menu")
		quit(1)
		return
	var scroll: ScrollContainer = game.settings_screen.find_child("SettingsScroll", true, false) as ScrollContainer
	if scroll == null or scroll.vertical_scroll_mode != ScrollContainer.SCROLL_MODE_AUTO:
		push_error("Settings need scrolling fallback for short phones")
		quit(1)
		return
	for name in ["DifficultySelect", "SfxVolume", "AnimationsToggle", "VibrationToggle", "PowerSavingToggle", "ResetSettingsButton", "SettingsBackButton"]:
		if game.settings_screen.find_child(name, true, false) == null:
			push_error("Missing settings control: " + name)
			quit(1)
			return
	if game.settings_screen.find_children("*Nick*", "LineEdit", true, false).size() != 0:
		push_error("Nickname editor must remain only on main menu")
		quit(1)
		return
	print("PASS: gameplay, audio, graphics, controls, restore defaults and back button")
	game.on_difficulty_changed(2)
	game.on_sfx_volume_changed(0.25)
	game.on_animations_toggled(false)
	game.on_vibration_toggled(false)
	game.on_low_power_toggled(true)
	if game.bot_difficulty != 2 or absf(game.sfx_volume - 0.25) > 0.01 or game.animation_enabled or game.vibration_enabled or Engine.max_fps != 30:
		push_error("Setting toggles did not affect live game behavior")
		quit(1)
		return
	var saved: ConfigFile = ConfigFile.new()
	if saved.load(game.PROFILE_SAVE_PATH) != OK:
		push_error("Settings not persisted")
		quit(1)
		return
	if saved.get_value("visual", "animations", true) or not saved.get_value("visual", "battery_saver", false) or saved.get_value("controls", "vibration", true):
		push_error("Settings values not saved")
		quit(1)
		return
	if absf(float(saved.get_value("audio", "sfx_volume", 0.0)) - 0.25) > 0.01 or int(saved.get_value("game", "difficulty", -1)) != 2:
		push_error("Difficulty and volume not persisted")
		quit(1)
		return
	print("PASS: live toggles and persistent profile.cfg settings")
	game.reset_settings()
	if game.bot_difficulty != 1 or not game.animation_preference or not game.vibration_enabled or game.low_power_mode or Engine.max_fps != 60:
		push_error("Reset-to-defaults failed")
		quit(1)
		return
	if absf(game.sfx_slider.value - 0.67) > 0.01 or game.difficulty_select.selected != 1:
		push_error("Reset did not refresh UI widgets")
		quit(1)
		return
	print("PASS: restore defaults updates data and widgets")
	for size in [Vector2(320, 568), Vector2(360, 640), Vector2(480, 854), Vector2(720, 1280)]:
		game.adapt_layout(size)
		var panel: PanelContainer = game.settings_screen.find_child("SettingsPanel", true, false) as PanelContainer
		if panel.custom_minimum_size.x > size.x:
			push_error("Settings panel wider than phone: " + str(size))
			quit(1)
			return
	print("PASS: settings panel width fits 320 to 720 px portraits")
	game.close_settings()
	if not game.menu_screen.visible or game.settings_screen.visible:
		push_error("Back button did not return to menu")
		quit(1)
		return
	print("PASS: settings page returns to main menu")
	var exit_button: Button = game.menu_screen.find_child("ExitGameButton", true, false) as Button
	if exit_button == null or game.exit_overlay == null:
		push_error("Exit button and premium modal missing")
		quit(1)
		return
	exit_button.pressed.emit()
	await process_frame
	if not game.exit_overlay.visible:
		push_error("Exit button does not open premium confirmation")
		quit(1)
		return
	game.exit_overlay.hide()
	print("PASS: exit button in menu opens confirmation without closing unexpectedly")
	quit(0)
