extends SceneTree

func _initialize() -> void:
	call_deferred("_test")

func _wait_until(check: Callable, description: String) -> bool:
	for _i in range(250):
		if check.call():
			print("PASS: " + description)
			return true
		await create_timer(0.025).timeout
	push_error("FAIL: " + description)
	return false

func _has_id(client: Control) -> bool:
	return client.player_id.length() == 8

func _has_request(client: Control) -> bool:
	return (client.friends_state.get("requests", []) as Array).size() > 0

func _has_friend(client: Control) -> bool:
	return (client.friends_state.get("friends", []) as Array).size() > 0

func _has_invitation(client: Control) -> bool:
	return client.invitation_code.length() == 6

func _has_code(client: Control) -> bool:
	return client.current_code.length() == 6

func _has_message(client: Control, text: String) -> bool:
	for message in client.chat_history.get("room:" + client.current_code, []):
		if str(message).contains(text):
			return true
	return false

func _test() -> void:
	var offline: Control = load("res://control.tscn").instantiate()
	root.add_child(offline)
	await process_frame
	offline.open_online()
	var a: Control = offline.online_view
	var b: Control = (load("res://online/online_ui.gd") as Script).new()
	b.offline_game = offline
	root.add_child(b)
	await process_frame
	a.profile_storage_path = "user://jokershift_social_integration_a_" + str(Time.get_ticks_usec()) + ".cfg"
	b.profile_storage_path = "user://jokershift_social_integration_b_" + str(Time.get_ticks_usec()) + ".cfg"
	a.url_input.text = "ws://127.0.0.1:8765"
	b.url_input.text = "ws://127.0.0.1:8765"
	offline.nick_input.text = "Алиса"  # Nickname is edited only in the main menu.
	a._begin_request("login")
	if not await _wait_until(_has_id.bind(a), "First Godot player authenticated"):
		quit(1); return
	b._begin_request("login")
	if not await _wait_until(_has_id.bind(b), "Second Godot player authenticated"):
		quit(1); return
	if a.player_id == b.player_id:
		push_error("Players have same account")
		quit(1); return
	a._open_friends()
	a.social_friend_id.text = b.player_id
	a._add_friend()
	if not await _wait_until(_has_request.bind(b), "Friend request delivered in Godot"):
		quit(1); return
	b._social_send("friend_accept", a.player_id)
	if not await _wait_until(_has_friend.bind(a), "Friendship appears on host"):
		quit(1); return
	a._open_chat(b.player_id)
	a.chat_input.text = "Привет, сыграем?"
	a._send_chat()
	for _i in range(60):
		await create_timer(0.025).timeout
	var dm_messages: Array = b.chat_history.get("dm:" + a.player_id, [])
	if dm_messages.is_empty():
		push_error("Direct message did not arrive in Godot")
		quit(1); return
	print("PASS: Direct chat delivered between Godot clients")
	a.chat_dialog.hide()
	a._begin_request("create")
	if not await _wait_until(_has_code.bind(a), "Host room created"):
		quit(1); return
	a._invite_friend(b.player_id)
	if not await _wait_until(_has_invitation.bind(b), "Friend invite delivered and popup opened"):
		quit(1); return
	b._accept_invitation()
	if not await _wait_until(_has_code.bind(b), "Friend accepted invitation and joined room"):
		quit(1); return
	a._open_chat()
	a.chat_input.text = "Ход за тобой"
	a._send_chat()
	if not await _wait_until(_has_message.bind(b, "Ход за тобой"), "Room chat synchronized"):
		quit(1); return
	a._do_leave()
	b._do_leave()
	quit(0)
