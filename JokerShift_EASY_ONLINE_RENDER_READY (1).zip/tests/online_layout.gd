extends SceneTree

func _initialize() -> void:
	call_deferred("_verify")

func _verify() -> void:
	var scene: Control = load("res://control.tscn").instantiate()
	root.add_child(scene)
	await process_frame
	scene.open_online()
	await process_frame
	if scene.online_view == null:
		push_error("Online view has not been created")
		quit(1)
		return
	var online: Control = scene.online_view
	if online.form_panel == null or online.url_input == null or online.game_panel == null:
		push_error("Online lobby has missing widgets")
		quit(1)
		return
	print("PASS: Online lobby and form created in Godot")
	var sample_card := {"id": 1, "rank": 13, "suit": "♠", "special": "", "joker_color": "", "copy_rank": -1, "copy_suit": ""}
	if online._face(sample_card) == null:
		push_error("Card image failed to load")
		quit(1)
		return
	print("PASS: Original card art loaded in online mode")
	online.current_code = "123456"
	online.state = {
		"type":"state", "your_seat":0,"your_name":"Алиса", "opponent_name":"Боб",
		"your_hand":[sample_card], "opponent_count":6,
		"table":[{"attack": sample_card, "defense":null}],
		"deck_count":20,"discard_count":0,"trump_mode":"suit","trump_suit":"♠",
		"attacker":0,"defender":1,"taking":false,"round":1,"notice":"Твой ход",
		"stage":"game","winner":null
	}
	online.game_panel.show()
	online._render_game()
	await process_frame
	if online.table_grid.get_child_count() != 10 or online.hand_row.get_child_count() != 1:
		push_error("Online card widgets did not render correctly")
		quit(1)
		return
	print("PASS: Online field and player cards rendered")
	online._do_leave()
	await process_frame
	print("PASS: Online menu closed")
	quit(0)
