extends Control
## Boot screen: load the real game scene in the background while showing progress.

const GAME_SCENE: String = "res://control.tscn"
var load_progress: ProgressBar
var status: Label
var crest: Label
var time_passed: float = 0.0
var requested: bool = false
var entering: bool = false

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg: TextureRect = TextureRect.new()
	bg.texture = load("res://assets/menu_background.png")
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var veil: ColorRect = ColorRect.new()
	veil.color = Color(0.055, 0.025, 0.11, 0.73)
	veil.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(veil)
	veil.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var center: CenterContainer = CenterContainer.new()
	add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var column: VBoxContainer = VBoxContainer.new()
	column.custom_minimum_size = Vector2(240, 220)
	column.add_theme_constant_override("separation", 14)
	center.add_child(column)

	crest = Label.new()
	crest.text = "✦ 🃏 ✦"
	crest.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	crest.add_theme_font_size_override("font_size", 46)
	crest.add_theme_color_override("font_color", Color("#DFB7FF"))
	column.add_child(crest)

	var name_tag: Label = Label.new()
	name_tag.text = "J O K E R S H I F T"
	name_tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_tag.add_theme_font_size_override("font_size", 23)
	name_tag.add_theme_color_override("font_color", Color("#F3DDFF"))
	column.add_child(name_tag)

	var caption: Label = Label.new()
	caption.text = "✦  ТВОЯ ИГРА НАЧИНАЕТСЯ  ✦"
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	caption.add_theme_font_size_override("font_size", 12)
	caption.add_theme_color_override("font_color", Color("#D7AFFF"))
	column.add_child(caption)

	load_progress = ProgressBar.new()
	load_progress.custom_minimum_size = Vector2(245, 15)
	load_progress.show_percentage = false
	load_progress.min_value = 0
	load_progress.max_value = 100
	load_progress.value = 0
	var track: StyleBoxFlat = StyleBoxFlat.new()
	track.bg_color = Color("#291437")
	track.set_corner_radius_all(12)
	load_progress.add_theme_stylebox_override("background", track)
	var fill: StyleBoxFlat = StyleBoxFlat.new()
	fill.bg_color = Color("#BB78FF")
	fill.set_corner_radius_all(12)
	load_progress.add_theme_stylebox_override("fill", fill)
	column.add_child(load_progress)

	status = Label.new()
	status.text = "Загружаем карты..."
	status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status.add_theme_font_size_override("font_size", 13)
	status.add_theme_color_override("font_color", Color("#D6BBEA"))
	column.add_child(status)
	var rc: Error = ResourceLoader.load_threaded_request(GAME_SCENE)
	requested = rc == OK
	if not requested:
		status.text = "Ошибка загрузки игры (" + str(rc) + ")"

func _process(delta: float) -> void:
	if not requested or entering:
		return
	time_passed += delta
	crest.position.y = sin(time_passed * 2.7) * 4.0
	crest.modulate.a = 0.76 + 0.24 * (sin(time_passed * 3.4) * 0.5 + 0.5)
	var progress: Array = []
	var state: ResourceLoader.ThreadLoadStatus = ResourceLoader.load_threaded_get_status(GAME_SCENE, progress)
	var value: float = float(progress[0]) if not progress.is_empty() else 0.0
	load_progress.value = maxf(load_progress.value, value * 100.0)
	if state == ResourceLoader.THREAD_LOAD_FAILED or state == ResourceLoader.THREAD_LOAD_INVALID_RESOURCE:
		status.text = "Не удалось загрузить игру"
		requested = false
		return
	if state == ResourceLoader.THREAD_LOAD_LOADED:
		load_progress.value = 100.0
		status.text = "Готово!"
		# Keep the splash visible long enough to avoid a white screen flash.
		if time_passed >= 0.75:
			entering = true
			var scene: PackedScene = ResourceLoader.load_threaded_get(GAME_SCENE) as PackedScene
			if scene != null:
				get_tree().change_scene_to_packed(scene)
			else:
				status.text = "Не удалось открыть главное меню"
